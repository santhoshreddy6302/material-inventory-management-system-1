import { useState, useEffect, useCallback } from 'react';
import { Plus, Edit2, Trash2, Package, RefreshCw } from 'lucide-react';
import { materialService } from '../../services/materialService';
import { supplierService } from '../../services/supplierService';
import DataTable from '../../components/common/DataTable';
import Pagination from '../../components/common/Pagination';
import SearchFilter from '../../components/common/SearchFilter';
import Modal from '../../components/common/Modal';
import { fmtCurrency, fmtNumber, getStatusLabel } from '../../utils/helpers';
import toast from 'react-hot-toast';
import { useAuth } from '../../context/AuthContext';

const emptyForm = { name:'',category_id:'',unit:'',description:'',cost_per_unit:'',minimum_threshold:'',reorder_quantity:'',supplier_id:'',specifications:'' };

export default function MaterialList() {
  const { hasRole } = useAuth();
  const canEdit = hasRole('admin','procurement_staff');
  const [data, setData]           = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading]     = useState(true);
  const [search, setSearch]       = useState('');
  const [filters, setFilters]     = useState({});
  const [page, setPage]           = useState(1);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing]     = useState(null);
  const [form, setForm]           = useState(emptyForm);
  const [saving, setSaving]       = useState(false);
  const [categories, setCategories] = useState([]);
  const [suppliers, setSuppliers]   = useState([]);
  const [catModal, setCatModal]   = useState(false);
  const [catForm, setCatForm]     = useState({ name:'', description:'', color:'#6B7280' });

  useEffect(() => { fetchCategories(); fetchSuppliers(); }, []);
  useEffect(() => { fetchData(); }, [page, search, filters]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: r } = await materialService.getAll({ page, limit: 12, search, ...filters });
      if (r.success) { setData(r.data); setPagination(r.pagination); }
    } catch {}
    setLoading(false);
  };

  const fetchCategories = async () => {
    const { data } = await materialService.getCategories();
    if (data.success) setCategories(data.data);
  };

  const fetchSuppliers = async () => {
    const { data } = await supplierService.getAllSimple();
    if (data.success) setSuppliers(data.data);
  };

  const openAdd = () => { setEditing(null); setForm(emptyForm); setModalOpen(true); };
  const openEdit = m => { setEditing(m); setForm({ name:m.name, category_id:m.category_id||'', unit:m.unit, description:m.description||'', cost_per_unit:m.cost_per_unit, minimum_threshold:m.minimum_threshold, reorder_quantity:m.reorder_quantity||'', supplier_id:m.supplier_id||'', specifications:m.specifications||'' }); setModalOpen(true); };

  const handleSave = async () => {
    if (!form.name || !form.unit || form.cost_per_unit === '' || form.minimum_threshold === '') {
      toast.error('Please fill all required fields'); return;
    }
    setSaving(true);
    try {
      const payload = { ...form, cost_per_unit: parseFloat(form.cost_per_unit), minimum_threshold: parseFloat(form.minimum_threshold), reorder_quantity: parseFloat(form.reorder_quantity) || 0 };
      if (editing) {
        const { data } = await materialService.update(editing.id, payload);
        if (data.success) { toast.success('Material updated'); setModalOpen(false); fetchData(); }
      } else {
        const { data } = await materialService.create(payload);
        if (data.success) { toast.success('Material created'); setModalOpen(false); fetchData(); }
      }
    } catch (e) { toast.error(e.message); }
    setSaving(false);
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Delete material "${name}"?`)) return;
    try {
      const { data } = await materialService.remove(id);
      if (data.success) { toast.success('Material deleted'); fetchData(); }
    } catch (e) { toast.error(e.message); }
  };

  const handleCreateCategory = async () => {
    if (!catForm.name) { toast.error('Category name required'); return; }
    try {
      const { data } = await materialService.createCategory(catForm);
      if (data.success) { toast.success('Category created'); fetchCategories(); setCatModal(false); setCatForm({ name:'', description:'', color:'#6B7280' }); }
    } catch (e) { toast.error(e.message); }
  };

  const getStockBadge = (stock, threshold) => {
    if (stock <= 0) return <span className="badge-red">Out of Stock</span>;
    if (stock <= threshold) return <span className="badge-yellow">Low Stock</span>;
    return <span className="badge-green">In Stock</span>;
  };

  const columns = [
    { header: 'Material', key: 'name', render: (v, row) => (
      <div>
        <div className="font-medium text-gray-900 dark:text-white">{v}</div>
        <div className="text-xs text-gray-400">{row.material_code}</div>
      </div>
    )},
    { header: 'Category', key: 'category_name', render: v => v ? (
      <span className="badge-blue">{v}</span>
    ) : <span className="text-gray-400 text-xs">—</span> },
    { header: 'Unit', key: 'unit' },
    { header: 'Cost/Unit', key: 'cost_per_unit', render: v => fmtCurrency(v) },
    { header: 'Min Threshold', key: 'minimum_threshold', render: (v, row) => `${fmtNumber(v)} ${row.unit}` },
    { header: 'Supplier', key: 'supplier_name', render: v => v || '—' },
    { header: 'Status', key: 'is_active', render: v => v ? <span className="badge-green">Active</span> : <span className="badge-red">Inactive</span> },
    ...(canEdit ? [{
      header: 'Actions', key: 'id', render: (_, row) => (
        <div className="flex items-center gap-1">
          <button onClick={() => openEdit(row)} className="p-1.5 text-gray-400 hover:text-primary-600 hover:bg-primary-50 dark:hover:bg-primary-900/20 rounded"><Edit2 size={14} /></button>
          <button onClick={() => handleDelete(row.id, row.name)} className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded"><Trash2 size={14} /></button>
        </div>
      )
    }] : [])
  ];

  const filterDefs = [
    { key: 'category_id', label: 'Category', type: 'select', options: categories.map(c => ({ value: c.id, label: c.name })) },
    { key: 'is_active', label: 'Status', type: 'select', options: [{ value: 'true', label: 'Active' }, { value: 'false', label: 'Inactive' }] },
  ];

  return (
    <div className="space-y-4">
      <div className="page-header">
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2"><Package size={22} /> Materials</h1>
          <p className="text-sm text-gray-500 mt-0.5">{pagination?.total ?? 0} total materials</p>
        </div>
        {canEdit && (
          <div className="flex gap-2">
            <button onClick={() => setCatModal(true)} className="btn-secondary text-xs">+ Category</button>
            <button onClick={openAdd} className="btn-primary"><Plus size={16} /> Add Material</button>
          </div>
        )}
      </div>

      <div className="card">
        <div className="p-4 border-b border-gray-100 dark:border-gray-700 flex flex-wrap gap-3 items-center justify-between">
          <SearchFilter
            value={search} onChange={v => { setSearch(v); setPage(1); }}
            placeholder="Search materials…"
            filters={filterDefs}
            filterValues={filters}
            onFilterChange={(k, v) => { setFilters(f => ({ ...f, [k]: v })); setPage(1); }}
          />
          <button onClick={fetchData} className="btn-secondary text-xs"><RefreshCw size={13} /></button>
        </div>
        <DataTable columns={columns} data={data} loading={loading} />
        <Pagination pagination={pagination} onPageChange={setPage} />
      </div>

      {/* Add/Edit Modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Material' : 'Add New Material'} size="lg"
        footer={<>
          <button onClick={() => setModalOpen(false)} className="btn-secondary">Cancel</button>
          <button onClick={handleSave} disabled={saving} className="btn-primary">{saving ? 'Saving…' : editing ? 'Update' : 'Create'}</button>
        </>}
      >
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2">
            <label className="form-label">Material Name <span className="text-red-500">*</span></label>
            <input className="form-input" value={form.name} onChange={e => setForm(f => ({...f, name: e.target.value}))} placeholder="e.g. OPC 53 Grade Cement" />
          </div>
          <div>
            <label className="form-label">Category</label>
            <select className="form-select" value={form.category_id} onChange={e => setForm(f => ({...f, category_id: e.target.value}))}>
              <option value="">Select category</option>
              {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div>
            <label className="form-label">Unit <span className="text-red-500">*</span></label>
            <input className="form-input" value={form.unit} onChange={e => setForm(f => ({...f, unit: e.target.value}))} placeholder="e.g. Bags, MT, Nos, Sqm" />
          </div>
          <div>
            <label className="form-label">Cost per Unit (₹) <span className="text-red-500">*</span></label>
            <input type="number" min="0" step="0.01" className="form-input" value={form.cost_per_unit} onChange={e => setForm(f => ({...f, cost_per_unit: e.target.value}))} />
          </div>
          <div>
            <label className="form-label">Min Stock Threshold <span className="text-red-500">*</span></label>
            <input type="number" min="0" step="0.01" className="form-input" value={form.minimum_threshold} onChange={e => setForm(f => ({...f, minimum_threshold: e.target.value}))} />
          </div>
          <div>
            <label className="form-label">Reorder Quantity</label>
            <input type="number" min="0" step="0.01" className="form-input" value={form.reorder_quantity} onChange={e => setForm(f => ({...f, reorder_quantity: e.target.value}))} />
          </div>
          <div>
            <label className="form-label">Preferred Supplier</label>
            <select className="form-select" value={form.supplier_id} onChange={e => setForm(f => ({...f, supplier_id: e.target.value}))}>
              <option value="">Select supplier</option>
              {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div className="col-span-2">
            <label className="form-label">Description</label>
            <textarea className="form-input" rows={2} value={form.description} onChange={e => setForm(f => ({...f, description: e.target.value}))} placeholder="Material description..." />
          </div>
          <div className="col-span-2">
            <label className="form-label">Specifications</label>
            <textarea className="form-input" rows={2} value={form.specifications} onChange={e => setForm(f => ({...f, specifications: e.target.value}))} placeholder="Technical specifications..." />
          </div>
        </div>
      </Modal>

      {/* Category Modal */}
      <Modal open={catModal} onClose={() => setCatModal(false)} title="Add Category" size="sm"
        footer={<>
          <button onClick={() => setCatModal(false)} className="btn-secondary">Cancel</button>
          <button onClick={handleCreateCategory} className="btn-primary">Create</button>
        </>}
      >
        <div className="space-y-3">
          <div>
            <label className="form-label">Name <span className="text-red-500">*</span></label>
            <input className="form-input" value={catForm.name} onChange={e => setCatForm(f => ({...f, name: e.target.value}))} placeholder="Category name" />
          </div>
          <div>
            <label className="form-label">Description</label>
            <textarea className="form-input" rows={2} value={catForm.description} onChange={e => setCatForm(f => ({...f, description: e.target.value}))} />
          </div>
          <div>
            <label className="form-label">Color</label>
            <input type="color" className="h-9 w-full rounded cursor-pointer border border-gray-300" value={catForm.color} onChange={e => setCatForm(f => ({...f, color: e.target.value}))} />
          </div>
        </div>
      </Modal>
    </div>
  );
}
