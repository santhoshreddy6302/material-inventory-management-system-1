import api from './api';
export const transferService = {
  getAll:       p => api.get('/transfers', { params: p }),
  create:       d => api.post('/transfers', d),
  updateStatus: (id, d) => api.put(`/transfers/${id}/status`, d),
};
