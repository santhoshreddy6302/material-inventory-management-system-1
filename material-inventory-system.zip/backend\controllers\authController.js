const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/database');
const { success, error, created } = require('../utils/responseHelper');
const { JWT_SECRET, JWT_EXPIRES_IN } = require('../config/config');

const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const [users] = await db.query(
      'SELECT id, name, email, password, role, is_active, phone, avatar FROM users WHERE email = ?',
      [email.toLowerCase().trim()]
    );
    if (!users.length) return error(res, 'Invalid email or password', 401);
    const user = users[0];
    if (!user.is_active) return error(res, 'Account deactivated. Contact administrator.', 401);
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return error(res, 'Invalid email or password', 401);
    await db.query('UPDATE users SET last_login = NOW() WHERE id = ?', [user.id]);
    const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
    const { password: _, ...userData } = user;
    return success(res, { token, user: userData }, 'Login successful');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const register = async (req, res) => {
  try {
    const { name, email, password, role, phone } = req.body;
    const [exists] = await db.query('SELECT id FROM users WHERE email = ?', [email.toLowerCase()]);
    if (exists.length) return error(res, 'Email already registered', 409);
    const hashedPwd = await bcrypt.hash(password, 12);
    const [result] = await db.query(
      'INSERT INTO users (name, email, password, role, phone) VALUES (?, ?, ?, ?, ?)',
      [name.trim(), email.toLowerCase().trim(), hashedPwd, role || 'site_engineer', phone || null]
    );
    const [newUser] = await db.query(
      'SELECT id, name, email, role, phone, created_at FROM users WHERE id = ?',
      [result.insertId]
    );
    return created(res, newUser[0], 'User registered successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getMe = async (req, res) => {
  try {
    const [users] = await db.query(
      'SELECT id, name, email, role, phone, avatar, is_active, last_login, created_at FROM users WHERE id = ?',
      [req.user.id]
    );
    if (!users.length) return error(res, 'User not found', 404);
    return success(res, users[0]);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const updatePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const [users] = await db.query('SELECT password FROM users WHERE id = ?', [req.user.id]);
    const isMatch = await bcrypt.compare(currentPassword, users[0].password);
    if (!isMatch) return error(res, 'Current password is incorrect', 400);
    const hashed = await bcrypt.hash(newPassword, 12);
    await db.query('UPDATE users SET password = ? WHERE id = ?', [hashed, req.user.id]);
    return success(res, null, 'Password updated successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const updateProfile = async (req, res) => {
  try {
    const { name, phone } = req.body;
    await db.query(
      'UPDATE users SET name = ?, phone = ?, updated_at = NOW() WHERE id = ?',
      [name, phone || null, req.user.id]
    );
    const [updated] = await db.query(
      'SELECT id, name, email, role, phone, avatar, is_active FROM users WHERE id = ?',
      [req.user.id]
    );
    return success(res, updated[0], 'Profile updated successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

module.exports = { login, register, getMe, updatePassword, updateProfile };
