import { useState, useEffect } from 'react';
import { Plus, Trash2, RefreshCw } from 'lucide-react';
import { wastageService } from '../../services/wastageService';
import { siteService } from '../../services/siteService';
import { materialService } from '../../services/materialService';
import DataTable from '../../components/common/DataTable';
import Pagination from '../../components/common/Pagination';
import SearchFilter from '../../components/common/SearchFilter';
import Modal from '../../components/common/Modal';
import { fmtDate, fmtCurrency, fmtNumber } from '../../utils/helpers';
import toast from 'react-hot-toast';
import { useAuth } from '../../context/AuthContext';

const REASONS = ['damage','expired','spill','cutting_loss','quality_issue','theft','other'];
const emptyForm = { site_id:'', material_id:'', quantity_wasted:'', wastage_date: new Date().toISOString().split('T')[0], reason:'', description:'', preventable: false, remarks:'' };

export default function WastageList() {
  const { hasRole } = useAuth();
  const [data, setData]             = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading]       = useState(true);
  const [search, setSearch]         = useState('');
  const [filters, setFilters]       = useState({});
  const [page, setPage]             = useState(1);
  const [modal, setModal]           = useState(false);
  const [form, setForm]             = useState(emptyForm);
  const [saving, setSaving]         = useState(false);
  const [sites, setSites]           = useState([]);
  const [materials, setMaterials]   = useState([]);

  useEffect(() => {
    siteService.getAllSimple().then(r => { if(r.data.success) setSites(r.data.data); });
    materialService.getAll({ limit: 200, is_active: 'true' }).then(r => { if(r.data.success) setMaterials(r.data.data); });
  }, []);

  useEffect(() => { fetchData(); }, [page, search, filters]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: r } = await wastageService.getAll({ page, limit: 15, search, ...filters });
      if (r.success) { setData(r.data); setPagination(r.pagination); }
    } catch {}
    setLoading(false);
  };

  const handleSubmit = async () => {
    const { site_id, material_id, quantity_wasted, wastage_date, reason } = form;
    if (!site_id || !material_id || !quantity_wasted || !wastage_date || !reason) { toast.error('Fill all required fields'); return; }
    setSaving(true);
    try {
      const { data: r } = await wastageService.create({ ...form, site_id: parseInt(site_id), material_id: parseInt(material_id), quantity_wasted: parseFloat(quantity_wasted) });
      if (r.success) { toast.success('Wastage recorded'); setModal(false); setForm(emptyForm); fetchData(); }
    } catch (e) { toast.error(e.message); }
    setSaving(false);
  };

  const columns = [
    { header: 'Code', key: 'wastage_code', render: v => <span className="font-mono text-xs text-red-600">{v}</span> },
    { header: 'Date', key: 'wastage_date', render: v => fmtDate(v) },
    { header: 'Site', key: 'site_name' },
    { header: 'Material', key: 'material_name', render: (v, row) => <><div className="font-medium">{v}</div><div className="text-xs text-gray-400">{row.unit}</div></> },
    { header: 'Qty Wasted', key: 'quantity_wasted', render: (v, row) => <span className="font-semibold text-red-600">{fmtNumber(v)} {row.unit}</span> },
    { header: 'Cost', key: 'total_cost', render: v => fmtCurrency(v) },
    { header: 'Reason', key: 'reason', render: v => <span className="badge-orange capitalize">{v?.replace(/_/g,' ')}</span> },
    { header: 'Preventable', key: 'preventable', render: v => v ? <span className="badge-yellow">Yes</span> : <span className="badge-gray">No</span> },
    { header: 'By', key: 'recorded_by_name' },
  ];

  const filterDefs = [
    { key: 'site_id', label: 'Site', type: 'select', options: sites.map(s => ({ value: s.id, label: s.name })) },
    { key: 'reason', label: 'Reason', type: 'select', options: REASONS.map(r => ({ value: r, label: r.replace(/_/g,' ') })) },
    { key: 'from_date', label: 'From Date', type: 'date' },
    { key: 'to_date', label: 'To Date', type: 'date' },
  ];

  return (
    <div className="space-y-4">
      <div className="page-header">
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2"><Trash2 size={22} />Wastage Records</h1>
          <p className="text-sm text-gray-500">{pagination?.total ?? 0} wastage entries</p>
        </div>
        {hasRole('admin','site_engineer','project_manager') && (
          <button onClick={() => setModal(true)} className="btn-primary"><Plus size={15} /> Record Wastage</button>
        )}
      </div>

      <div className="card">
        <div className="p-4 border-b border-gray-100 dark:border-gray-700 flex flex-wrap gap-3 items-center justify-between">
          <SearchFilter value={search} onChange={v=>{setSearch(v);setPage(1);}} placeholder="Search wastage records…"
            filters={filterDefs} filterValues={filters} onFilterChange={(k,v)=>{setFilters(f=>({...f,[k]:v}));setPage(1);}} />
          <button onClick={fetchData} className="btn-secondary text-xs"><RefreshCw size={13} /></button>
        </div>
        <DataTable columns={columns} data={data} loading={loading} />
        <Pagination pagination={pagination} onPageChange={setPage} />
      </div>

      <Modal open={modal} onClose={() => setModal(false)} title="Record Wastage" size="lg"
        footer={<>
          <button onClick={() => setModal(false)} className="btn-secondary">Cancel</button>
          <button onClick={handleSubmit} disabled={saving} className="btn-primary btn-danger">{saving ? 'Saving…' : 'Record Wastage'}</button>
        </>}
      >
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="form-label">Site <span className="text-red-500">*</span></label>
            <select className="form-select" value={form.site_id} onChange={e => setForm(f=>({...f,site_id:e.target.value}))}>
              <option value="">Select site</option>
              {sites.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div>
            <label className="form-label">Material <span className="text-red-500">*</span></label>
            <select className="form-select" value={form.material_id} onChange={e => setForm(f=>({...f,material_id:e.target.value}))}>
              <option value="">Select material</option>
              {materials.map(m => <option key={m.id} value={m.id}>{m.name} ({m.unit})</option>)}
            </select>
          </div>
          <div>
            <label className="form-label">Quantity Wasted <span className="text-red-500">*</span></label>
            <input type="number" min="0.01" step="0.01" className="form-input" value={form.quantity_wasted} onChange={e => setForm(f=>({...f,quantity_wasted:e.target.value}))} />
          </div>
          <div>
            <label className="form-label">Wastage Date <span className="text-red-500">*</span></label>
            <input type="date" className="form-input" value={form.wastage_date} onChange={e => setForm(f=>({...f,wastage_date:e.target.value}))} />
          </div>
          <div>
            <label className="form-label">Reason <span className="text-red-500">*</span></label>
            <select className="form-select" value={form.reason} onChange={e => setForm(f=>({...f,reason:e.target.value}))}>
              <option value="">Select reason</option>
              {REASONS.map(r => <option key={r} value={r}>{r.replace(/_/g,' ')}</option>)}
            </select>
          </div>
          <div className="flex items-center gap-2 mt-6">
            <input type="checkbox" id="preventable" checked={form.preventable} onChange={e => setForm(f=>({...f,preventable:e.target.checked}))} className="rounded" />
            <label htmlFor="preventable" className="text-sm text-gray-700 dark:text-gray-300">Was this wastage preventable?</label>
          </div>
          <div className="col-span-2">
            <label className="form-label">Description</label>
            <textarea className="form-input" rows={2} value={form.description} onChange={e => setForm(f=>({...f,description:e.target.value}))} placeholder="Describe the wastage..." />
          </div>
        </div>
        <div className="mt-3 p-3 bg-red-50 dark:bg-red-900/20 rounded-lg text-xs text-red-700 dark:text-red-400">
          ⚠️ Recording wastage will deduct from site inventory and log the loss cost.
        </div>
      </Modal>
    </div>
  );
}
