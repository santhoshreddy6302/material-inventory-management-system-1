import { useState, useEffect } from 'react';
import { Bell, CheckCircle, AlertTriangle, RefreshCw, CheckCheck } from 'lucide-react';
import { alertService } from '../../services/alertService';
import DataTable from '../../components/common/DataTable';
import Pagination from '../../components/common/Pagination';
import SearchFilter from '../../components/common/SearchFilter';
import { fmtDateTime, getStatusColor } from '../../utils/helpers';
import toast from 'react-hot-toast';

const SEVERITY_COLORS = { critical:'text-red-600 bg-red-50', high:'text-orange-600 bg-orange-50', medium:'text-yellow-600 bg-yellow-50', low:'text-blue-600 bg-blue-50' };
const SEVERITY_ICONS  = { critical:'🔴', high:'🟠', medium:'🟡', low:'🔵' };

export default function AlertsPage() {
  const [data, setData]             = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading]       = useState(true);
  const [filters, setFilters]       = useState({ is_resolved: 'false' });
  const [page, setPage]             = useState(1);

  useEffect(() => { fetchData(); }, [page, filters]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: r } = await alertService.getAll({ page, limit: 15, ...filters });
      if (r.success) { setData(r.data); setPagination(r.pagination); }
    } catch {}
    setLoading(false);
  };

  const handleMarkAllRead = async () => {
    try {
      await alertService.markAllRead();
      toast.success('All alerts marked as read');
      fetchData();
    } catch {}
  };

  const handleResolve = async (id) => {
    try {
      await alertService.resolve(id);
      toast.success('Alert resolved');
      fetchData();
    } catch (e) { toast.error(e.message); }
  };

  const columns = [
    { header: 'Severity', key: 'severity', render: v => (
      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold ${SEVERITY_COLORS[v] || 'text-gray-600 bg-gray-50'}`}>
        {SEVERITY_ICONS[v]} {v}
      </span>
    )},
    { header: 'Type', key: 'type', render: v => <span className="badge-blue capitalize">{v?.replace(/_/g,' ')}</span> },
    { header: 'Title', key: 'title', render: (v, row) => (
      <div>
        <div className={`font-medium text-sm ${!row.is_read ? 'text-gray-900 dark:text-white' : 'text-gray-500'}`}>{v}</div>
        <div className="text-xs text-gray-400 mt-0.5">{row.message}</div>
      </div>
    )},
    { header: 'Material', key: 'material_name', render: (v, row) => v ? (
      <div><div className="text-sm">{v}</div><div className="text-xs text-gray-400">{row.site_name}</div></div>
    ) : (row.po_number ? `PO: ${row.po_number}` : '—') },
    { header: 'Time', key: 'created_at', render: v => <span className="text-xs text-gray-500">{fmtDateTime(v)}</span> },
    { header: 'Read', key: 'is_read', render: v => v ? <span className="badge-green">Read</span> : <span className="badge-yellow">Unread</span> },
    { header: 'Action', key: 'id', render: (id, row) => !row.is_resolved ? (
      <button onClick={() => handleResolve(id)} className="btn-secondary text-xs py-1 px-2 flex items-center gap-1">
        <CheckCircle size={12} /> Resolve
      </button>
    ) : <span className="badge-green flex items-center gap-1 w-fit"><CheckCircle size={10}/>Resolved</span> }
  ];

  const filterDefs = [
    { key: 'type', label: 'Type', type: 'select', options: ['low_stock','out_of_stock','po_approval','delivery_due','budget_exceeded','high_wastage'].map(t => ({ value: t, label: t.replace(/_/g,' ') })) },
    { key: 'severity', label: 'Severity', type: 'select', options: ['critical','high','medium','low'].map(s => ({ value: s, label: s })) },
    { key: 'is_read', label: 'Read Status', type: 'select', options: [{ value:'false', label:'Unread' }, { value:'true', label:'Read' }] },
    { key: 'is_resolved', label: 'Resolved', type: 'select', options: [{ value:'false', label:'Active' }, { value:'true', label:'Resolved' }] },
  ];

  const unreadCount = data.filter(a => !a.is_read).length;

  return (
    <div className="space-y-4">
      <div className="page-header">
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <Bell size={22} /> Alerts
            {unreadCount > 0 && <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">{unreadCount}</span>}
          </h1>
          <p className="text-sm text-gray-500">{pagination?.total ?? 0} total alerts</p>
        </div>
        <button onClick={handleMarkAllRead} className="btn-secondary text-sm"><CheckCheck size={15} /> Mark All Read</button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {Object.entries({ critical: '🔴', high: '🟠', medium: '🟡', low: '🔵' }).map(([sev, icon]) => {
          const count = data.filter(a => a.severity === sev && !a.is_resolved).length;
          return (
            <div key={sev} className={`card p-4 border-l-4 ${sev === 'critical' ? 'border-l-red-500' : sev === 'high' ? 'border-l-orange-500' : sev === 'medium' ? 'border-l-yellow-500' : 'border-l-blue-500'}`}>
              <div className="text-2xl font-bold text-gray-900 dark:text-white">{icon} {count}</div>
              <div className="text-xs text-gray-500 capitalize mt-1">{sev} priority</div>
            </div>
          );
        })}
      </div>

      <div className="card">
        <div className="p-4 border-b border-gray-100 dark:border-gray-700 flex flex-wrap gap-3 items-center justify-between">
          <SearchFilter value="" onChange={() => {}} placeholder="Filter alerts…"
            filters={filterDefs} filterValues={filters} onFilterChange={(k,v) => { setFilters(f => ({ ...f, [k]: v })); setPage(1); }} />
          <button onClick={fetchData} className="btn-secondary text-xs"><RefreshCw size={13} /></button>
        </div>
        <DataTable columns={columns} data={data} loading={loading} emptyMessage="No alerts found" />
        <Pagination pagination={pagination} onPageChange={setPage} />
      </div>
    </div>
  );
}
