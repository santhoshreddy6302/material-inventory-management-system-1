const express = require('express');
const router = express.Router();
const { getAll, create, updateStatus } = require('../controllers/transferController');
const { authenticate, authorize } = require('../middleware/auth');
router.use(authenticate);
router.get('/', getAll);
router.post('/', authorize('admin','site_engineer','project_manager'), create);
router.put('/:id/status', authorize('admin','project_manager'), updateStatus);
module.exports = router;
