const express = require('express');
const router = express.Router();
const { getAll, getSiteInventory, getTransactions, adjustStock } = require('../controllers/inventoryController');
const { authenticate, authorize } = require('../middleware/auth');

router.use(authenticate);
router.get('/', getAll);
router.get('/transactions', getTransactions);
router.get('/site/:site_id', getSiteInventory);
router.post('/adjust', authorize('admin', 'procurement_staff', 'site_engineer'), adjustStock);

module.exports = router;
