import api from './api';
export const milestoneService = {
  getAll: p => api.get('/milestones', { params: p }),
  getOne: id => api.get(`/milestones/${id}`),
  create: d => api.post('/milestones', d),
  update: (id, d) => api.put(`/milestones/${id}`, d),
  remove: id => api.delete(`/milestones/${id}`),
};
