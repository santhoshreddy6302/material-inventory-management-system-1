import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard, Package, Warehouse, ShoppingCart, Wrench, Trash2,
  FolderKanban, MapPin, Truck, FileBarChart, Bell, Users, ArrowLeftRight,
  HardHat, ChevronDown, ChevronRight, DollarSign, MessageSquare, Target,
  Briefcase, Settings, BarChart
} from 'lucide-react';
import { useState } from 'react';

const navItems = [
  { to: '/', icon: LayoutDashboard, label: 'Dashboard', exact: true },
  { to: '/materials', icon: Package, label: 'Materials' },
  {
    label: 'Inventory', icon: Warehouse, children: [
      { to: '/inventory',  label: 'Stock Overview' },
      { to: '/transfers',  label: 'Stock Transfers' },
    ]
  },
  { to: '/purchase-orders', icon: ShoppingCart, label: 'Purchase Orders' },
  { to: '/usage',    icon: Wrench, label: 'Material Usage' },
  { to: '/wastage',  icon: Trash2, label: 'Wastage Records' },
  { to: '/projects', icon: FolderKanban, label: 'Projects' },
  { to: '/sites',    icon: MapPin,        label: 'Sites' },
  { to: '/suppliers',icon: Truck,         label: 'Suppliers' },
  { to: '/labour',         icon: Users,         label: 'Labour' },
  { to: '/expenses',       icon: DollarSign,    label: 'Expenses' },
  { to: '/enquiries',      icon: MessageSquare, label: 'Enquiries' },
  { to: '/milestones',     icon: Target,        label: 'Milestones' },
  { to: '/subcontractors', icon: Briefcase,     label: 'Subcontractors' },
  { to: '/machinery',      icon: Settings,      label: 'Machinery' },
  { to: '/progress',       icon: BarChart,      label: 'Progress' },
  { to: '/reports',  icon: FileBarChart,  label: 'Reports' },
  { to: '/alerts',   icon: Bell,          label: 'Alerts' },
];

function NavGroup({ item }) {
  const [open, setOpen] = useState(false);
  const Icon = item.icon;
  return (
    <div>
      <button
        onClick={() => setOpen(o => !o)}
        className="sidebar-link w-full justify-between"
      >
        <span className="flex items-center gap-3">
          <Icon size={18} />
          <span>{item.label}</span>
        </span>
        {open ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
      </button>
      {open && (
        <div className="ml-7 mt-1 space-y-1">
          {item.children.map(child => (
            <NavLink
              key={child.to} to={child.to}
              className={({ isActive }) => `sidebar-link text-xs ${isActive ? 'active' : ''}`}
            >
              {child.label}
            </NavLink>
          ))}
        </div>
      )}
    </div>
  );
}

export default function Sidebar({ open, onClose }) {
  const { user, isAdmin } = useAuth();

  return (
    <>
      {/* Mobile overlay */}
      {open && <div className="fixed inset-0 z-20 bg-black/50 lg:hidden" onClick={onClose} />}

      <aside className={`
        fixed top-0 left-0 z-30 h-full w-64 flex flex-col
        bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700
        transform transition-transform duration-300 ease-in-out
        ${open ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0
      `}>
        {/* Brand */}
        <div className="flex items-center gap-3 px-5 py-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex-shrink-0 w-9 h-9 bg-primary-600 rounded-lg flex items-center justify-center">
            <HardHat size={20} className="text-white" />
          </div>
          <div>
            <div className="text-xs font-bold text-gray-900 dark:text-white leading-tight">AVINASH KANAPARTHI INFRA</div>
            <div className="text-[10px] text-gray-500 dark:text-gray-400">PRIVATE LIMITED</div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {navItems.map(item =>
            item.children
              ? <NavGroup key={item.label} item={item} />
              : (
                <NavLink
                  key={item.to} to={item.to}
                  end={item.exact}
                  className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
                  onClick={onClose}
                >
                  <item.icon size={18} />
                  <span>{item.label}</span>
                </NavLink>
              )
          )}
          {isAdmin() && (
            <NavLink
              to="/users"
              className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
              onClick={onClose}
            >
              <Users size={18} />
              <span>User Management</span>
            </NavLink>
          )}
        </nav>

        {/* User info */}
        <div className="p-3 border-t border-gray-200 dark:border-gray-700">
          <NavLink to="/profile" onClick={onClose} className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
            <div className="w-8 h-8 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center text-primary-700 dark:text-primary-300 text-sm font-bold">
              {user?.name?.charAt(0)?.toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-semibold text-gray-900 dark:text-white truncate">{user?.name}</div>
              <div className="text-xs text-gray-500 dark:text-gray-400 capitalize truncate">
                {user?.role?.replace(/_/g, ' ')}
              </div>
            </div>
          </NavLink>
        </div>
      </aside>
    </>
  );
}
