import api from './api';
export const materialService = {
  getAll:          p => api.get('/materials', { params: p }),
  getOne:          id => api.get(`/materials/${id}`),
  create:          d => api.post('/materials', d),
  update:          (id, d) => api.put(`/materials/${id}`, d),
  remove:          id => api.delete(`/materials/${id}`),
  getLowStock:     () => api.get('/materials/low-stock'),
  getCategories:   () => api.get('/materials/categories'),
  createCategory:  d => api.post('/materials/categories', d),
};
