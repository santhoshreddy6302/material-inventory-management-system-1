const db = require('../config/database');
const { success, created, error, paginated } = require('../utils/responseHelper');
const { parseFilters } = require('../utils/helpers');

const getAll = async (req, res) => {
  try {
    const { page, limit, offset } = parseFilters(req.query);
    const [countResult] = await db.query('SELECT COUNT(*) as total FROM site_progress');
    const [rows] = await db.query('SELECT * FROM site_progress LIMIT ? OFFSET ?', [limit, offset]);
    return paginated(res, rows, countResult[0].total, page, limit);
  } catch (err) { return error(res, err.message, 500); }
};
const getOne = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM site_progress WHERE id = ?', [req.params.id]);
    if (!rows.length) return error(res, 'Not found', 404);
    return success(res, rows[0]);
  } catch (err) { return error(res, err.message, 500); }
};
const create = async (req, res) => {
  try {
    const fields = Object.keys(req.body);
    const values = Object.values(req.body);
    const placeholders = fields.map(() => '?').join(', ');
    const [result] = await db.query(`INSERT INTO site_progress (${fields.join(', ')}) VALUES (${placeholders})`, values);
    return created(res, { id: result.insertId, ...req.body }, 'Created successfully');
  } catch (err) { return error(res, err.message, 500); }
};
const update = async (req, res) => {
  try {
    const fields = Object.keys(req.body);
    const setClause = fields.map(f => `${f}=?`).join(', ');
    await db.query(`UPDATE site_progress SET ${setClause} WHERE id=?`, [...Object.values(req.body), req.params.id]);
    return success(res, { id: req.params.id, ...req.body }, 'Updated successfully');
  } catch (err) { return error(res, err.message, 500); }
};
const remove = async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM site_progress WHERE id = ?', [req.params.id]);
    if (!result.affectedRows) return error(res, 'Not found', 404);
    return success(res, null, 'Deleted successfully');
  } catch (err) { return error(res, err.message, 500); }
};
module.exports = { getAll, getOne, create, update, remove };
