const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const { getAll, create, getStats } = require('../controllers/usageController');
const { authenticate, authorize } = require('../middleware/auth');
const validate = require('../middleware/validate');

router.use(authenticate);
router.get('/', getAll);
router.get('/stats', getStats);
router.post('/', authorize('admin','site_engineer','project_manager'), [
  body('site_id').isInt(),
  body('material_id').isInt(),
  body('quantity_used').isFloat({ min: 0.01 }),
  body('usage_date').isDate()
], validate, create);

module.exports = router;
