# 🏗️ Material Inventory Management System
### AVINASH KANAPARTHI INFRA PRIVATE LIMITED

A production-ready, full-stack Material Inventory Management System for construction companies — built with React 18 + Vite, Node.js + Express, and SQLite (MySQL-compatible).

---

## ⚡ Quick Start (3 Steps)

```bash
# Step 1 — Install dependencies
npm install
npm run install:all

# Step 2 — Seed the database with demo data
npm run seed

# Step 3 — Start development servers
npm run dev
```

Open **http://localhost:5173**

### 🔑 Demo Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@constco.com | Admin@123 |
| Project Manager | pm@constco.com | Admin@123 |
| Site Engineer | engineer@constco.com | Admin@123 |
| Procurement Staff | procurement@constco.com | Admin@123 |
| Accounts Staff | accounts@constco.com | Admin@123 |

---

## ✨ Features

| Module | Description |
|---|---|
| **Dashboard** | Real-time KPI cards, 4 interactive charts, low stock alerts, recent activity feed |
| **Authentication** | JWT-based login, role-based access control (RBAC), protected routes |
| **Materials** | CRUD with categories, threshold management, supplier linking, stock badges |
| **Inventory** | Site-wise stock overview, immutable ledger, adjustments, stock transfers |
| **Purchase Orders** | Create → Approve → Receive workflow with auto inventory update |
| **Material Usage** | Record consumption, auto-deduct inventory, cost tracking per site |
| **Wastage Records** | Log by reason, preventability flag, cost analysis |
| **Projects & Sites** | Multi-project multi-site management with progress tracking |
| **Suppliers** | Full supplier database with purchase history and spend tracking |
| **Labour** | Labour resource management and wage tracking |
| **Expenses** | Project expense tracking with categories |
| **Milestones** | Payment milestone tracking per project |
| **Machinery** | Equipment and machinery assignments at sites |
| **Subcontractors** | Manage subcontractor tasks and costs |
| **Enquiries** | Client enquiry management |
| **Progress** | Site progress tracking and reporting |
| **Reports** | Generate and export reports in CSV, Excel formats |
| **Alerts** | Automatic low-stock & high-wastage notifications with bell icon |
| **User Management** | 5 roles with full RBAC, admin panel for user CRUD |
| **Profile** | User profile editing with avatar support |

---

## 🛠️ Technology Stack

### Frontend
- **React 18** + **Vite** — Fast development and builds
- **Tailwind CSS 3** — Utility-first styling with dark mode
- **React Router v6** — Client-side routing with protected routes
- **Chart.js 4** + **react-chartjs-2** — Interactive data visualizations
- **Axios** — HTTP client with interceptors
- **Lucide React** — Consistent icon library
- **React Hot Toast** — Toast notification system

### Backend
- **Node.js** + **Express.js** — RESTful API server
- **SQLite** (MySQL-compatible adapter) — Database with full MySQL syntax support
- **JWT (jsonwebtoken)** — Stateless authentication
- **bcryptjs** — Password hashing
- **ExcelJS** — Excel report generation
- **PDFKit** — PDF report generation
- **Winston** — Structured logging
- **Helmet** — Security headers
- **Morgan** — HTTP request logging

### Database
- **SQLite** (default, zero-configuration) — auto-creates on seed
- **MySQL 8+** compatible schema at `database/material_inventory.sql`

---

## 📁 Project Structure

```
material-inventory-final/
│
├── backend/                    # Node.js + Express API Server
│   ├── app.js                  # Express app setup with all middleware
│   ├── server.js               # HTTP server entry point
│   ├── .env                    # Environment variables (configure this)
│   ├── config/
│   │   ├── database.js         # SQLite connection + MySQL translator
│   │   └── config.js           # App configuration constants
│   ├── controllers/            # Business logic handlers (22 controllers)
│   │   ├── authController.js
│   │   ├── dashboardController.js
│   │   ├── materialController.js
│   │   ├── inventoryController.js
│   │   ├── purchaseController.js
│   │   ├── usageController.js
│   │   ├── wastageController.js
│   │   ├── projectController.js
│   │   ├── siteController.js
│   │   ├── supplierController.js
│   │   ├── reportController.js
│   │   ├── alertController.js
│   │   ├── transferController.js
│   │   ├── userController.js
│   │   ├── labourController.js
│   │   ├── expenseController.js
│   │   ├── enquiryController.js
│   │   ├── milestoneController.js
│   │   ├── subcontractorController.js
│   │   ├── machineryController.js
│   │   ├── progressController.js
│   │   └── aiController.js
│   ├── routes/                 # Express routers (22 route files)
│   ├── middleware/             # Auth, error handler, validation
│   ├── services/               # Business services
│   ├── utils/                  # Logger, response helpers
│   ├── database/               # SQLite setup and seeding
│   │   ├── sqlite_setup.js     # Database schema setup + translation
│   │   └── seed.js             # Demo data seeder
│   └── uploads/                # Uploaded files storage
│
├── frontend/                   # React 18 + Vite SPA
│   ├── index.html
│   ├── vite.config.js
│   ├── tailwind.config.js
│   ├── .env                    # Frontend environment variables
│   └── src/
│       ├── App.jsx             # Root component with routing
│       ├── main.jsx            # React entry point
│       ├── index.css           # Global styles + Tailwind utilities
│       ├── components/
│       │   ├── common/         # Reusable UI (DataTable, Modal, Pagination, etc.)
│       │   └── dashboard/      # Dashboard-specific (StatsCard, ChartCard)
│       ├── context/
│       │   ├── AuthContext.jsx # JWT auth state management
│       │   └── ThemeContext.jsx # Dark/light mode
│       ├── layouts/
│       │   ├── MainLayout.jsx  # App shell
│       │   ├── Sidebar.jsx     # Navigation sidebar
│       │   └── Navbar.jsx      # Top navigation bar
│       ├── pages/              # 20+ page components
│       │   ├── Dashboard.jsx
│       │   ├── Login.jsx
│       │   ├── Profile.jsx
│       │   ├── Users.jsx
│       │   ├── materials/
│       │   ├── inventory/
│       │   ├── purchase/
│       │   ├── usage/
│       │   ├── wastage/
│       │   ├── projects/
│       │   ├── sites/
│       │   ├── suppliers/
│       │   ├── reports/
│       │   ├── alerts/
│       │   ├── labour/
│       │   ├── expenses/
│       │   ├── enquiries/
│       │   ├── milestones/
│       │   ├── subcontractors/
│       │   ├── machinery/
│       │   └── progress/
│       ├── services/           # Axios API clients (21 service files)
│       ├── hooks/              # Custom React hooks
│       └── utils/              # Helpers, formatters, constants
│
├── database/
│   ├── material_inventory.sql  # Complete MySQL schema (23 tables + seed data)
│   └── material_inventory.db   # SQLite database (auto-generated by seed)
│
├── docs/
│   ├── README.md               # Quickstart documentation
│   ├── Setup_Guide.md          # Detailed setup instructions
│   ├── API_Documentation.md    # REST API reference
│   ├── ER_Diagram.md           # Entity-Relationship diagram
│   └── Project_Report.md       # Internship project report
│
├── package.json                # Root convenience scripts
└── README.md                   # This file
```

---

## 🗄️ Database Schema (23 Tables)

| Table | Description |
|---|---|
| `users` | System users with roles |
| `projects` | Construction projects |
| `sites` | Project sites / work locations |
| `material_categories` | Material type categories |
| `suppliers` | Supplier master data |
| `materials` | Material master with thresholds |
| `inventory` | Current site-wise stock levels |
| `inventory_transactions` | Immutable stock ledger |
| `purchase_orders` | PO headers |
| `purchase_order_items` | PO line items |
| `material_usage` | Material consumption records |
| `wastage_records` | Material wastage tracking |
| `stock_transfers` | Inter-site stock transfers |
| `alerts` | Low stock and other alerts |
| `activity_logs` | Audit trail for all actions |
| `site_progress` | Site completion percentage |
| `equipment_machinery` | Equipment tracking |
| `subcontractor_tasks` | Subcontractor work orders |
| `payment_milestones` | Project payment milestones |
| `client_enquiries` | Client inquiry records |
| `project_expenses` | Project expense tracking |
| `labour_wages` | Labour wage records |
| `labour_attendance` | Daily attendance tracking |

---

## 🔌 REST API Endpoints

### Authentication
```
POST   /api/auth/login          — Login with email/password
POST   /api/auth/register       — Register new user (admin only)
GET    /api/auth/me             — Get current user profile
PUT    /api/auth/password       — Change password
```

### Core Resources (all support CRUD)
```
/api/materials          — Material master management
/api/inventory          — Stock levels and ledger
/api/purchase-orders    — Purchase order workflow
/api/usage              — Material usage records
/api/wastage            — Wastage records
/api/projects           — Project management
/api/sites              — Site management
/api/suppliers          — Supplier management
/api/alerts             — Alert notifications
/api/transfers          — Stock transfers
/api/dashboard          — Dashboard statistics
/api/reports            — Report generation + export
/api/users              — User management (admin)
```

---

## 🔐 Environment Configuration

### `backend/.env`
```env
PORT=5000
NODE_ENV=development
FRONTEND_URL=http://localhost:5173

# Database (SQLite by default — no setup needed)
# For MySQL: Update database.js to use mysql2 pool
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_password_here
DB_NAME=material_inventory

JWT_SECRET=mims_super_secret_jwt_key_change_in_production_min_32_chars
JWT_EXPIRES_IN=7d
```

### `frontend/.env`
```env
VITE_API_URL=http://localhost:5000/api
VITE_APP_NAME=Material Inventory System
```

---

## 🚀 Deployment

### Frontend → Vercel
```bash
cd frontend
npm run build
# Deploy the dist/ folder to Vercel
# Set VITE_API_URL to your Render backend URL
```

### Backend → Render
```bash
# 1. Push backend/ to a GitHub repository
# 2. Create a new Web Service on Render
# 3. Set build command: npm install
# 4. Set start command: node server.js
# 5. Add environment variables in Render dashboard
# 6. Set FRONTEND_URL to your Vercel URL
```

### Database → MySQL (Production)
```bash
# Import schema to MySQL:
mysql -u root -p < database/material_inventory.sql

# Update backend/.env with MySQL credentials
# Update backend/config/database.js to use mysql2 pool instead of SQLite
```

---

## 👥 User Roles & Permissions

| Module | Admin | Project Mgr | Site Engineer | Procurement | Accounts |
|--------|-------|-------------|---------------|-------------|----------|
| Dashboard | ✅ | ✅ | ✅ | ✅ | ✅ |
| Materials | CRUD | View | View | CRUD | View |
| Inventory | Full | View | Entry | View | View |
| Purchase Orders | Full | Approve | View | Create | View |
| Usage/Wastage | Full | View | CRUD | View | View |
| Projects/Sites | Full | CRUD | View | View | View |
| Suppliers | Full | View | View | CRUD | View |
| Reports | Full | Full | View | Full | Full |
| User Management | Full | ❌ | ❌ | ❌ | ❌ |

---

## 📋 Internship Project Details

**Company:** AVINASH KANAPARTHI INFRA PRIVATE LIMITED  
**Project:** Material Inventory Management System  
**Stack:** React.js + Vite + Tailwind CSS + Node.js + Express + SQLite/MySQL  
**Version:** 1.0.0  
**Year:** 2024-2025

---

© 2025 AVINASH KANAPARTHI INFRA PRIVATE LIMITED. All rights reserved.
