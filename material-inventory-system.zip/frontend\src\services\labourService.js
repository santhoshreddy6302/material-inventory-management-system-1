import api from './api';
export const labourService = {
  getAll: p => api.get('/labour', { params: p }),
  getOne: id => api.get(`/labour/${id}`),
  create: d => api.post('/labour', d),
  update: (id, d) => api.put(`/labour/${id}`, d),
  remove: id => api.delete(`/labour/${id}`),
};
