import api from './api';
export const usageService = {
  getAll:   p => api.get('/usage', { params: p }),
  create:   d => api.post('/usage', d),
  getStats: p => api.get('/usage/stats', { params: p }),
};
