const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const logger = require('../utils/logger');

const dbPath = path.join(__dirname, '../../database/material_inventory.db');

// Main shared connection
const sharedDb = new sqlite3.Database(dbPath);
sharedDb.run('PRAGMA foreign_keys = ON;');

// SQL translation helper
function translateSQL(sql) {
  if (!sql) return sql;
  let newSql = sql;
  
  // Translate DATE_FORMAT
  newSql = newSql.replace(/DATE_FORMAT\s*\(\s*([^,]+)\s*,\s*'([^']+)'\s*\)/gi, (match, expr, format) => {
    return `strftime('${format}', ${expr.trim()})`;
  });

  // DATE_SUB(NOW(), INTERVAL x DAY)
  newSql = newSql.replace(/DATE_SUB\s*\(\s*NOW\s*\(\s*\)\s*,\s*INTERVAL\s*(\d+)\s+DAY\s*\)/gi, (match, val) => {
    return `datetime('now', '-${val} day')`;
  });

  // DATE_SUB(NOW(), INTERVAL x MONTH)
  newSql = newSql.replace(/DATE_SUB\s*\(\s*NOW\s*\(\s*\)\s*,\s*INTERVAL\s*(\d+)\s+MONTH\s*\)/gi, (match, val) => {
    return `datetime('now', '-${val} month')`;
  });

  // DATE_SUB(CURDATE(), INTERVAL x DAY)
  newSql = newSql.replace(/DATE_SUB\s*\(\s*CURDATE\s*\(\s*\)\s*,\s*INTERVAL\s*(\d+)\s+DAY\s*\)/gi, (match, val) => {
    return `date('now', '-${val} day')`;
  });

  // NOW() -> datetime('now')
  newSql = newSql.replace(/NOW\s*\(\s*\)/gi, "datetime('now')");
  
  // CURDATE() -> date('now')
  newSql = newSql.replace(/CURDATE\s*\(\s*\)/gi, "date('now')");

  // INSERT IGNORE INTO -> INSERT OR IGNORE INTO
  newSql = newSql.replace(/INSERT\s+IGNORE\s+INTO/gi, "INSERT OR IGNORE INTO");

  // ON DUPLICATE KEY UPDATE -> ON CONFLICT(type, material_id, site_id) DO UPDATE SET ...
  if (newSql.includes('ON DUPLICATE KEY UPDATE')) {
    newSql = newSql.replace(/ON\s+DUPLICATE\s+KEY\s+UPDATE\s+(.+)$/gi, (match, updateClause) => {
      let sqLiteUpdateClause = updateClause.replace(/NOW\s*\(\s*\)/gi, "datetime('now')");
      return `ON CONFLICT(type, material_id, site_id) DO UPDATE SET ${sqLiteUpdateClause}`;
    });
  }

  return newSql;
}

// Connection class for getConnection()
class SqliteConnection {
  constructor(dbInstance) {
    this.db = dbInstance;
  }

  query(sql, params = []) {
    const translated = translateSQL(sql);
    const isSelect = /^\s*(SELECT|PRAGMA|EXPLAIN|WITH)/i.test(translated);
    
    return new Promise((resolve, reject) => {
      if (isSelect) {
        this.db.all(translated, params, (err, rows) => {
          if (err) return reject(err);
          resolve([rows, []]);
        });
      } else {
        this.db.run(translated, params, function(err) {
          if (err) return reject(err);
          resolve([{
            insertId: this.lastID,
            affectedRows: this.changes,
            changedRows: this.changes
          }, []]);
        });
      }
    });
  }

  execute(sql, params = []) {
    return this.query(sql, params);
  }

  beginTransaction() {
    return new Promise((resolve, reject) => {
      this.db.run('BEGIN TRANSACTION', (err) => {
        if (err) reject(err);
        else resolve();
      });
    });
  }

  commit() {
    return new Promise((resolve, reject) => {
      this.db.run('COMMIT', (err) => {
        if (err) reject(err);
        else resolve();
      });
    });
  }

  rollback() {
    return new Promise((resolve, reject) => {
      this.db.run('ROLLBACK', (err) => {
        if (err) reject(err);
        else resolve();
      });
    });
  }

  release() {
    this.db.close();
  }
}

// Pool interface
const pool = {
  query(sql, params = []) {
    const translated = translateSQL(sql);
    const isSelect = /^\s*(SELECT|PRAGMA|EXPLAIN|WITH)/i.test(translated);
    
    return new Promise((resolve, reject) => {
      if (isSelect) {
        sharedDb.all(translated, params, (err, rows) => {
          if (err) return reject(err);
          resolve([rows, []]);
        });
      } else {
        sharedDb.run(translated, params, function(err) {
          if (err) return reject(err);
          resolve([{
            insertId: this.lastID,
            affectedRows: this.changes,
            changedRows: this.changes
          }, []]);
        });
      }
    });
  },

  execute(sql, params = []) {
    return this.query(sql, params);
  },

  getConnection() {
    return new Promise((resolve, reject) => {
      const connDb = new sqlite3.Database(dbPath, (err) => {
        if (err) return reject(err);
        connDb.run('PRAGMA foreign_keys = ON;', (pragmaErr) => {
          if (pragmaErr) return reject(pragmaErr);
          resolve(new SqliteConnection(connDb));
        });
      });
    });
  }
};

// Test connection
pool.getConnection()
  .then(conn => {
    logger.info('✅ SQLite Database connected successfully (MySQL Emulator)');
    conn.release();
  })
  .catch(err => {
    logger.error('❌ SQLite connection failed:', err.message);
  });

module.exports = pool;
