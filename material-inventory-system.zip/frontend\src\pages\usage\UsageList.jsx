import { useState, useEffect } from 'react';
import { Plus, Wrench, RefreshCw } from 'lucide-react';
import { usageService } from '../../services/usageService';
import { siteService } from '../../services/siteService';
import { materialService } from '../../services/materialService';
import DataTable from '../../components/common/DataTable';
import Pagination from '../../components/common/Pagination';
import SearchFilter from '../../components/common/SearchFilter';
import Modal from '../../components/common/Modal';
import { fmtDate, fmtCurrency, fmtNumber } from '../../utils/helpers';
import toast from 'react-hot-toast';
import { useAuth } from '../../context/AuthContext';

const emptyForm = { site_id:'', material_id:'', quantity_used:'', usage_date: new Date().toISOString().split('T')[0], purpose:'', work_type:'', floor_level:'', remarks:'' };

export default function UsageList() {
  const { hasRole } = useAuth();
  const [data, setData]             = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading]       = useState(true);
  const [search, setSearch]         = useState('');
  const [filters, setFilters]       = useState({});
  const [page, setPage]             = useState(1);
  const [modal, setModal]           = useState(false);
  const [form, setForm]             = useState(emptyForm);
  const [saving, setSaving]         = useState(false);
  const [sites, setSites]           = useState([]);
  const [materials, setMaterials]   = useState([]);

  useEffect(() => {
    siteService.getAllSimple().then(r => { if(r.data.success) setSites(r.data.data); });
    materialService.getAll({ limit: 200, is_active: 'true' }).then(r => { if(r.data.success) setMaterials(r.data.data); });
  }, []);

  useEffect(() => { fetchData(); }, [page, search, filters]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: r } = await usageService.getAll({ page, limit: 15, search, ...filters });
      if (r.success) { setData(r.data); setPagination(r.pagination); }
    } catch {}
    setLoading(false);
  };

  const handleSubmit = async () => {
    const { site_id, material_id, quantity_used, usage_date } = form;
    if (!site_id || !material_id || !quantity_used || !usage_date) { toast.error('Fill all required fields'); return; }
    setSaving(true);
    try {
      const { data: r } = await usageService.create({ ...form, site_id: parseInt(site_id), material_id: parseInt(material_id), quantity_used: parseFloat(quantity_used) });
      if (r.success) { toast.success('Usage recorded'); setModal(false); setForm(emptyForm); fetchData(); }
    } catch (e) { toast.error(e.message); }
    setSaving(false);
  };

  const columns = [
    { header: 'Code', key: 'usage_code', render: v => <span className="font-mono text-xs text-primary-600">{v}</span> },
    { header: 'Date', key: 'usage_date', render: v => fmtDate(v) },
    { header: 'Site', key: 'site_name' },
    { header: 'Material', key: 'material_name', render: (v, row) => (
      <div><div className="font-medium">{v}</div><div className="text-xs text-gray-400">{row.material_code}</div></div>
    )},
    { header: 'Qty Used', key: 'quantity_used', render: (v, row) => <span className="font-semibold text-orange-600">{fmtNumber(v)} {row.unit}</span> },
    { header: 'Total Cost', key: 'total_cost', render: v => fmtCurrency(v) },
    { header: 'Purpose', key: 'purpose', render: v => v || '—' },
    { header: 'Recorded By', key: 'recorded_by_name' },
  ];

  const filterDefs = [
    { key: 'site_id', label: 'Site', type: 'select', options: sites.map(s => ({ value: s.id, label: s.name })) },
    { key: 'from_date', label: 'From Date', type: 'date' },
    { key: 'to_date', label: 'To Date', type: 'date' },
  ];

  return (
    <div className="space-y-4">
      <div className="page-header">
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2"><Wrench size={22} />Material Usage</h1>
          <p className="text-sm text-gray-500">{pagination?.total ?? 0} usage records</p>
        </div>
        {hasRole('admin','site_engineer','project_manager') && (
          <button onClick={() => setModal(true)} className="btn-primary"><Plus size={15} /> Record Usage</button>
        )}
      </div>

      <div className="card">
        <div className="p-4 border-b border-gray-100 dark:border-gray-700 flex flex-wrap gap-3 items-center justify-between">
          <SearchFilter value={search} onChange={v=>{setSearch(v);setPage(1);}} placeholder="Search usage records…"
            filters={filterDefs} filterValues={filters} onFilterChange={(k,v)=>{setFilters(f=>({...f,[k]:v}));setPage(1);}} />
          <button onClick={fetchData} className="btn-secondary text-xs"><RefreshCw size={13} /></button>
        </div>
        <DataTable columns={columns} data={data} loading={loading} />
        <Pagination pagination={pagination} onPageChange={setPage} />
      </div>

      <Modal open={modal} onClose={() => setModal(false)} title="Record Material Usage" size="lg"
        footer={<>
          <button onClick={() => setModal(false)} className="btn-secondary">Cancel</button>
          <button onClick={handleSubmit} disabled={saving} className="btn-primary">{saving ? 'Saving…' : 'Record Usage'}</button>
        </>}
      >
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="form-label">Site <span className="text-red-500">*</span></label>
            <select className="form-select" value={form.site_id} onChange={e => setForm(f=>({...f,site_id:e.target.value}))}>
              <option value="">Select site</option>
              {sites.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div>
            <label className="form-label">Material <span className="text-red-500">*</span></label>
            <select className="form-select" value={form.material_id} onChange={e => setForm(f=>({...f,material_id:e.target.value}))}>
              <option value="">Select material</option>
              {materials.map(m => <option key={m.id} value={m.id}>{m.name} ({m.unit})</option>)}
            </select>
          </div>
          <div>
            <label className="form-label">Quantity Used <span className="text-red-500">*</span></label>
            <input type="number" min="0.01" step="0.01" className="form-input" value={form.quantity_used} onChange={e => setForm(f=>({...f,quantity_used:e.target.value}))} placeholder="0.00" />
          </div>
          <div>
            <label className="form-label">Usage Date <span className="text-red-500">*</span></label>
            <input type="date" className="form-input" value={form.usage_date} onChange={e => setForm(f=>({...f,usage_date:e.target.value}))} />
          </div>
          <div>
            <label className="form-label">Purpose / Activity</label>
            <input className="form-input" value={form.purpose} onChange={e => setForm(f=>({...f,purpose:e.target.value}))} placeholder="e.g. Slab concreting" />
          </div>
          <div>
            <label className="form-label">Work Type</label>
            <select className="form-select" value={form.work_type} onChange={e => setForm(f=>({...f,work_type:e.target.value}))}>
              <option value="">Select</option>
              {['Civil','Structural','Electrical','Plumbing','Finishing','Waterproofing','Other'].map(w => <option key={w} value={w}>{w}</option>)}
            </select>
          </div>
          <div>
            <label className="form-label">Floor / Level</label>
            <input className="form-input" value={form.floor_level} onChange={e => setForm(f=>({...f,floor_level:e.target.value}))} placeholder="e.g. G+2, Basement" />
          </div>
          <div>
            <label className="form-label">Remarks</label>
            <textarea className="form-input" rows={2} value={form.remarks} onChange={e => setForm(f=>({...f,remarks:e.target.value}))} />
          </div>
        </div>
        <div className="mt-3 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg text-xs text-yellow-700 dark:text-yellow-400">
          ⚠️ Recording usage will automatically deduct from site inventory.
        </div>
      </Modal>
    </div>
  );
}
