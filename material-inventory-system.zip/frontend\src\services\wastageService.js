import api from './api';
export const wastageService = {
  getAll:   p => api.get('/wastage', { params: p }),
  create:   d => api.post('/wastage', d),
  getStats: p => api.get('/wastage/stats', { params: p }),
};
