const express = require('express');
const router = express.Router();
const milestoneController = require('../controllers/milestoneController');
const { authenticate } = require('../middleware/auth');

router.use(authenticate);

router.get('/', milestoneController.getAll);
router.get('/:id', milestoneController.getOne);
router.post('/', milestoneController.create);
router.put('/:id', milestoneController.update);
router.delete('/:id', milestoneController.remove);

module.exports = router;
