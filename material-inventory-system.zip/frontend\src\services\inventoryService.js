import api from './api';
export const inventoryService = {
  getAll:          p => api.get('/inventory', { params: p }),
  getSiteInventory:s => api.get(`/inventory/site/${s}`),
  getTransactions: p => api.get('/inventory/transactions', { params: p }),
  adjustStock:     d => api.post('/inventory/adjust', d),
};
