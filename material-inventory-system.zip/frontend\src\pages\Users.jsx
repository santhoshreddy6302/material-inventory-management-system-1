import { useState, useEffect } from 'react';
import { Plus, Edit2, RefreshCw, Users, Key } from 'lucide-react';
import { userService } from '../services/userService';
import DataTable from '../components/common/DataTable';
import Pagination from '../components/common/Pagination';
import SearchFilter from '../components/common/SearchFilter';
import Modal from '../components/common/Modal';
import { fmtDateTime, ROLE_LABELS, getStatusColor } from '../utils/helpers';
import toast from 'react-hot-toast';

const ROLES = ['admin','project_manager','site_engineer','procurement_staff','accounts_staff'];
const emptyForm = { name:'', email:'', password:'', role:'site_engineer', phone:'' };

export default function UsersPage() {
  const [data, setData]             = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading]       = useState(true);
  const [search, setSearch]         = useState('');
  const [filters, setFilters]       = useState({});
  const [page, setPage]             = useState(1);
  const [modal, setModal]           = useState(false);
  const [pwdModal, setPwdModal]     = useState(false);
  const [editing, setEditing]       = useState(null);
  const [form, setForm]             = useState(emptyForm);
  const [newPwd, setNewPwd]         = useState('');
  const [saving, setSaving]         = useState(false);

  useEffect(() => { fetchData(); }, [page, search, filters]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: r } = await userService.getAll({ page, limit: 12, search, ...filters });
      if (r.success) { setData(r.data); setPagination(r.pagination); }
    } catch {}
    setLoading(false);
  };

  const openAdd  = () => { setEditing(null); setForm(emptyForm); setModal(true); };
  const openEdit = u => { setEditing(u); setForm({ name:u.name, email:u.email, role:u.role, phone:u.phone||'', is_active:u.is_active }); setModal(true); };
  const openPwd  = u => { setEditing(u); setNewPwd(''); setPwdModal(true); };

  const handleSave = async () => {
    if (!form.name || !form.email) { toast.error('Name and email required'); return; }
    if (!editing && !form.password) { toast.error('Password required for new user'); return; }
    setSaving(true);
    try {
      const { data: r } = editing ? await userService.update(editing.id, form) : await userService.create(form);
      if (r.success) { toast.success(editing ? 'User updated' : 'User created'); setModal(false); fetchData(); }
    } catch (e) { toast.error(e.message); }
    setSaving(false);
  };

  const handleResetPwd = async () => {
    if (!newPwd || newPwd.length < 6) { toast.error('Password must be at least 6 characters'); return; }
    setSaving(true);
    try {
      const { data: r } = await userService.resetPassword(editing.id, { password: newPwd });
      if (r.success) { toast.success('Password reset'); setPwdModal(false); }
    } catch (e) { toast.error(e.message); }
    setSaving(false);
  };

  const columns = [
    { header: 'User', key: 'name', render: (v, row) => (
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center text-primary-700 dark:text-primary-300 text-sm font-bold">
          {v.charAt(0).toUpperCase()}
        </div>
        <div><div className="font-medium">{v}</div><div className="text-xs text-gray-400">{row.email}</div></div>
      </div>
    )},
    { header: 'Role', key: 'role', render: v => <span className="badge-blue capitalize">{ROLE_LABELS[v] || v}</span> },
    { header: 'Phone', key: 'phone', render: v => v || '—' },
    { header: 'Status', key: 'is_active', render: v => v ? <span className="badge-green">Active</span> : <span className="badge-red">Inactive</span> },
    { header: 'Last Login', key: 'last_login', render: v => <span className="text-xs text-gray-500">{v ? fmtDateTime(v) : 'Never'}</span> },
    { header: 'Actions', key: 'id', render: (_, row) => (
      <div className="flex items-center gap-1">
        <button onClick={() => openEdit(row)} className="p-1.5 text-gray-400 hover:text-primary-600 rounded"><Edit2 size={14}/></button>
        <button onClick={() => openPwd(row)} className="p-1.5 text-gray-400 hover:text-yellow-600 rounded" title="Reset Password"><Key size={14}/></button>
      </div>
    )}
  ];

  const filterDefs = [
    { key: 'role', label: 'Role', type: 'select', options: ROLES.map(r => ({ value: r, label: ROLE_LABELS[r] || r })) },
    { key: 'is_active', label: 'Status', type: 'select', options: [{ value:'true', label:'Active' }, { value:'false', label:'Inactive' }] },
  ];

  return (
    <div className="space-y-4">
      <div className="page-header">
        <div><h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2"><Users size={22}/>User Management</h1><p className="text-sm text-gray-500">{pagination?.total ?? 0} users</p></div>
        <button onClick={openAdd} className="btn-primary"><Plus size={15}/> New User</button>
      </div>
      <div className="card">
        <div className="p-4 border-b border-gray-100 dark:border-gray-700 flex flex-wrap gap-3 items-center justify-between">
          <SearchFilter value={search} onChange={v=>{setSearch(v);setPage(1);}} placeholder="Search users…"
            filters={filterDefs} filterValues={filters} onFilterChange={(k,v)=>{setFilters(f=>({...f,[k]:v}));setPage(1);}} />
          <button onClick={fetchData} className="btn-secondary text-xs"><RefreshCw size={13}/></button>
        </div>
        <DataTable columns={columns} data={data} loading={loading} />
        <Pagination pagination={pagination} onPageChange={setPage} />
      </div>

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Edit User' : 'New User'} size="md"
        footer={<><button onClick={() => setModal(false)} className="btn-secondary">Cancel</button><button onClick={handleSave} disabled={saving} className="btn-primary">{saving ? 'Saving…' : editing ? 'Update' : 'Create'}</button></>}
      >
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2"><label className="form-label">Full Name *</label><input className="form-input" value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} /></div>
          <div><label className="form-label">Email *</label><input type="email" className="form-input" value={form.email} onChange={e=>setForm(f=>({...f,email:e.target.value}))} /></div>
          <div><label className="form-label">Phone</label><input className="form-input" value={form.phone} onChange={e=>setForm(f=>({...f,phone:e.target.value}))} /></div>
          {!editing && <div className="col-span-2"><label className="form-label">Password *</label><input type="password" className="form-input" value={form.password} onChange={e=>setForm(f=>({...f,password:e.target.value}))} placeholder="Min 6 characters" /></div>}
          <div><label className="form-label">Role</label><select className="form-select" value={form.role} onChange={e=>setForm(f=>({...f,role:e.target.value}))}>{ROLES.map(r=><option key={r} value={r}>{ROLE_LABELS[r]}</option>)}</select></div>
          {editing && <div className="flex items-center gap-2 mt-6"><input type="checkbox" id="active" checked={!!form.is_active} onChange={e=>setForm(f=>({...f,is_active:e.target.checked}))}/><label htmlFor="active" className="text-sm">Active</label></div>}
        </div>
      </Modal>

      <Modal open={pwdModal} onClose={() => setPwdModal(false)} title={`Reset Password — ${editing?.name}`} size="sm"
        footer={<><button onClick={() => setPwdModal(false)} className="btn-secondary">Cancel</button><button onClick={handleResetPwd} disabled={saving} className="btn-primary">{saving ? 'Resetting…' : 'Reset Password'}</button></>}
      >
        <div>
          <label className="form-label">New Password</label>
          <input type="password" className="form-input" value={newPwd} onChange={e => setNewPwd(e.target.value)} placeholder="Min 6 characters" />
        </div>
      </Modal>
    </div>
  );
}
