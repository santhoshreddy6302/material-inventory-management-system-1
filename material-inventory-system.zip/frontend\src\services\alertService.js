import api from './api';
export const alertService = {
  getAll:        p => api.get('/alerts', { params: p }),
  getUnreadCount:() => api.get('/alerts/unread-count'),
  markRead:      ids => api.put('/alerts/mark-read', { ids }),
  markAllRead:   () => api.put('/alerts/mark-read', {}),
  resolve:       id => api.put(`/alerts/${id}/resolve`),
};
