import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Package, FolderKanban, MapPin, Truck, AlertTriangle,
  ShoppingCart, Wrench, Trash2, TrendingUp, TrendingDown, Clock
} from 'lucide-react';
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement, LineElement,
  PointElement, ArcElement, Title, Tooltip, Legend, Filler
} from 'chart.js';
import { Bar, Line, Doughnut } from 'react-chartjs-2';
import { dashboardService } from '../services/dashboardService';
import StatsCard from '../components/dashboard/StatsCard';
import ChartCard from '../components/dashboard/ChartCard';
import { fmtCurrency, fmtLargeNumber, fmtNumber, timeAgo, getStatusColor, getStatusLabel } from '../utils/helpers';
import LoadingSpinner from '../components/common/LoadingSpinner';

ChartJS.register(CategoryScale, LinearScale, BarElement, LineElement, PointElement, ArcElement, Title, Tooltip, Legend, Filler);

const chartDefaults = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: { legend: { labels: { font: { size: 11 }, padding: 12 } } },
  scales: {
    x: { grid: { display: false }, ticks: { font: { size: 11 } } },
    y: { grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { font: { size: 11 } } }
  }
};

export default function Dashboard() {
  const [stats, setStats]             = useState(null);
  const [trend, setTrend]             = useState([]);
  const [usageCat, setUsageCat]       = useState([]);
  const [wastageStat, setWastageStat] = useState([]);
  const [siteData, setSiteData]       = useState([]);
  const [monthlyTrend, setMonthly]    = useState(null);
  const [lowStock, setLowStock]       = useState([]);
  const [activity, setActivity]       = useState([]);
  const [loading, setLoading]         = useState(true);

  useEffect(() => { fetchAll(); }, []);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [s, t, uc, wa, sc, mt, ls, ac] = await Promise.all([
        dashboardService.getStats(),
        dashboardService.getInventoryTrend(),
        dashboardService.getUsageByCategory(),
        dashboardService.getWastageAnalysis(),
        dashboardService.getSiteConsumption(),
        dashboardService.getMonthlyTrend(),
        dashboardService.getLowStockItems(),
        dashboardService.getRecentActivity(),
      ]);
      if (s.data.success) setStats(s.data.data);
      if (t.data.success) setTrend(t.data.data);
      if (uc.data.success) setUsageCat(uc.data.data);
      if (wa.data.success) setWastageStat(wa.data.data);
      if (sc.data.success) setSiteData(sc.data.data);
      if (mt.data.success) setMonthly(mt.data.data);
      if (ls.data.success) setLowStock(ls.data.data);
      if (ac.data.success) setActivity(ac.data.data);
    } catch {}
    setLoading(false);
  };

  if (loading) return (
    <div className="flex items-center justify-center h-64"><LoadingSpinner size="lg" /></div>
  );

  // Chart datasets
  const trendChart = {
    labels: trend.map(r => r.date?.slice(5)),
    datasets: [
      { label: 'Purchases', data: trend.map(r => r.purchases), backgroundColor: 'rgba(59,130,246,0.8)', borderRadius: 4, stack: 'a' },
      { label: 'Usage',     data: trend.map(r => r.usage),     backgroundColor: 'rgba(234,88,12,0.8)',  borderRadius: 4, stack: 'b' },
      { label: 'Wastage',   data: trend.map(r => r.wastage),   backgroundColor: 'rgba(239,68,68,0.8)', borderRadius: 4, stack: 'c' },
    ]
  };

  const categoryColors = ['#3b82f6','#f59e0b','#10b981','#f97316','#8b5cf6','#06b6d4','#ec4899','#84cc16'];
  const usageCatChart = {
    labels: usageCat.map(r => r.category || 'Unknown'),
    datasets: [{
      data: usageCat.map(r => parseFloat(r.total_cost || 0)),
      backgroundColor: categoryColors.slice(0, usageCat.length),
      borderWidth: 2, borderColor: '#fff', hoverOffset: 4
    }]
  };

  const monthlyLabels = monthlyTrend?.purchases?.map(r => r.month?.slice(0, 7)) || [];
  const monthlyChart = {
    labels: monthlyLabels,
    datasets: [
      { label: 'Purchases', data: monthlyTrend?.purchases?.map(r => parseFloat(r.total || 0)) || [], borderColor: '#3b82f6', backgroundColor: 'rgba(59,130,246,0.1)', fill: true, tension: 0.4, pointRadius: 3 },
      { label: 'Usage Cost', data: monthlyTrend?.usage?.map(r => parseFloat(r.total || 0)) || [],    borderColor: '#f97316', backgroundColor: 'rgba(249,115,22,0.1)',  fill: true, tension: 0.4, pointRadius: 3 },
    ]
  };

  const siteChart = {
    labels: siteData.map(r => r.site_name),
    datasets: [
      { label: 'Usage Cost',   data: siteData.map(r => parseFloat(r.usage_cost || 0)),   backgroundColor: 'rgba(59,130,246,0.8)', borderRadius: 4 },
      { label: 'Wastage Cost', data: siteData.map(r => parseFloat(r.wastage_cost || 0)), backgroundColor: 'rgba(239,68,68,0.6)',  borderRadius: 4 },
    ]
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">Overview of your material inventory</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        <StatsCard title="Active Materials"   value={stats?.totalMaterials ?? '—'}      icon={Package}      color="blue" />
        <StatsCard title="Active Projects"    value={stats?.activeProjects ?? '—'}      icon={FolderKanban} color="green" />
        <StatsCard title="Active Sites"       value={stats?.activeSites ?? '—'}         icon={MapPin}       color="purple" />
        <StatsCard title="Suppliers"          value={stats?.totalSuppliers ?? '—'}      icon={Truck}        color="orange" />
        <StatsCard
          title="Low Stock Alerts"
          value={stats?.lowStockMaterials ?? '—'}
          icon={AlertTriangle}
          color={stats?.lowStockMaterials > 0 ? 'red' : 'green'}
          subtitle={stats?.lowStockMaterials > 0 ? 'Needs attention' : 'All stocked'}
        />
        <StatsCard title="Monthly Purchases"  value={fmtLargeNumber(stats?.monthlyPurchases)}  icon={ShoppingCart} color="blue"   subtitle="This month" />
        <StatsCard title="Monthly Usage"      value={fmtLargeNumber(stats?.monthlyUsageCost)}  icon={Wrench}       color="orange" subtitle="Material cost" />
        <StatsCard title="Monthly Wastage"    value={fmtLargeNumber(stats?.monthlyWastageCost)}icon={Trash2}       color="red"    subtitle="Loss cost" />
        <StatsCard title="Pending POs"        value={stats?.pendingPOs ?? '—'}          icon={ShoppingCart}  color="yellow" />
        <StatsCard title="Unread Alerts"      value={stats?.unreadAlerts ?? '—'}        icon={AlertTriangle} color={stats?.unreadAlerts > 0 ? 'red' : 'green'} />
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <ChartCard title="30-Day Stock Movement" subtitle="Purchases vs Usage vs Wastage (qty)" action={
          <span className="text-xs text-gray-400">Last 30 days</span>
        }>
          <div className="h-52">
            <Bar data={trendChart} options={{ ...chartDefaults, scales: { ...chartDefaults.scales, x: { ...chartDefaults.scales.x, ticks: { maxTicksLimit: 8, font: { size: 10 } } } } }} />
          </div>
        </ChartCard>

        <ChartCard title="Usage by Category" subtitle="This month">
          <div className="h-52 flex items-center justify-center">
            {usageCat.length > 0
              ? <Doughnut data={usageCatChart} options={{ responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { size: 11 }, padding: 8 } } }, cutout: '65%' }} />
              : <p className="text-sm text-gray-400">No usage data this month</p>
            }
          </div>
        </ChartCard>

        <ChartCard title="Monthly Trend" subtitle="Purchase vs Usage cost (12 months)">
          <div className="h-52">
            <Line data={monthlyChart} options={{ ...chartDefaults, scales: { x: { grid: { display: false }, ticks: { font: { size: 10 } } }, y: { grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { callback: v => fmtLargeNumber(v), font: { size: 10 } } } } }} />
          </div>
        </ChartCard>
      </div>

      {/* Charts Row 2 + Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <ChartCard title="Site-wise Consumption" subtitle="Last 30 days">
          <div className="h-52">
            {siteData.length > 0
              ? <Bar data={siteChart} options={{ ...chartDefaults, indexAxis: 'y', scales: { x: { grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { callback: v => fmtLargeNumber(v), font: { size: 10 } } }, y: { grid: { display: false }, ticks: { font: { size: 10 } } } } }} />
              : <p className="text-sm text-gray-400 flex items-center justify-center h-full">No data available</p>
            }
          </div>
        </ChartCard>

        {/* Low Stock */}
        <div className="card">
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 dark:border-gray-700">
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white">⚠️ Low Stock Items</h3>
            <Link to="/inventory" className="text-xs text-primary-600 hover:underline">View all</Link>
          </div>
          <div className="divide-y divide-gray-50 dark:divide-gray-700/50">
            {lowStock.length === 0
              ? <div className="py-8 text-center text-sm text-gray-400">✅ All materials well-stocked</div>
              : lowStock.slice(0, 6).map(item => (
                <div key={`${item.id}-${item.site_id}`} className="px-5 py-3 flex items-center justify-between">
                  <div>
                    <span className="text-sm font-medium text-gray-900 dark:text-white">{item.name}</span>
                    <div className="text-xs text-gray-400 mt-0.5">{item.site_name} · {item.category_name}</div>
                  </div>
                  <div className="text-right">
                    <div className={`text-sm font-semibold ${item.current_stock <= 0 ? 'text-red-600' : 'text-yellow-600'}`}>
                      {fmtNumber(item.current_stock)} {item.unit}
                    </div>
                    <div className="text-xs text-gray-400">Min: {fmtNumber(item.minimum_threshold)}</div>
                  </div>
                </div>
              ))
            }
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="card">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 dark:border-gray-700">
          <div className="flex items-center gap-2">
            <Clock size={16} className="text-gray-400" />
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white">Recent Activity</h3>
          </div>
        </div>
        <div className="divide-y divide-gray-50 dark:divide-gray-700/50">
          {activity.length === 0
            ? <div className="py-8 text-center text-sm text-gray-400">No recent activity</div>
            : activity.slice(0, 8).map(a => (
              <div key={a.id} className="px-5 py-3 flex items-start gap-3">
                <div className="w-7 h-7 rounded-full bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center text-primary-700 dark:text-primary-400 text-xs font-bold flex-shrink-0 mt-0.5">
                  {(a.user_name || 'S').charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <span className="text-sm text-gray-900 dark:text-white font-medium">{a.user_name || 'System'}</span>
                  <span className="text-sm text-gray-500 dark:text-gray-400"> — {a.action}</span>
                  {a.entity_name && <span className="text-sm text-primary-600 dark:text-primary-400"> "{a.entity_name}"</span>}
                </div>
                <div className="text-xs text-gray-400 flex-shrink-0">{timeAgo(a.created_at)}</div>
              </div>
            ))
          }
        </div>
      </div>
    </div>
  );
}
