const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const { login, register, getMe, updatePassword, updateProfile } = require('../controllers/authController');
const { authenticate, authorize } = require('../middleware/auth');
const validate = require('../middleware/validate');

router.post('/login', [
  body('email').isEmail().withMessage('Valid email required'),
  body('password').notEmpty().withMessage('Password required')
], validate, login);

router.post('/register', [
  body('name').trim().notEmpty().withMessage('Name required'),
  body('email').isEmail().withMessage('Valid email required'),
  body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
  body('role').isIn(['admin','project_manager','site_engineer','procurement_staff','accounts_staff']).withMessage('Invalid role')
], validate, authenticate, authorize('admin'), register);

router.get('/me', authenticate, getMe);
router.put('/password', authenticate, [
  body('currentPassword').notEmpty(),
  body('newPassword').isLength({ min: 6 })
], validate, updatePassword);
router.put('/profile', authenticate, [
  body('name').trim().notEmpty()
], validate, updateProfile);

module.exports = router;
