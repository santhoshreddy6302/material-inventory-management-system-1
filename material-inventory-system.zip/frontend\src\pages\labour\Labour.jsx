import { useState, useEffect } from 'react';
import { Plus, Users, Edit2, Trash2 } from 'lucide-react';
import { labourService } from '../../services/labourService';
import DataTable from '../../components/common/DataTable';
import Pagination from '../../components/common/Pagination';
import Modal from '../../components/common/Modal';
import toast from 'react-hot-toast';
import { useAuth } from '../../context/AuthContext';

const emptyForm = { name: '', type: '', daily_wage: '' };

export default function Labour() {
  const { hasRole } = useAuth();
  const canEdit = hasRole('admin', 'project_manager');
  const [data, setData] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  useEffect(() => { fetchData(); }, [page]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: r } = await labourService.getAll({ page, limit: 12 });
      if (r.success) { setData(r.data); setPagination(r.pagination); }
    } catch {}
    setLoading(false);
  };

  const openAdd = () => { setEditing(null); setForm(emptyForm); setModal(true); };
  const openEdit = item => { setEditing(item); setForm({ name: item.name, type: item.type, daily_wage: item.daily_wage }); setModal(true); };

  const handleSave = async () => {
    if (!form.name) { toast.error('Name required'); return; }
    setSaving(true);
    try {
      const { data: r } = editing ? await labourService.update(editing.id, form) : await labourService.create(form);
      if (r.success) { toast.success(editing ? 'Updated' : 'Created'); setModal(false); fetchData(); }
    } catch (e) { toast.error(e.message); }
    setSaving(false);
  };

  const handleDelete = async id => {
    if (!confirm('Are you sure?')) return;
    try {
      const { data: r } = await labourService.remove(id);
      if (r.success) { toast.success('Deleted'); fetchData(); }
    } catch (e) { toast.error(e.message); }
  };

  const columns = [
    { key: 'name', label: 'Name' },
    { key: 'type', label: 'Type' },
    { key: 'daily_wage', label: 'Daily Wage' },
    ...(canEdit ? [{ key: 'actions', label: 'Actions', render: (val, item) => (
      <div className="flex gap-2">
        <button onClick={() => openEdit(item)} className="p-1 text-blue-600 hover:bg-blue-50 rounded"><Edit2 size={16}/></button>
        <button onClick={() => handleDelete(item.id)} className="p-1 text-red-600 hover:bg-red-50 rounded"><Trash2 size={16}/></button>
      </div>
    ) }] : [])
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-100 text-indigo-600 rounded-lg"><Users size={24} /></div>
          <div>
            <h1 className="text-2xl font-bold text-slate-800">Labour</h1>
            <p className="text-sm text-slate-500">Manage labour resources</p>
          </div>
        </div>
        {canEdit && (
          <button onClick={openAdd} className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center gap-2">
            <Plus size={20} /> Add Labour
          </button>
        )}
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200">
        <DataTable columns={columns} data={data} loading={loading} />
        {pagination && <Pagination current={pagination.page} total={pagination.pages} onPageChange={setPage} />}
      </div>

      <Modal isOpen={modal} onClose={() => setModal(false)} title={editing ? 'Edit Labour' : 'Add Labour'}>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Name</label>
            <input type="text" value={form.name} onChange={e => setForm({...form, name: e.target.value})} className="w-full rounded-lg border-slate-200 border p-2" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Type</label>
            <input type="text" value={form.type} onChange={e => setForm({...form, type: e.target.value})} className="w-full rounded-lg border-slate-200 border p-2" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Daily Wage</label>
            <input type="number" value={form.daily_wage} onChange={e => setForm({...form, daily_wage: e.target.value})} className="w-full rounded-lg border-slate-200 border p-2" />
          </div>
          <div className="flex justify-end gap-3 mt-6">
            <button onClick={() => setModal(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-50 rounded-lg">Cancel</button>
            <button onClick={handleSave} disabled={saving} className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50">
              {saving ? 'Saving...' : 'Save'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
