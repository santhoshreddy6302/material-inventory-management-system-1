const db = require('../config/database');
const { success, created, error, paginated } = require('../utils/responseHelper');
const { parseFilters, buildSearchQuery, buildSearchParams, generateCode } = require('../utils/helpers');

const getAll = async (req, res) => {
  try {
    const { page, limit, offset, search, sort, order } = parseFilters(req.query);
    const { category_id, is_active } = req.query;
    let where = 'WHERE 1=1';
    const params = [];
    if (search) {
      where += ` AND (m.name LIKE ? OR m.material_code LIKE ? OR m.description LIKE ?)`;
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    if (category_id) { where += ' AND m.category_id = ?'; params.push(category_id); }
    if (is_active !== undefined) { where += ' AND m.is_active = ?'; params.push(is_active === 'true' ? 1 : 0); }

    const [countResult] = await db.query(
      `SELECT COUNT(*) as total FROM materials m ${where}`, params
    );
    const [rows] = await db.query(
      `SELECT m.*, mc.name as category_name, mc.color as category_color,
              s.name as supplier_name, s.phone as supplier_phone
       FROM materials m
       LEFT JOIN material_categories mc ON m.category_id = mc.id
       LEFT JOIN suppliers s ON m.supplier_id = s.id
       ${where}
       ORDER BY m.${sort} ${order}
       LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );
    return paginated(res, rows, countResult[0].total, page, limit);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getOne = async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT m.*, mc.name as category_name, s.name as supplier_name
       FROM materials m
       LEFT JOIN material_categories mc ON m.category_id = mc.id
       LEFT JOIN suppliers s ON m.supplier_id = s.id
       WHERE m.id = ?`,
      [req.params.id]
    );
    if (!rows.length) return error(res, 'Material not found', 404);
    return success(res, rows[0]);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const create = async (req, res) => {
  try {
    const { name, category_id, unit, description, cost_per_unit, minimum_threshold, reorder_quantity, supplier_id, specifications } = req.body;
    const code = generateCode('MAT');
    const [result] = await db.query(
      `INSERT INTO materials (material_code, name, category_id, unit, description, cost_per_unit, minimum_threshold, reorder_quantity, supplier_id, specifications)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [code, name.trim(), category_id || null, unit, description || null, cost_per_unit || 0, minimum_threshold || 0, reorder_quantity || 0, supplier_id || null, specifications || null]
    );
    const [newMaterial] = await db.query(
      `SELECT m.*, mc.name as category_name FROM materials m LEFT JOIN material_categories mc ON m.category_id = mc.id WHERE m.id = ?`,
      [result.insertId]
    );
    return created(res, newMaterial[0], 'Material created successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const update = async (req, res) => {
  try {
    const { name, category_id, unit, description, cost_per_unit, minimum_threshold, reorder_quantity, supplier_id, specifications, is_active } = req.body;
    const [exists] = await db.query('SELECT id FROM materials WHERE id = ?', [req.params.id]);
    if (!exists.length) return error(res, 'Material not found', 404);
    await db.query(
      `UPDATE materials SET name=?, category_id=?, unit=?, description=?, cost_per_unit=?, minimum_threshold=?, reorder_quantity=?, supplier_id=?, specifications=?, is_active=?, updated_at=NOW()
       WHERE id=?`,
      [name, category_id || null, unit, description || null, cost_per_unit, minimum_threshold, reorder_quantity || 0, supplier_id || null, specifications || null, is_active !== undefined ? is_active : 1, req.params.id]
    );
    const [updated] = await db.query(
      `SELECT m.*, mc.name as category_name FROM materials m LEFT JOIN material_categories mc ON m.category_id = mc.id WHERE m.id = ?`,
      [req.params.id]
    );
    return success(res, updated[0], 'Material updated successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const remove = async (req, res) => {
  try {
    const [usage] = await db.query('SELECT id FROM inventory WHERE material_id = ? LIMIT 1', [req.params.id]);
    if (usage.length) return error(res, 'Cannot delete material with inventory records', 409);
    const [result] = await db.query('DELETE FROM materials WHERE id = ?', [req.params.id]);
    if (!result.affectedRows) return error(res, 'Material not found', 404);
    return success(res, null, 'Material deleted successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getCategories = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM material_categories ORDER BY name ASC');
    return success(res, rows);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const createCategory = async (req, res) => {
  try {
    const { name, description, color } = req.body;
    const [result] = await db.query(
      'INSERT INTO material_categories (name, description, color) VALUES (?, ?, ?)',
      [name.trim(), description || null, color || '#6B7280']
    );
    const [cat] = await db.query('SELECT * FROM material_categories WHERE id = ?', [result.insertId]);
    return created(res, cat[0], 'Category created successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getLowStock = async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT m.id, m.name, m.material_code, m.unit, m.minimum_threshold,
              COALESCE(SUM(i.current_stock), 0) as total_stock,
              mc.name as category_name
       FROM materials m
       LEFT JOIN inventory i ON m.id = i.material_id
       LEFT JOIN material_categories mc ON m.category_id = mc.id
       WHERE m.is_active = 1
       GROUP BY m.id
       HAVING total_stock <= m.minimum_threshold
       ORDER BY total_stock ASC`
    );
    return success(res, rows);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

module.exports = { getAll, getOne, create, update, remove, getCategories, createCategory, getLowStock };
