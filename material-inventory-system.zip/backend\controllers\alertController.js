const db = require('../config/database');
const { success, error, paginated } = require('../utils/responseHelper');
const { parseFilters } = require('../utils/helpers');

const getAll = async (req, res) => {
  try {
    const { page, limit, offset } = parseFilters(req.query);
    const { type, severity, is_read, is_resolved } = req.query;
    let where = 'WHERE 1=1';
    const params = [];
    if (type) { where += ' AND a.type = ?'; params.push(type); }
    if (severity) { where += ' AND a.severity = ?'; params.push(severity); }
    if (is_read !== undefined) { where += ' AND a.is_read = ?'; params.push(is_read === 'true' ? 1 : 0); }
    if (is_resolved !== undefined) { where += ' AND a.is_resolved = ?'; params.push(is_resolved === 'true' ? 1 : 0); }

    const [countResult] = await db.query(`SELECT COUNT(*) as total FROM alerts a ${where}`, params);
    const [rows] = await db.query(
      `SELECT a.*, m.name as material_name, m.unit, s.name as site_name, po.po_number
       FROM alerts a
       LEFT JOIN materials m ON a.material_id = m.id
       LEFT JOIN sites s ON a.site_id = s.id
       LEFT JOIN purchase_orders po ON a.po_id = po.id
       ${where}
       ORDER BY a.created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );
    return paginated(res, rows, countResult[0].total, page, limit);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const markRead = async (req, res) => {
  try {
    const { ids } = req.body;
    if (ids && ids.length) {
      await db.query('UPDATE alerts SET is_read = 1 WHERE id IN (?)', [ids]);
    } else {
      await db.query('UPDATE alerts SET is_read = 1');
    }
    return success(res, null, 'Alerts marked as read');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const resolve = async (req, res) => {
  try {
    await db.query('UPDATE alerts SET is_resolved = 1, is_read = 1, resolved_at = NOW() WHERE id = ?', [req.params.id]);
    return success(res, null, 'Alert resolved');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getUnreadCount = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT COUNT(*) as count FROM alerts WHERE is_read = 0 AND is_resolved = 0');
    return success(res, { count: rows[0].count });
  } catch (err) {
    return error(res, err.message, 500);
  }
};

module.exports = { getAll, markRead, resolve, getUnreadCount };
