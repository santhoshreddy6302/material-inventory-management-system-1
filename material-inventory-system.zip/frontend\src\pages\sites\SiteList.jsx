import { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, RefreshCw, MapPin } from 'lucide-react';
import { siteService } from '../../services/siteService';
import { projectService } from '../../services/projectService';
import DataTable from '../../components/common/DataTable';
import Pagination from '../../components/common/Pagination';
import SearchFilter from '../../components/common/SearchFilter';
import Modal from '../../components/common/Modal';
import toast from 'react-hot-toast';
import { useAuth } from '../../context/AuthContext';

export default function SiteList() {
  const { hasRole } = useAuth();
  const canEdit = hasRole('admin','project_manager');
  const [data, setData]             = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading]       = useState(true);
  const [search, setSearch]         = useState('');
  const [page, setPage]             = useState(1);
  const [modal, setModal]           = useState(false);
  const [editing, setEditing]       = useState(null);
  const [projects, setProjects]     = useState([]);
  const [saving, setSaving]         = useState(false);
  const [form, setForm]             = useState({ name:'', location:'', address:'', project_id:'', engineer_id:'' });

  useEffect(() => {
    projectService.getAll({ limit: 100 }).then(r => { if(r.data.success) setProjects(r.data.data); });
  }, []);

  useEffect(() => { fetchData(); }, [page, search]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: r } = await siteService.getAll({ page, limit: 12, search });
      if (r.success) { setData(r.data); setPagination(r.pagination); }
    } catch {}
    setLoading(false);
  };

  const openAdd = () => { setEditing(null); setForm({ name:'', location:'', address:'', project_id:'', engineer_id:'' }); setModal(true); };
  const openEdit = (item) => { setEditing(item); setForm({ name: item.name, location: item.location||'', address: item.address||'', project_id: item.project_id||'', engineer_id: item.engineer_id||'', is_active: item.is_active }); setModal(true); };

  const handleSave = async () => {
    if (!form.name) { toast.error('Site name required'); return; }
    setSaving(true);
    try {
      const { data: r } = editing ? await siteService.update(editing.id, form) : await siteService.create(form);
      if (r.success) { toast.success(editing ? 'Site updated' : 'Site created'); setModal(false); fetchData(); }
    } catch (e) { toast.error(e.message); }
    setSaving(false);
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Delete site "${name}"?`)) return;
    try {
      const { data: r } = await siteService.remove(id);
      if (r.success) { toast.success('Site deleted'); fetchData(); }
    } catch (e) { toast.error(e.message); }
  };

  const columns = [
    { header: 'Site', key: 'name', render: (v, row) => (
      <div><div className="font-semibold text-gray-900 dark:text-white">{v}</div><div className="text-xs text-gray-400">{row.site_code}</div></div>
    )},
    { header: 'Project', key: 'project_name', render: v => v || '—' },
    { header: 'Location', key: 'location', render: v => v || '—' },
    { header: 'Engineer', key: 'engineer_name', render: v => v || '—' },
    { header: 'Status', key: 'is_active', render: v => v ? <span className="badge-green">Active</span> : <span className="badge-red">Inactive</span> },
    ...(canEdit ? [{ header: '', key: 'id', render: (_, row) => (
      <div className="flex gap-1">
        <button onClick={() => openEdit(row)} className="p-1.5 text-gray-400 hover:text-primary-600 rounded"><Edit2 size={14}/></button>
        <button onClick={() => handleDelete(row.id, row.name)} className="p-1.5 text-gray-400 hover:text-red-600 rounded"><Trash2 size={14}/></button>
      </div>
    )}] : [])
  ];

  return (
    <div className="space-y-4">
      <div className="page-header">
        <div><h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2"><MapPin size={22}/>Sites</h1><p className="text-sm text-gray-500">{pagination?.total ?? 0} sites</p></div>
        {canEdit && <button onClick={openAdd} className="btn-primary"><Plus size={15}/> New Site</button>}
      </div>
      <div className="card">
        <div className="p-4 border-b border-gray-100 dark:border-gray-700 flex gap-3 items-center justify-between">
          <SearchFilter value={search} onChange={v=>{setSearch(v);setPage(1);}} placeholder="Search sites…" />
          <button onClick={fetchData} className="btn-secondary text-xs"><RefreshCw size={13}/></button>
        </div>
        <DataTable columns={columns} data={data} loading={loading} />
        <Pagination pagination={pagination} onPageChange={setPage} />
      </div>
      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Edit Site' : 'New Site'} size="md"
        footer={<><button onClick={() => setModal(false)} className="btn-secondary">Cancel</button><button onClick={handleSave} disabled={saving} className="btn-primary">{saving ? 'Saving…' : editing ? 'Update' : 'Create'}</button></>}
      >
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2"><label className="form-label">Site Name *</label><input className="form-input" value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} /></div>
          <div><label className="form-label">Project</label><select className="form-select" value={form.project_id} onChange={e=>setForm(f=>({...f,project_id:e.target.value}))}><option value="">Select project</option>{projects.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></div>
          <div><label className="form-label">Location</label><input className="form-input" value={form.location} onChange={e=>setForm(f=>({...f,location:e.target.value}))} /></div>
          <div className="col-span-2"><label className="form-label">Address</label><textarea className="form-input" rows={2} value={form.address} onChange={e=>setForm(f=>({...f,address:e.target.value}))} /></div>
        </div>
      </Modal>
    </div>
  );
}
