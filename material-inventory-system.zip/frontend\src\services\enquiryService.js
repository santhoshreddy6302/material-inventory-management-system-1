import api from './api';
export const enquiryService = {
  getAll: p => api.get('/enquiries', { params: p }),
  getOne: id => api.get(`/enquiries/${id}`),
  create: d => api.post('/enquiries', d),
  update: (id, d) => api.put(`/enquiries/${id}`, d),
  remove: id => api.delete(`/enquiries/${id}`),
};
