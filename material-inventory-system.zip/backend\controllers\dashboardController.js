const db = require('../config/database');
const { success, error } = require('../utils/responseHelper');

const getStats = async (req, res) => {
  try {
    const [materials] = await db.query('SELECT COUNT(*) as count FROM materials WHERE is_active = 1');
    const [projects] = await db.query('SELECT COUNT(*) as count FROM projects WHERE status = "active"');
    const [suppliers] = await db.query('SELECT COUNT(*) as count FROM suppliers WHERE is_active = 1');
    const [sites] = await db.query('SELECT COUNT(*) as count FROM sites WHERE is_active = 1');
    const [lowStock] = await db.query(
      `SELECT COUNT(DISTINCT m.id) as count FROM materials m
       LEFT JOIN inventory i ON m.id = i.material_id
       WHERE m.is_active = 1
       GROUP BY m.id
       HAVING COALESCE(SUM(i.current_stock), 0) <= m.minimum_threshold`
    );
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
    const [monthlyPurchases] = await db.query(
      `SELECT COALESCE(SUM(total_amount), 0) as total FROM purchase_orders WHERE status NOT IN ('draft', 'cancelled') AND order_date >= ?`,
      [startOfMonth]
    );
    const [monthlyUsage] = await db.query(
      `SELECT COALESCE(SUM(total_cost), 0) as total FROM material_usage WHERE usage_date >= ?`,
      [startOfMonth]
    );
    const [monthlyWastage] = await db.query(
      `SELECT COALESCE(SUM(total_cost), 0) as total FROM wastage_records WHERE wastage_date >= ?`,
      [startOfMonth]
    );
    const [pendingPOs] = await db.query(
      `SELECT COUNT(*) as count FROM purchase_orders WHERE status IN ('pending_approval', 'approved', 'ordered')`
    );
    const [unreadAlerts] = await db.query('SELECT COUNT(*) as count FROM alerts WHERE is_read = 0 AND is_resolved = 0');

    return success(res, {
      totalMaterials: materials[0].count,
      activeProjects: projects[0].count,
      totalSuppliers: suppliers[0].count,
      activeSites: sites[0].count,
      lowStockMaterials: lowStock.length,
      monthlyPurchases: parseFloat(monthlyPurchases[0].total),
      monthlyUsageCost: parseFloat(monthlyUsage[0].total),
      monthlyWastageCost: parseFloat(monthlyWastage[0].total),
      pendingPOs: pendingPOs[0].count,
      unreadAlerts: unreadAlerts[0].count
    });
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getInventoryTrend = async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT DATE_FORMAT(created_at, '%Y-%m-%d') as date,
              SUM(CASE WHEN transaction_type = 'purchase' THEN quantity ELSE 0 END) as purchases,
              SUM(CASE WHEN transaction_type = 'usage' THEN ABS(quantity) ELSE 0 END) as usage,
              SUM(CASE WHEN transaction_type = 'wastage' THEN ABS(quantity) ELSE 0 END) as wastage
       FROM inventory_transactions
       WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
       GROUP BY DATE_FORMAT(created_at, '%Y-%m-%d')
       ORDER BY date ASC`
    );
    return success(res, rows);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getUsageByCategory = async (req, res) => {
  try {
    const startOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0];
    const [rows] = await db.query(
      `SELECT mc.name as category, SUM(u.total_cost) as total_cost, SUM(u.quantity_used) as total_qty
       FROM material_usage u
       LEFT JOIN materials m ON u.material_id = m.id
       LEFT JOIN material_categories mc ON m.category_id = mc.id
       WHERE u.usage_date >= ?
       GROUP BY mc.id
       ORDER BY total_cost DESC`,
      [startOfMonth]
    );
    return success(res, rows);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getWastageAnalysis = async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT w.reason, COUNT(*) as count, SUM(w.total_cost) as total_cost
       FROM wastage_records w
       WHERE w.wastage_date >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
       GROUP BY w.reason
       ORDER BY total_cost DESC`
    );
    return success(res, rows);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getSiteConsumption = async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT s.name as site_name, SUM(u.total_cost) as usage_cost, SUM(w.total_cost) as wastage_cost
       FROM sites s
       LEFT JOIN material_usage u ON s.id = u.site_id AND u.usage_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
       LEFT JOIN wastage_records w ON s.id = w.site_id AND w.wastage_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
       WHERE s.is_active = 1
       GROUP BY s.id
       ORDER BY usage_cost DESC
       LIMIT 10`
    );
    return success(res, rows);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getMonthlyTrend = async (req, res) => {
  try {
    const [purchases] = await db.query(
      `SELECT DATE_FORMAT(order_date, '%Y-%m') as month, SUM(total_amount) as total
       FROM purchase_orders WHERE status NOT IN ('draft', 'cancelled') AND order_date >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
       GROUP BY month ORDER BY month ASC`
    );
    const [usage] = await db.query(
      `SELECT DATE_FORMAT(usage_date, '%Y-%m') as month, SUM(total_cost) as total
       FROM material_usage WHERE usage_date >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
       GROUP BY month ORDER BY month ASC`
    );
    return success(res, { purchases, usage });
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getRecentActivity = async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT al.*, u.name as user_name FROM activity_logs al
       LEFT JOIN users u ON al.user_id = u.id
       ORDER BY al.created_at DESC LIMIT 20`
    );
    return success(res, rows);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getLowStockItems = async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT m.id, m.name, m.material_code, m.unit, m.minimum_threshold,
              mc.name as category_name, mc.color as category_color,
              s.name as site_name, i.current_stock, i.site_id
       FROM inventory i
       LEFT JOIN materials m ON i.material_id = m.id
       LEFT JOIN material_categories mc ON m.category_id = mc.id
       LEFT JOIN sites s ON i.site_id = s.id
       WHERE i.current_stock <= m.minimum_threshold AND m.is_active = 1
       ORDER BY i.current_stock ASC
       LIMIT 20`
    );
    return success(res, rows);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

module.exports = { getStats, getInventoryTrend, getUsageByCategory, getWastageAnalysis, getSiteConsumption, getMonthlyTrend, getRecentActivity, getLowStockItems };
