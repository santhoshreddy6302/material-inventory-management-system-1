const generateCode = (prefix, length = 6) => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = prefix + '-';
  for (let i = 0; i < length; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
};

const generatePONumber = () => {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
  return `PO-${year}${month}-${random}`;
};

const generateCode_with_timestamp = (prefix) => {
  const ts = Date.now().toString().slice(-6);
  return `${prefix}-${ts}`;
};

const formatDate = (date) => {
  if (!date) return null;
  return new Date(date).toISOString().split('T')[0];
};

const sanitizeInput = (str) => {
  if (typeof str !== 'string') return str;
  return str.trim().replace(/[<>]/g, '');
};

const parseFilters = (query) => {
  const { page = 1, limit = 10, search = '', sort = 'created_at', order = 'DESC' } = query;
  const offset = (parseInt(page) - 1) * parseInt(limit);
  return {
    page: parseInt(page),
    limit: parseInt(limit),
    offset,
    search: sanitizeInput(search),
    sort: sanitizeInput(sort),
    order: order.toUpperCase() === 'ASC' ? 'ASC' : 'DESC'
  };
};

const buildSearchQuery = (fields, search) => {
  if (!search) return '';
  const conditions = fields.map(f => `${f} LIKE ?`).join(' OR ');
  return `AND (${conditions})`;
};

const buildSearchParams = (fields, search) => {
  if (!search) return [];
  return fields.map(() => `%${search}%`);
};

module.exports = {
  generateCode,
  generatePONumber,
  generateCode_with_timestamp,
  formatDate,
  sanitizeInput,
  parseFilters,
  buildSearchQuery,
  buildSearchParams
};
