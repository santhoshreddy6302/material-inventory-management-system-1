const bcrypt = require('bcryptjs');
const db = require('../config/database');
const { success, created, error, paginated } = require('../utils/responseHelper');
const { parseFilters } = require('../utils/helpers');

const getAll = async (req, res) => {
  try {
    const { page, limit, offset, search } = parseFilters(req.query);
    const { role, is_active } = req.query;
    let where = 'WHERE 1=1';
    const params = [];
    if (search) { where += ' AND (name LIKE ? OR email LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }
    if (role) { where += ' AND role = ?'; params.push(role); }
    if (is_active !== undefined) { where += ' AND is_active = ?'; params.push(is_active === 'true' ? 1 : 0); }

    const [countResult] = await db.query(`SELECT COUNT(*) as total FROM users ${where}`, params);
    const [rows] = await db.query(
      `SELECT id, name, email, role, phone, is_active, last_login, created_at FROM users ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );
    return paginated(res, rows, countResult[0].total, page, limit);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const create = async (req, res) => {
  try {
    const { name, email, password, role, phone } = req.body;
    const [exists] = await db.query('SELECT id FROM users WHERE email = ?', [email.toLowerCase()]);
    if (exists.length) return error(res, 'Email already registered', 409);
    const hashed = await bcrypt.hash(password, 12);
    const [result] = await db.query(
      'INSERT INTO users (name, email, password, role, phone) VALUES (?, ?, ?, ?, ?)',
      [name, email.toLowerCase(), hashed, role, phone || null]
    );
    const [newUser] = await db.query('SELECT id, name, email, role, phone, created_at FROM users WHERE id = ?', [result.insertId]);
    return created(res, newUser[0], 'User created successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const update = async (req, res) => {
  try {
    const { name, email, role, phone, is_active } = req.body;
    const [exists] = await db.query('SELECT id FROM users WHERE id = ?', [req.params.id]);
    if (!exists.length) return error(res, 'User not found', 404);
    await db.query(
      'UPDATE users SET name=?, email=?, role=?, phone=?, is_active=?, updated_at=NOW() WHERE id=?',
      [name, email.toLowerCase(), role, phone || null, is_active !== undefined ? is_active : 1, req.params.id]
    );
    const [updated] = await db.query('SELECT id, name, email, role, phone, is_active FROM users WHERE id = ?', [req.params.id]);
    return success(res, updated[0], 'User updated successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const resetPassword = async (req, res) => {
  try {
    const { password } = req.body;
    const hashed = await bcrypt.hash(password, 12);
    await db.query('UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?', [hashed, req.params.id]);
    return success(res, null, 'Password reset successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

module.exports = { getAll, create, update, resetPassword };
