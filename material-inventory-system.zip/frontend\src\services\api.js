import axios from 'axios';
import toast from 'react-hot-toast';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' }
});

const token = localStorage.getItem('mims_token');
if (token) api.defaults.headers.common['Authorization'] = `Bearer ${token}`;

api.interceptors.request.use(
  config => config,
  err => Promise.reject(err)
);

api.interceptors.response.use(
  response => response,
  error => {
    const msg = error.response?.data?.message || error.message || 'Request failed';
    const status = error.response?.status;
    if (status === 401) {
      localStorage.removeItem('mims_token');
      delete api.defaults.headers.common['Authorization'];
      if (window.location.pathname !== '/login') window.location.href = '/login';
    } else if (status === 403) {
      toast.error('Access denied. Insufficient permissions.');
    } else if (status >= 500) {
      toast.error('Server error. Please try again.');
    }
    return Promise.reject({ ...error, message: msg });
  }
);

export default api;
