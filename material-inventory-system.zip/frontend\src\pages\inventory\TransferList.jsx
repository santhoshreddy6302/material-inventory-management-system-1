import { useState, useEffect } from 'react';
import { Plus, ArrowLeftRight, RefreshCw } from 'lucide-react';
import { transferService } from '../../services/transferService';
import { siteService } from '../../services/siteService';
import DataTable from '../../components/common/DataTable';
import Pagination from '../../components/common/Pagination';
import Modal from '../../components/common/Modal';
import { fmtDate, fmtNumber, getStatusColor, getStatusLabel } from '../../utils/helpers';
import toast from 'react-hot-toast';
import { useAuth } from '../../context/AuthContext';

export default function TransferList() {
  const { hasRole } = useAuth();
  const [data, setData]         = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading]   = useState(true);
  const [page, setPage]         = useState(1);
  const [modalOpen, setModalOpen] = useState(false);
  const [sites, setSites]       = useState([]);
  const [form, setForm]         = useState({ from_site_id:'', to_site_id:'', material_id:'', quantity:'', transfer_date:'', reason:'' });
  const [saving, setSaving]     = useState(false);

  useEffect(() => { siteService.getAllSimple().then(r => { if (r.data.success) setSites(r.data.data); }); }, []);
  useEffect(() => { fetchData(); }, [page]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: r } = await transferService.getAll({ page, limit: 15 });
      if (r.success) { setData(r.data); setPagination(r.pagination); }
    } catch {}
    setLoading(false);
  };

  const handleCreate = async () => {
    if (!form.from_site_id || !form.to_site_id || !form.material_id || !form.quantity || !form.transfer_date) {
      toast.error('Fill all required fields'); return;
    }
    setSaving(true);
    try {
      const { data } = await transferService.create({ ...form, quantity: parseFloat(form.quantity), material_id: parseInt(form.material_id) });
      if (data.success) { toast.success('Transfer request created'); setModalOpen(false); fetchData(); }
    } catch (e) { toast.error(e.message); }
    setSaving(false);
  };

  const handleStatusUpdate = async (id, status) => {
    if (!window.confirm(`Mark transfer as ${status}?`)) return;
    try {
      const { data } = await transferService.updateStatus(id, { status });
      if (data.success) { toast.success('Status updated'); fetchData(); }
    } catch (e) { toast.error(e.message); }
  };

  const columns = [
    { header: 'Code', key: 'transfer_code', render: v => <span className="font-mono text-xs font-semibold text-primary-600">{v}</span> },
    { header: 'Material', key: 'material_name', render: (v, row) => <><div className="font-medium">{v}</div><div className="text-xs text-gray-400">{row.material_code}</div></> },
    { header: 'From → To', key: 'from_site_name', render: (v, row) => <div className="text-xs"><div className="font-medium">{v}</div><div className="text-gray-400">→ {row.to_site_name}</div></div> },
    { header: 'Qty', key: 'quantity', render: (v, row) => `${fmtNumber(v)} ${row.unit || ''}` },
    { header: 'Date', key: 'transfer_date', render: v => fmtDate(v) },
    { header: 'Status', key: 'status', render: v => <span className={getStatusColor(v)}>{getStatusLabel(v)}</span> },
    { header: 'By', key: 'requested_by_name' },
    ...(hasRole('admin','project_manager') ? [{
      header: 'Action', key: 'id', render: (id, row) => row.status === 'pending'
        ? <button onClick={() => handleStatusUpdate(id, 'completed')} className="text-xs btn-primary py-1 px-2">Complete</button>
        : row.status === 'in_transit'
        ? <button onClick={() => handleStatusUpdate(id, 'completed')} className="text-xs btn-primary py-1 px-2">Mark Received</button>
        : null
    }] : [])
  ];

  return (
    <div className="space-y-4">
      <div className="page-header">
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2"><ArrowLeftRight size={22} />Stock Transfers</h1>
          <p className="text-sm text-gray-500 mt-0.5">{pagination?.total ?? 0} transfers</p>
        </div>
        {hasRole('admin','site_engineer','project_manager') && (
          <button onClick={() => setModalOpen(true)} className="btn-primary"><Plus size={15} /> New Transfer</button>
        )}
      </div>
      <div className="card">
        <div className="p-4 border-b border-gray-100 dark:border-gray-700 flex justify-end">
          <button onClick={fetchData} className="btn-secondary text-xs"><RefreshCw size={13} /></button>
        </div>
        <DataTable columns={columns} data={data} loading={loading} />
        <Pagination pagination={pagination} onPageChange={setPage} />
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="New Stock Transfer" size="md"
        footer={<>
          <button onClick={() => setModalOpen(false)} className="btn-secondary">Cancel</button>
          <button onClick={handleCreate} disabled={saving} className="btn-primary">{saving ? 'Requesting…' : 'Request Transfer'}</button>
        </>}
      >
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="form-label">From Site <span className="text-red-500">*</span></label>
              <select className="form-select" value={form.from_site_id} onChange={e => setForm(f=>({...f,from_site_id:e.target.value}))}>
                <option value="">Select</option>
                {sites.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
            <div>
              <label className="form-label">To Site <span className="text-red-500">*</span></label>
              <select className="form-select" value={form.to_site_id} onChange={e => setForm(f=>({...f,to_site_id:e.target.value}))}>
                <option value="">Select</option>
                {sites.filter(s => s.id != form.from_site_id).map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="form-label">Material ID <span className="text-red-500">*</span></label>
              <input type="number" className="form-input" placeholder="Material ID" value={form.material_id} onChange={e => setForm(f=>({...f,material_id:e.target.value}))} />
            </div>
            <div>
              <label className="form-label">Quantity <span className="text-red-500">*</span></label>
              <input type="number" min="0.01" step="0.01" className="form-input" value={form.quantity} onChange={e => setForm(f=>({...f,quantity:e.target.value}))} />
            </div>
          </div>
          <div>
            <label className="form-label">Transfer Date <span className="text-red-500">*</span></label>
            <input type="date" className="form-input" value={form.transfer_date} onChange={e => setForm(f=>({...f,transfer_date:e.target.value}))} />
          </div>
          <div>
            <label className="form-label">Reason</label>
            <textarea className="form-input" rows={2} value={form.reason} onChange={e => setForm(f=>({...f,reason:e.target.value}))} />
          </div>
        </div>
      </Modal>
    </div>
  );
}
