import api from './api';
export const supplierService = {
  getAll:      p => api.get('/suppliers', { params: p }),
  getAllSimple: () => api.get('/suppliers/all'),
  create:      d => api.post('/suppliers', d),
  update:      (id, d) => api.put(`/suppliers/${id}`, d),
  remove:      id => api.delete(`/suppliers/${id}`),
};
