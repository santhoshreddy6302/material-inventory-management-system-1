import api from './api';
export const userService = {
  getAll:         p => api.get('/users', { params: p }),
  create:         d => api.post('/users', d),
  update:         (id, d) => api.put(`/users/${id}`, d),
  resetPassword:  (id, d) => api.put(`/users/${id}/reset-password`, d),
  updateProfile:  d => api.put('/auth/profile', d),
  changePassword: d => api.put('/auth/password', d),
};
