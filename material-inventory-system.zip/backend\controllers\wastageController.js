const db = require('../config/database');
const { success, created, error, paginated } = require('../utils/responseHelper');
const { parseFilters, generateCode_with_timestamp } = require('../utils/helpers');
const { checkAndCreateAlerts } = require('./inventoryController');

const getAll = async (req, res) => {
  try {
    const { page, limit, offset, search } = parseFilters(req.query);
    const { site_id, material_id, reason, from_date, to_date } = req.query;
    let where = 'WHERE 1=1';
    const params = [];
    if (site_id) { where += ' AND w.site_id = ?'; params.push(site_id); }
    if (material_id) { where += ' AND w.material_id = ?'; params.push(material_id); }
    if (reason) { where += ' AND w.reason = ?'; params.push(reason); }
    if (from_date) { where += ' AND w.wastage_date >= ?'; params.push(from_date); }
    if (to_date) { where += ' AND w.wastage_date <= ?'; params.push(to_date); }
    if (search) { where += ' AND (m.name LIKE ? OR s.name LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }

    const [countResult] = await db.query(`SELECT COUNT(*) as total FROM wastage_records w LEFT JOIN materials m ON w.material_id = m.id LEFT JOIN sites s ON w.site_id = s.id ${where}`, params);
    const [rows] = await db.query(
      `SELECT w.*, m.name as material_name, m.unit, m.material_code, s.name as site_name, r.name as recorded_by_name
       FROM wastage_records w
       LEFT JOIN materials m ON w.material_id = m.id
       LEFT JOIN sites s ON w.site_id = s.id
       LEFT JOIN users r ON w.recorded_by = r.id
       ${where}
       ORDER BY w.wastage_date DESC
       LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );
    return paginated(res, rows, countResult[0].total, page, limit);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const create = async (req, res) => {
  try {
    const { site_id, material_id, quantity_wasted, wastage_date, reason, description, preventable, remarks } = req.body;
    const conn = await db.getConnection();
    try {
      await conn.beginTransaction();
      const [inv] = await conn.query('SELECT * FROM inventory WHERE material_id = ? AND site_id = ?', [material_id, site_id]);
      if (!inv.length || inv[0].current_stock < quantity_wasted) {
        throw new Error(`Insufficient stock. Available: ${inv.length ? inv[0].current_stock : 0}`);
      }
      const [material] = await conn.query('SELECT cost_per_unit FROM materials WHERE id = ?', [material_id]);
      const unit_cost = material[0]?.cost_per_unit || 0;
      const total_cost = unit_cost * quantity_wasted;
      const code = generateCode_with_timestamp('WST');
      const [result] = await conn.query(
        `INSERT INTO wastage_records (wastage_code, site_id, material_id, quantity_wasted, unit_cost, total_cost, wastage_date, reason, description, preventable, remarks, recorded_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [code, site_id, material_id, quantity_wasted, unit_cost, total_cost, wastage_date, reason, description || null, preventable ? 1 : 0, remarks || null, req.user.id]
      );
      const newStock = parseFloat(inv[0].current_stock) - parseFloat(quantity_wasted);
      await conn.query('UPDATE inventory SET current_stock = ?, last_updated = NOW() WHERE id = ?', [newStock, inv[0].id]);
      await conn.query(
        `INSERT INTO inventory_transactions (inventory_id, material_id, site_id, transaction_type, quantity, balance_after, unit_cost, total_cost, reference_id, reference_type, created_by)
         VALUES (?, ?, ?, 'wastage', ?, ?, ?, ?, ?, 'wastage_record', ?)`,
        [inv[0].id, material_id, site_id, -quantity_wasted, newStock, unit_cost, total_cost, result.insertId, req.user.id]
      );
      await checkAndCreateAlerts(conn, material_id, site_id, newStock);
      await conn.commit();
      return created(res, { id: result.insertId, code }, 'Wastage recorded successfully');
    } catch (e) {
      await conn.rollback();
      throw e;
    } finally {
      conn.release();
    }
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getStats = async (req, res) => {
  try {
    const { site_id, from_date, to_date } = req.query;
    let where = 'WHERE 1=1';
    const params = [];
    if (site_id) { where += ' AND w.site_id = ?'; params.push(site_id); }
    if (from_date) { where += ' AND w.wastage_date >= ?'; params.push(from_date); }
    if (to_date) { where += ' AND w.wastage_date <= ?'; params.push(to_date); }
    const [byReason] = await db.query(`SELECT w.reason, COUNT(*) as count, SUM(w.total_cost) as total_cost FROM wastage_records w ${where} GROUP BY w.reason ORDER BY total_cost DESC`, params);
    const [byMaterial] = await db.query(`SELECT m.name, m.unit, SUM(w.quantity_wasted) as total_qty, SUM(w.total_cost) as total_cost FROM wastage_records w LEFT JOIN materials m ON w.material_id = m.id ${where} GROUP BY w.material_id ORDER BY total_cost DESC LIMIT 10`, params);
    const [monthly] = await db.query(`SELECT DATE_FORMAT(w.wastage_date, '%Y-%m') as month, SUM(w.total_cost) as total_cost FROM wastage_records w ${where} GROUP BY month ORDER BY month DESC LIMIT 12`, params);
    return success(res, { byReason, byMaterial, monthly });
  } catch (err) {
    return error(res, err.message, 500);
  }
};

module.exports = { getAll, create, getStats };
