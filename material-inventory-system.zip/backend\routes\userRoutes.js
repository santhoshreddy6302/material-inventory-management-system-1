const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const { getAll, create, update, resetPassword } = require('../controllers/userController');
const { authenticate, authorize } = require('../middleware/auth');
const validate = require('../middleware/validate');

router.use(authenticate);
router.get('/', authorize('admin'), getAll);
router.post('/', authorize('admin'), [
  body('name').trim().notEmpty(),
  body('email').isEmail(),
  body('password').isLength({ min: 6 }),
  body('role').isIn(['admin','project_manager','site_engineer','procurement_staff','accounts_staff'])
], validate, create);
router.put('/:id', authorize('admin'), update);
router.put('/:id/reset-password', authorize('admin'), [
  body('password').isLength({ min: 6 })
], validate, resetPassword);

module.exports = router;
