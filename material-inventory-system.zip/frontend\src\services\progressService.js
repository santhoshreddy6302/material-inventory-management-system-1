import api from './api';
export const progressService = {
  getAll: p => api.get('/progress', { params: p }),
  getOne: id => api.get(`/progress/${id}`),
  create: d => api.post('/progress', d),
  update: (id, d) => api.put(`/progress/${id}`, d),
  remove: id => api.delete(`/progress/${id}`),
};
