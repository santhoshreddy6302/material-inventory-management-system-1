import { useState, useEffect } from 'react';
import { Plus, FolderKanban, Edit2, Trash2, RefreshCw } from 'lucide-react';
import { projectService } from '../../services/projectService';
import DataTable from '../../components/common/DataTable';
import Pagination from '../../components/common/Pagination';
import SearchFilter from '../../components/common/SearchFilter';
import Modal from '../../components/common/Modal';
import { fmtDate, fmtCurrency, getStatusColor, getStatusLabel } from '../../utils/helpers';
import toast from 'react-hot-toast';
import { useAuth } from '../../context/AuthContext';

const STATUSES = ['planning','active','completed','on_hold','cancelled'];
const emptyForm = { name:'', description:'', location:'', client_name:'', start_date:'', end_date:'', budget:'', status:'planning', manager_id:'' };

export default function ProjectList() {
  const { hasRole } = useAuth();
  const canEdit = hasRole('admin','project_manager');
  const [data, setData]             = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading]       = useState(true);
  const [search, setSearch]         = useState('');
  const [filters, setFilters]       = useState({});
  const [page, setPage]             = useState(1);
  const [modal, setModal]           = useState(false);
  const [editing, setEditing]       = useState(null);
  const [form, setForm]             = useState(emptyForm);
  const [saving, setSaving]         = useState(false);

  useEffect(() => { fetchData(); }, [page, search, filters]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: r } = await projectService.getAll({ page, limit: 12, search, ...filters });
      if (r.success) { setData(r.data); setPagination(r.pagination); }
    } catch {}
    setLoading(false);
  };

  const openAdd = () => { setEditing(null); setForm(emptyForm); setModal(true); };
  const openEdit = p => { setEditing(p); setForm({ name:p.name, description:p.description||'', location:p.location||'', client_name:p.client_name||'', start_date:p.start_date?.split('T')[0]||'', end_date:p.end_date?.split('T')[0]||'', budget:p.budget||'', status:p.status, manager_id:p.manager_id||'' }); setModal(true); };

  const handleSave = async () => {
    if (!form.name) { toast.error('Project name required'); return; }
    setSaving(true);
    try {
      const payload = { ...form, budget: parseFloat(form.budget) || 0, manager_id: form.manager_id ? parseInt(form.manager_id) : null };
      const { data: r } = editing ? await projectService.update(editing.id, payload) : await projectService.create(payload);
      if (r.success) { toast.success(editing ? 'Project updated' : 'Project created'); setModal(false); fetchData(); }
    } catch (e) { toast.error(e.message); }
    setSaving(false);
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Delete project "${name}"?`)) return;
    try {
      const { data: r } = await projectService.remove(id);
      if (r.success) { toast.success('Deleted'); fetchData(); }
    } catch (e) { toast.error(e.message); }
  };

  const columns = [
    { header: 'Project', key: 'name', render: (v, row) => (
      <div><div className="font-semibold text-gray-900 dark:text-white">{v}</div><div className="text-xs text-gray-400">{row.project_code}</div></div>
    )},
    { header: 'Client', key: 'client_name', render: v => v || '—' },
    { header: 'Location', key: 'location', render: v => v || '—' },
    { header: 'Manager', key: 'manager_name', render: v => v || '—' },
    { header: 'Sites', key: 'site_count', render: v => <span className="badge-blue">{v}</span> },
    { header: 'Budget', key: 'budget', render: v => fmtCurrency(v) },
    { header: 'Start', key: 'start_date', render: v => fmtDate(v) },
    { header: 'Status', key: 'status', render: v => <span className={getStatusColor(v)}>{getStatusLabel(v)}</span> },
    ...(canEdit ? [{ header: '', key: 'id', render: (_, row) => (
      <div className="flex gap-1">
        <button onClick={() => openEdit(row)} className="p-1.5 text-gray-400 hover:text-primary-600 rounded"><Edit2 size={14} /></button>
        <button onClick={() => handleDelete(row.id, row.name)} className="p-1.5 text-gray-400 hover:text-red-600 rounded"><Trash2 size={14} /></button>
      </div>
    )}] : [])
  ];

  return (
    <div className="space-y-4">
      <div className="page-header">
        <div><h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2"><FolderKanban size={22} />Projects</h1><p className="text-sm text-gray-500">{pagination?.total ?? 0} projects</p></div>
        {canEdit && <button onClick={openAdd} className="btn-primary"><Plus size={15} /> New Project</button>}
      </div>
      <div className="card">
        <div className="p-4 border-b border-gray-100 dark:border-gray-700 flex flex-wrap gap-3 items-center justify-between">
          <SearchFilter value={search} onChange={v=>{setSearch(v);setPage(1);}} placeholder="Search projects…"
            filters={[{ key:'status', label:'Status', type:'select', options: STATUSES.map(s => ({ value:s, label:getStatusLabel(s) })) }]}
            filterValues={filters} onFilterChange={(k,v)=>{setFilters(f=>({...f,[k]:v}));setPage(1);}} />
          <button onClick={fetchData} className="btn-secondary text-xs"><RefreshCw size={13} /></button>
        </div>
        <DataTable columns={columns} data={data} loading={loading} />
        <Pagination pagination={pagination} onPageChange={setPage} />
      </div>
      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Edit Project' : 'New Project'} size="lg"
        footer={<><button onClick={() => setModal(false)} className="btn-secondary">Cancel</button><button onClick={handleSave} disabled={saving} className="btn-primary">{saving ? 'Saving…' : editing ? 'Update' : 'Create'}</button></>}
      >
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2"><label className="form-label">Project Name <span className="text-red-500">*</span></label><input className="form-input" value={form.name} onChange={e => setForm(f=>({...f,name:e.target.value}))} /></div>
          <div><label className="form-label">Client Name</label><input className="form-input" value={form.client_name} onChange={e => setForm(f=>({...f,client_name:e.target.value}))} /></div>
          <div><label className="form-label">Location</label><input className="form-input" value={form.location} onChange={e => setForm(f=>({...f,location:e.target.value}))} /></div>
          <div><label className="form-label">Start Date</label><input type="date" className="form-input" value={form.start_date} onChange={e => setForm(f=>({...f,start_date:e.target.value}))} /></div>
          <div><label className="form-label">End Date</label><input type="date" className="form-input" value={form.end_date} onChange={e => setForm(f=>({...f,end_date:e.target.value}))} /></div>
          <div><label className="form-label">Budget (₹)</label><input type="number" className="form-input" value={form.budget} onChange={e => setForm(f=>({...f,budget:e.target.value}))} /></div>
          <div><label className="form-label">Status</label><select className="form-select" value={form.status} onChange={e => setForm(f=>({...f,status:e.target.value}))}>{STATUSES.map(s => <option key={s} value={s}>{getStatusLabel(s)}</option>)}</select></div>
          <div className="col-span-2"><label className="form-label">Description</label><textarea className="form-input" rows={2} value={form.description} onChange={e => setForm(f=>({...f,description:e.target.value}))} /></div>
        </div>
      </Modal>
    </div>
  );
}
