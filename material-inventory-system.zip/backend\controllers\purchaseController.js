const db = require('../config/database');
const { success, created, error, paginated } = require('../utils/responseHelper');
const { parseFilters, generatePONumber } = require('../utils/helpers');

const getAll = async (req, res) => {
  try {
    const { page, limit, offset, search } = parseFilters(req.query);
    const { status, supplier_id, from_date, to_date } = req.query;
    let where = 'WHERE 1=1';
    const params = [];
    if (search) { where += ' AND (po.po_number LIKE ? OR s.name LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }
    if (status) { where += ' AND po.status = ?'; params.push(status); }
    if (supplier_id) { where += ' AND po.supplier_id = ?'; params.push(supplier_id); }
    if (from_date) { where += ' AND DATE(po.order_date) >= ?'; params.push(from_date); }
    if (to_date) { where += ' AND DATE(po.order_date) <= ?'; params.push(to_date); }

    const [countResult] = await db.query(
      `SELECT COUNT(*) as total FROM purchase_orders po LEFT JOIN suppliers s ON po.supplier_id = s.id ${where}`, params
    );
    const [rows] = await db.query(
      `SELECT po.*, s.name as supplier_name, s.phone as supplier_phone,
              pr.name as project_name, si.name as site_name,
              u.name as created_by_name, a.name as approved_by_name,
              COUNT(poi.id) as item_count
       FROM purchase_orders po
       LEFT JOIN suppliers s ON po.supplier_id = s.id
       LEFT JOIN projects pr ON po.project_id = pr.id
       LEFT JOIN sites si ON po.site_id = si.id
       LEFT JOIN users u ON po.created_by = u.id
       LEFT JOIN users a ON po.approved_by = a.id
       LEFT JOIN purchase_order_items poi ON po.id = poi.po_id
       ${where}
       GROUP BY po.id
       ORDER BY po.created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );
    return paginated(res, rows, countResult[0].total, page, limit);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getOne = async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT po.*, s.name as supplier_name, s.email as supplier_email, s.phone as supplier_phone, s.address as supplier_address, s.gst_number,
              pr.name as project_name, si.name as site_name,
              u.name as created_by_name, a.name as approved_by_name
       FROM purchase_orders po
       LEFT JOIN suppliers s ON po.supplier_id = s.id
       LEFT JOIN projects pr ON po.project_id = pr.id
       LEFT JOIN sites si ON po.site_id = si.id
       LEFT JOIN users u ON po.created_by = u.id
       LEFT JOIN users a ON po.approved_by = a.id
       WHERE po.id = ?`,
      [req.params.id]
    );
    if (!rows.length) return error(res, 'Purchase order not found', 404);
    const [items] = await db.query(
      `SELECT poi.*, m.name as material_name, m.unit, m.material_code
       FROM purchase_order_items poi
       LEFT JOIN materials m ON poi.material_id = m.id
       WHERE poi.po_id = ?`,
      [req.params.id]
    );
    return success(res, { ...rows[0], items });
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const create = async (req, res) => {
  try {
    const { supplier_id, project_id, site_id, order_date, expected_delivery, notes, items, delivery_address, terms_conditions } = req.body;
    if (!items || !items.length) return error(res, 'At least one item is required', 400);
    const conn = await db.getConnection();
    try {
      await conn.beginTransaction();
      const po_number = generatePONumber();
      let subtotal = 0;
      items.forEach(item => { subtotal += parseFloat(item.quantity) * parseFloat(item.unit_price); });
      const [result] = await conn.query(
        `INSERT INTO purchase_orders (po_number, supplier_id, project_id, site_id, order_date, expected_delivery, subtotal, total_amount, notes, delivery_address, terms_conditions, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [po_number, supplier_id, project_id || null, site_id || null, order_date, expected_delivery || null, subtotal, subtotal, notes || null, delivery_address || null, terms_conditions || null, req.user.id]
      );
      const po_id = result.insertId;
      for (const item of items) {
        const total = parseFloat(item.quantity) * parseFloat(item.unit_price);
        await conn.query(
          `INSERT INTO purchase_order_items (po_id, material_id, quantity, unit_price, total_price, tax_percentage)
           VALUES (?, ?, ?, ?, ?, ?)`,
          [po_id, item.material_id, item.quantity, item.unit_price, total, item.tax_percentage || 0]
        );
      }
      // Create approval alert
      await conn.query(
        `INSERT INTO alerts (type, title, message, po_id, severity) VALUES ('po_approval', ?, ?, ?, 'medium')`,
        [`PO Approval Required: ${po_number}`, `New purchase order ${po_number} requires approval`, po_id]
      );
      await conn.commit();
      const [newPO] = await conn.query('SELECT * FROM purchase_orders WHERE id = ?', [po_id]);
      return created(res, newPO[0], 'Purchase order created successfully');
    } catch (e) {
      await conn.rollback();
      throw e;
    } finally {
      conn.release();
    }
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const updateStatus = async (req, res) => {
  try {
    const { status, notes } = req.body;
    const { id } = req.params;
    const [po] = await db.query('SELECT * FROM purchase_orders WHERE id = ?', [id]);
    if (!po.length) return error(res, 'Purchase order not found', 404);
    const validTransitions = {
      draft: ['pending_approval', 'cancelled'],
      pending_approval: ['approved', 'cancelled'],
      approved: ['ordered', 'cancelled'],
      ordered: ['partially_received', 'received', 'cancelled'],
      partially_received: ['received', 'cancelled'],
      received: [],
      cancelled: []
    };
    if (!validTransitions[po[0].status]?.includes(status)) {
      return error(res, `Cannot transition from ${po[0].status} to ${status}`, 400);
    }
    const updates = { status };
    if (status === 'approved') {
      updates.approved_by = req.user.id;
      updates.approved_at = new Date();
    }
    const conn = await db.getConnection();
    try {
      await conn.beginTransaction();
      await conn.query('UPDATE purchase_orders SET status = ?, approved_by = ?, approved_at = ?, updated_at = NOW() WHERE id = ?',
        [status, updates.approved_by || po[0].approved_by, updates.approved_at || po[0].approved_at, id]);
      
      // If received, update inventory
      if (status === 'received' || status === 'partially_received') {
        const [items] = await conn.query('SELECT * FROM purchase_order_items WHERE po_id = ?', [id]);
        for (const item of items) {
          if (po[0].site_id) {
            const qty = status === 'received' ? item.quantity : item.received_quantity;
            if (qty > 0) {
              const [existing] = await conn.query(
                'SELECT * FROM inventory WHERE material_id = ? AND site_id = ?',
                [item.material_id, po[0].site_id]
              );
              let invId;
              if (!existing.length) {
                const [r] = await conn.query('INSERT INTO inventory (material_id, site_id, current_stock) VALUES (?, ?, ?)',
                  [item.material_id, po[0].site_id, qty]);
                invId = r.insertId;
              } else {
                const newStock = parseFloat(existing[0].current_stock) + parseFloat(qty);
                await conn.query('UPDATE inventory SET current_stock = ?, last_updated = NOW() WHERE id = ?',
                  [newStock, existing[0].id]);
                invId = existing[0].id;
              }
              const [inv] = await conn.query('SELECT current_stock FROM inventory WHERE id = ?', [invId]);
              await conn.query(
                `INSERT INTO inventory_transactions (inventory_id, material_id, site_id, transaction_type, quantity, balance_after, unit_cost, total_cost, reference_id, reference_type, created_by)
                 VALUES (?, ?, ?, 'purchase', ?, ?, ?, ?, ?, 'purchase_order', ?)`,
                [invId, item.material_id, po[0].site_id, qty, inv[0].current_stock, item.unit_price, item.unit_price * qty, id, req.user.id]
              );
            }
          }
        }
        await conn.query('UPDATE purchase_orders SET actual_delivery = NOW() WHERE id = ?', [id]);
      }
      await conn.commit();
      return success(res, null, `Purchase order ${status.replace('_', ' ')} successfully`);
    } catch (e) {
      await conn.rollback();
      throw e;
    } finally {
      conn.release();
    }
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const remove = async (req, res) => {
  try {
    const [po] = await db.query('SELECT status FROM purchase_orders WHERE id = ?', [req.params.id]);
    if (!po.length) return error(res, 'Purchase order not found', 404);
    if (!['draft', 'cancelled'].includes(po[0].status)) {
      return error(res, 'Only draft or cancelled orders can be deleted', 400);
    }
    await db.query('DELETE FROM purchase_orders WHERE id = ?', [req.params.id]);
    return success(res, null, 'Purchase order deleted successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

module.exports = { getAll, getOne, create, updateStatus, remove };
