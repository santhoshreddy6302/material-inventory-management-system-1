import api from './api';
export const machineryService = {
  getAll: p => api.get('/machinery', { params: p }),
  getOne: id => api.get(`/machinery/${id}`),
  create: d => api.post('/machinery', d),
  update: (id, d) => api.put(`/machinery/${id}`, d),
  remove: id => api.delete(`/machinery/${id}`),
};
