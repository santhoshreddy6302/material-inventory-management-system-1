import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { HardHat, Mail, Lock, Eye, EyeOff, AlertCircle } from 'lucide-react';

export default function Login() {
  const { login } = useAuth();
  const [form, setForm]       = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState('');
  const [showPwd, setShowPwd] = useState(false);

  const handleChange = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    if (!form.email || !form.password) { setError('Email and password are required.'); return; }
    setLoading(true);
    try {
      const ok = await login(form.email, form.password);
      if (!ok) setError('Invalid credentials. Please try again.');
    } catch (err) {
      setError(err.message || 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const demoLogin = (email) => setForm({ email, password: 'Admin@123' });

  return (
    <div className="min-h-screen flex bg-gradient-to-br from-navy-900 via-navy-800 to-primary-900">
      {/* Left panel */}
      <div className="hidden lg:flex flex-1 flex-col justify-between p-12 text-white">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur">
            <HardHat size={24} className="text-white" />
          </div>
          <div>
            <div className="font-bold text-lg leading-tight">AVINASH KANAPARTHI INFRA</div>
            <div className="text-[10px] text-white/60">PRIVATE LIMITED</div>
          </div>
        </div>
        <div>
          <h1 className="text-4xl font-bold mb-4 leading-tight">
            Material Inventory<br />Management System
          </h1>
          <p className="text-white/70 text-lg mb-8">
            Track, manage, and optimize construction material flow across all your sites in real-time.
          </p>
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: 'Materials Tracked', value: '50+' },
              { label: 'Active Projects',   value: '10+' },
              { label: 'Sites Managed',     value: '25+' },
              { label: 'Purchase Orders',   value: '100+' },
            ].map(s => (
              <div key={s.label} className="bg-white/10 backdrop-blur rounded-xl p-4">
                <div className="text-2xl font-bold">{s.value}</div>
                <div className="text-sm text-white/60">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="text-xs text-white/40">© 2024 AVINASH KANAPARTHI INFRA PRIVATE LIMITED</div>
      </div>

      {/* Right panel - login form */}
      <div className="flex-1 lg:max-w-[440px] flex items-center justify-center p-6 bg-white dark:bg-gray-900">
        <div className="w-full max-w-sm">
          <div className="flex lg:hidden items-center gap-3 mb-8 justify-center">
            <div className="w-10 h-10 bg-primary-600 rounded-xl flex items-center justify-center">
              <HardHat size={22} className="text-white" />
            </div>
            <div className="font-bold text-xl text-gray-900 dark:text-white">AVINASH KANAPARTHI INFRA</div>
          </div>

          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">Sign in</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">Enter your credentials to continue</p>

          {error && (
            <div className="flex items-center gap-2 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg px-3 py-2.5 mb-4">
              <AlertCircle size={16} className="text-red-500 flex-shrink-0" />
              <span className="text-sm text-red-700 dark:text-red-400">{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="form-label">Email Address</label>
              <div className="relative">
                <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="email" name="email" value={form.email} onChange={handleChange}
                  placeholder="you@company.com" required autoComplete="email" autoFocus
                  className="form-input pl-9"
                />
              </div>
            </div>
            <div>
              <label className="form-label">Password</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type={showPwd ? 'text' : 'password'} name="password" value={form.password} onChange={handleChange}
                  placeholder="••••••••" required autoComplete="current-password"
                  className="form-input pl-9 pr-9"
                />
                <button type="button" onClick={() => setShowPwd(p => !p)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                  {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
            <button type="submit" disabled={loading} className="btn-primary w-full justify-center py-2.5">
              {loading ? (
                <><span className="animate-spin rounded-full h-4 w-4 border-2 border-white/30 border-t-white" />Signing in…</>
              ) : 'Sign In'}
            </button>
          </form>

          <div className="mt-6">
            <p className="text-xs text-gray-400 text-center mb-3">Quick demo access</p>
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: 'Admin',      email: 'admin@constco.com' },
                { label: 'PM',         email: 'pm@constco.com' },
                { label: 'Engineer',   email: 'engineer@constco.com' },
                { label: 'Procurement',email: 'procurement@constco.com' },
              ].map(d => (
                <button key={d.label} onClick={() => demoLogin(d.email)}
                  className="text-xs px-3 py-1.5 rounded-lg border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800">
                  {d.label}
                </button>
              ))}
            </div>
            <p className="text-xs text-gray-400 text-center mt-2">Password: Admin@123</p>
          </div>
        </div>
      </div>
    </div>
  );
}
