const express = require('express');
const router = express.Router();
const progressController = require('../controllers/progressController');
const { authenticate } = require('../middleware/auth');

router.use(authenticate);

router.get('/', progressController.getAll);
router.get('/:id', progressController.getOne);
router.post('/', progressController.create);
router.put('/:id', progressController.update);
router.delete('/:id', progressController.remove);

module.exports = router;
