import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Trash2, ArrowLeft, ShoppingCart } from 'lucide-react';
import { purchaseService } from '../../services/purchaseService';
import { supplierService } from '../../services/supplierService';
import { projectService } from '../../services/projectService';
import { siteService } from '../../services/siteService';
import { materialService } from '../../services/materialService';
import { fmtCurrency } from '../../utils/helpers';
import toast from 'react-hot-toast';

const emptyItem = { material_id: '', material_name: '', unit: '', quantity: '', unit_price: '', tax_percentage: 0 };

export default function CreatePO() {
  const navigate = useNavigate();
  const [suppliers, setSuppliers]   = useState([]);
  const [projects, setProjects]     = useState([]);
  const [sites, setSites]           = useState([]);
  const [materials, setMaterials]   = useState([]);
  const [saving, setSaving]         = useState(false);
  const [form, setForm] = useState({
    supplier_id: '', project_id: '', site_id: '', order_date: new Date().toISOString().split('T')[0],
    expected_delivery: '', delivery_address: '', terms_conditions: '', notes: '',
  });
  const [items, setItems] = useState([{ ...emptyItem }]);

  useEffect(() => {
    supplierService.getAllSimple().then(r => { if(r.data.success) setSuppliers(r.data.data); });
    projectService.getAll({ limit: 100 }).then(r => { if(r.data.success) setProjects(r.data.data); });
    siteService.getAllSimple().then(r => { if(r.data.success) setSites(r.data.data); });
    materialService.getAll({ limit: 100, is_active: 'true' }).then(r => { if(r.data.success) setMaterials(r.data.data); });
  }, []);

  const setField = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const setItem = (idx, k, v) => {
    setItems(prev => {
      const arr = [...prev];
      arr[idx] = { ...arr[idx], [k]: v };
      if (k === 'material_id') {
        const mat = materials.find(m => m.id == v);
        if (mat) { arr[idx].material_name = mat.name; arr[idx].unit = mat.unit; arr[idx].unit_price = mat.cost_per_unit; }
      }
      return arr;
    });
  };

  const addItem = () => setItems(prev => [...prev, { ...emptyItem }]);
  const removeItem = idx => setItems(prev => prev.filter((_, i) => i !== idx));

  const subtotal = items.reduce((s, i) => s + (parseFloat(i.quantity || 0) * parseFloat(i.unit_price || 0)), 0);

  const handleSubmit = async () => {
    if (!form.supplier_id) { toast.error('Please select a supplier'); return; }
    if (!form.order_date) { toast.error('Order date is required'); return; }
    const validItems = items.filter(i => i.material_id && i.quantity > 0 && i.unit_price >= 0);
    if (!validItems.length) { toast.error('Add at least one valid item'); return; }
    setSaving(true);
    try {
      const payload = {
        ...form,
        supplier_id: parseInt(form.supplier_id),
        project_id: form.project_id ? parseInt(form.project_id) : null,
        site_id: form.site_id ? parseInt(form.site_id) : null,
        items: validItems.map(i => ({
          material_id: parseInt(i.material_id),
          quantity: parseFloat(i.quantity),
          unit_price: parseFloat(i.unit_price),
          tax_percentage: parseFloat(i.tax_percentage || 0),
        }))
      };
      const { data } = await purchaseService.create(payload);
      if (data.success) { toast.success('Purchase order created'); navigate('/purchase-orders'); }
    } catch (e) { toast.error(e.message); }
    setSaving(false);
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate('/purchase-orders')} className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500"><ArrowLeft size={18} /></button>
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2"><ShoppingCart size={22} />Create Purchase Order</h1>
          <p className="text-sm text-gray-500">Fill details and add materials</p>
        </div>
      </div>

      {/* Header Details */}
      <div className="card p-5 space-y-4">
        <h2 className="text-sm font-semibold text-gray-700 dark:text-gray-300 border-b border-gray-100 dark:border-gray-700 pb-2">Order Details</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label className="form-label">Supplier <span className="text-red-500">*</span></label>
            <select className="form-select" value={form.supplier_id} onChange={e => setField('supplier_id', e.target.value)}>
              <option value="">Select supplier</option>
              {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div>
            <label className="form-label">Order Date <span className="text-red-500">*</span></label>
            <input type="date" className="form-input" value={form.order_date} onChange={e => setField('order_date', e.target.value)} />
          </div>
          <div>
            <label className="form-label">Expected Delivery</label>
            <input type="date" className="form-input" value={form.expected_delivery} onChange={e => setField('expected_delivery', e.target.value)} />
          </div>
          <div>
            <label className="form-label">Project</label>
            <select className="form-select" value={form.project_id} onChange={e => setField('project_id', e.target.value)}>
              <option value="">Select project</option>
              {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
          <div>
            <label className="form-label">Site</label>
            <select className="form-select" value={form.site_id} onChange={e => setField('site_id', e.target.value)}>
              <option value="">Select site</option>
              {sites.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div>
            <label className="form-label">Delivery Address</label>
            <input className="form-input" value={form.delivery_address} onChange={e => setField('delivery_address', e.target.value)} placeholder="Delivery address" />
          </div>
        </div>
        <div>
          <label className="form-label">Notes</label>
          <textarea className="form-input" rows={2} value={form.notes} onChange={e => setField('notes', e.target.value)} placeholder="Any notes for this purchase order..." />
        </div>
      </div>

      {/* Items */}
      <div className="card p-5">
        <div className="flex items-center justify-between mb-4 border-b border-gray-100 dark:border-gray-700 pb-2">
          <h2 className="text-sm font-semibold text-gray-700 dark:text-gray-300">Order Items</h2>
          <button onClick={addItem} className="btn-secondary text-xs"><Plus size={13} /> Add Item</button>
        </div>

        <div className="space-y-3">
          {items.map((item, idx) => (
            <div key={idx} className="grid grid-cols-12 gap-3 items-end p-3 bg-gray-50 dark:bg-gray-700/30 rounded-lg">
              <div className="col-span-4">
                <label className="form-label text-xs">Material</label>
                <select className="form-select text-sm" value={item.material_id} onChange={e => setItem(idx, 'material_id', e.target.value)}>
                  <option value="">Select material</option>
                  {materials.map(m => <option key={m.id} value={m.id}>{m.name} ({m.unit})</option>)}
                </select>
              </div>
              <div className="col-span-2">
                <label className="form-label text-xs">Unit</label>
                <input className="form-input text-sm" value={item.unit} readOnly placeholder="Unit" />
              </div>
              <div className="col-span-2">
                <label className="form-label text-xs">Quantity</label>
                <input type="number" min="0.01" step="0.01" className="form-input text-sm" value={item.quantity} onChange={e => setItem(idx, 'quantity', e.target.value)} placeholder="0" />
              </div>
              <div className="col-span-2">
                <label className="form-label text-xs">Unit Price (₹)</label>
                <input type="number" min="0" step="0.01" className="form-input text-sm" value={item.unit_price} onChange={e => setItem(idx, 'unit_price', e.target.value)} placeholder="0.00" />
              </div>
              <div className="col-span-1">
                <label className="form-label text-xs">Total</label>
                <div className="text-sm font-semibold text-gray-700 dark:text-gray-300 py-2">
                  {fmtCurrency(parseFloat(item.quantity || 0) * parseFloat(item.unit_price || 0))}
                </div>
              </div>
              <div className="col-span-1 flex justify-end">
                {items.length > 1 && (
                  <button onClick={() => removeItem(idx)} className="p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded mt-4">
                    <Trash2 size={14} />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 flex justify-end">
          <div className="text-right space-y-1">
            <div className="text-sm text-gray-500">Subtotal: <span className="font-semibold text-gray-900 dark:text-white">{fmtCurrency(subtotal)}</span></div>
            <div className="text-base font-bold text-primary-600">Total: {fmtCurrency(subtotal)}</div>
          </div>
        </div>
      </div>

      <div className="flex justify-end gap-3">
        <button onClick={() => navigate('/purchase-orders')} className="btn-secondary">Cancel</button>
        <button onClick={handleSubmit} disabled={saving} className="btn-primary px-6">
          {saving ? 'Creating…' : 'Create Purchase Order'}
        </button>
      </div>
    </div>
  );
}
