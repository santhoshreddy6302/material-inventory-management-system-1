const { success, error } = require('../utils/responseHelper');
const aiEngine = require('../services/aiEngine');

const getInsights = async (req, res) => {
  try {
    const data = req.body;
    const insights = await aiEngine.generateInsights(data);
    return success(res, insights, 'Insights generated successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

module.exports = { getInsights };
