const express = require('express');
const router = express.Router();
const subcontractorController = require('../controllers/subcontractorController');
const { authenticate } = require('../middleware/auth');

router.use(authenticate);

router.get('/', subcontractorController.getAll);
router.get('/:id', subcontractorController.getOne);
router.post('/', subcontractorController.create);
router.put('/:id', subcontractorController.update);
router.delete('/:id', subcontractorController.remove);

module.exports = router;
