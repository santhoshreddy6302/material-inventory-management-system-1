const db = require('../config/database');
const { success, created, error, paginated } = require('../utils/responseHelper');
const { parseFilters, generateCode } = require('../utils/helpers');

const getAll = async (req, res) => {
  try {
    const { page, limit, offset, search } = parseFilters(req.query);
    const { project_id, is_active } = req.query;
    let where = 'WHERE 1=1';
    const params = [];
    if (search) { where += ' AND (s.name LIKE ? OR s.site_code LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }
    if (project_id) { where += ' AND s.project_id = ?'; params.push(project_id); }
    if (is_active !== undefined) { where += ' AND s.is_active = ?'; params.push(is_active === 'true' ? 1 : 0); }

    const [countResult] = await db.query(`SELECT COUNT(*) as total FROM sites s ${where}`, params);
    const [rows] = await db.query(
      `SELECT s.*, p.name as project_name, u.name as engineer_name FROM sites s
       LEFT JOIN projects p ON s.project_id = p.id
       LEFT JOIN users u ON s.engineer_id = u.id
       ${where}
       ORDER BY s.created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );
    return paginated(res, rows, countResult[0].total, page, limit);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getAll_simple = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT id, name, site_code, project_id FROM sites WHERE is_active = 1 ORDER BY name ASC');
    return success(res, rows);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const create = async (req, res) => {
  try {
    const { name, location, address, project_id, engineer_id } = req.body;
    const code = generateCode('SITE');
    const [result] = await db.query(
      'INSERT INTO sites (site_code, name, location, address, project_id, engineer_id) VALUES (?, ?, ?, ?, ?, ?)',
      [code, name.trim(), location || null, address || null, project_id || null, engineer_id || null]
    );
    const [newSite] = await db.query('SELECT s.*, p.name as project_name FROM sites s LEFT JOIN projects p ON s.project_id = p.id WHERE s.id = ?', [result.insertId]);
    return created(res, newSite[0], 'Site created successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const update = async (req, res) => {
  try {
    const { name, location, address, project_id, engineer_id, is_active } = req.body;
    await db.query(
      'UPDATE sites SET name=?, location=?, address=?, project_id=?, engineer_id=?, is_active=?, updated_at=NOW() WHERE id=?',
      [name, location || null, address || null, project_id || null, engineer_id || null, is_active !== undefined ? is_active : 1, req.params.id]
    );
    const [updated] = await db.query('SELECT * FROM sites WHERE id = ?', [req.params.id]);
    return success(res, updated[0], 'Site updated successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const remove = async (req, res) => {
  try {
    const [inv] = await db.query('SELECT id FROM inventory WHERE site_id = ? LIMIT 1', [req.params.id]);
    if (inv.length) return error(res, 'Cannot delete site with inventory records', 409);
    const [result] = await db.query('DELETE FROM sites WHERE id = ?', [req.params.id]);
    if (!result.affectedRows) return error(res, 'Site not found', 404);
    return success(res, null, 'Site deleted successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

module.exports = { getAll, getAll_simple, create, update, remove };
