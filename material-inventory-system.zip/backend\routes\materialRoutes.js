const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const { getAll, getOne, create, update, remove, getCategories, createCategory, getLowStock } = require('../controllers/materialController');
const { authenticate, authorize } = require('../middleware/auth');
const validate = require('../middleware/validate');

router.use(authenticate);
router.get('/', getAll);
router.get('/low-stock', getLowStock);
router.get('/categories', getCategories);
router.post('/categories', authorize('admin', 'procurement_staff'), [
  body('name').trim().notEmpty().withMessage('Category name required')
], validate, createCategory);
router.get('/:id', getOne);
router.post('/', authorize('admin', 'procurement_staff'), [
  body('name').trim().notEmpty().withMessage('Name required'),
  body('unit').notEmpty().withMessage('Unit required'),
  body('cost_per_unit').isNumeric().withMessage('Valid cost required'),
  body('minimum_threshold').isNumeric().withMessage('Valid threshold required')
], validate, create);
router.put('/:id', authorize('admin', 'procurement_staff'), update);
router.delete('/:id', authorize('admin'), remove);

module.exports = router;
