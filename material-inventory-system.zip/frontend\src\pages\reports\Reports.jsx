import { useState } from 'react';
import { FileBarChart, Download, Filter } from 'lucide-react';
import { reportService } from '../../services/reportService';
import { downloadBlob, fmtCurrency, fmtDate } from '../../utils/helpers';
import DataTable from '../../components/common/DataTable';
import toast from 'react-hot-toast';

const REPORT_TYPES = [
  { key: 'inventory', label: 'Inventory Report',   desc: 'Current stock levels across all sites' },
  { key: 'purchase',  label: 'Purchase Report',    desc: 'Purchase orders and supplier spend' },
  { key: 'usage',     label: 'Usage Report',       desc: 'Material consumption by site and date' },
  { key: 'wastage',   label: 'Wastage Report',     desc: 'Wastage records and loss analysis' },
];

export default function Reports() {
  const [activeTab, setActiveTab]   = useState('inventory');
  const [filters, setFilters]       = useState({ from_date:'', to_date:'', site_id:'' });
  const [reportData, setReportData] = useState(null);
  const [summary, setSummary]       = useState(null);
  const [loading, setLoading]       = useState(false);
  const [downloading, setDownloading] = useState('');

  const setFilter = (k, v) => setFilters(f => ({ ...f, [k]: v }));

  const fetchReport = async () => {
    setLoading(true);
    try {
      const svcMap = { inventory: reportService.getInventory, purchase: reportService.getPurchase, usage: reportService.getUsage, wastage: reportService.getWastage };
      const { data: r } = await svcMap[activeTab](filters);
      if (r.success) { setReportData(r.data.rows); setSummary(r.data.summary); }
    } catch (e) { toast.error(e.message); }
    setLoading(false);
  };

  const downloadReport = async (format) => {
    setDownloading(format);
    try {
      const res = await reportService.download(activeTab, { ...filters, format });
      downloadBlob(res.data, `${activeTab}_report_${new Date().toISOString().split('T')[0]}.${format}`);
      toast.success(`${format.toUpperCase()} downloaded`);
    } catch (e) { toast.error('Download failed'); }
    setDownloading('');
  };

  const getColumns = () => {
    const cols = {
      inventory: [
        { header: 'Code', key: 'material_code' },
        { header: 'Material', key: 'material_name' },
        { header: 'Category', key: 'category', render: v => v || '—' },
        { header: 'Unit', key: 'unit' },
        { header: 'Site', key: 'site_name' },
        { header: 'Stock', key: 'current_stock', render: v => <span className="font-mono">{v}</span> },
        { header: 'Min', key: 'minimum_threshold' },
        { header: 'Stock Value', key: 'stock_value', render: v => fmtCurrency(v) },
        { header: 'Status', key: 'status', render: v => {
          const cls = { 'In Stock':'badge-green', 'Low Stock':'badge-yellow', 'Out of Stock':'badge-red' };
          return <span className={cls[v] || 'badge-gray'}>{v}</span>;
        }},
      ],
      purchase: [
        { header: 'PO No', key: 'po_number', render: v => <span className="font-mono text-xs text-primary-600">{v}</span> },
        { header: 'Date', key: 'order_date', render: v => fmtDate(v) },
        { header: 'Supplier', key: 'supplier_name' },
        { header: 'Status', key: 'status', render: v => <span className="badge-gray capitalize">{v?.replace(/_/g,' ')}</span> },
        { header: 'Payment', key: 'payment_status', render: v => <span className="badge-gray capitalize">{v}</span> },
        { header: 'Total', key: 'total_amount', render: v => <span className="font-semibold">{fmtCurrency(v)}</span> },
        { header: 'Project', key: 'project_name', render: v => v || '—' },
        { header: 'Site', key: 'site_name', render: v => v || '—' },
      ],
      usage: [
        { header: 'Code', key: 'usage_code', render: v => <span className="font-mono text-xs">{v}</span> },
        { header: 'Date', key: 'usage_date', render: v => fmtDate(v) },
        { header: 'Site', key: 'site_name' },
        { header: 'Material', key: 'material_name' },
        { header: 'Qty', key: 'quantity_used', render: (v, row) => `${v} ${row.unit}` },
        { header: 'Cost', key: 'total_cost', render: v => fmtCurrency(v) },
        { header: 'Purpose', key: 'purpose', render: v => v || '—' },
        { header: 'By', key: 'recorded_by' },
      ],
      wastage: [
        { header: 'Code', key: 'wastage_code', render: v => <span className="font-mono text-xs">{v}</span> },
        { header: 'Date', key: 'wastage_date', render: v => fmtDate(v) },
        { header: 'Site', key: 'site_name' },
        { header: 'Material', key: 'material_name' },
        { header: 'Qty', key: 'quantity_wasted', render: (v, row) => `${v} ${row.unit}` },
        { header: 'Cost', key: 'total_cost', render: v => fmtCurrency(v) },
        { header: 'Reason', key: 'reason', render: v => <span className="badge-orange capitalize">{v?.replace(/_/g,' ')}</span> },
        { header: 'Preventable', key: 'preventable', render: v => v ? <span className="badge-yellow">Yes</span> : 'No' },
      ],
    };
    return cols[activeTab] || [];
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2"><FileBarChart size={22}/>Reports</h1>
        <p className="text-sm text-gray-500">Generate and export inventory reports</p>
      </div>

      {/* Report Type Tabs */}
      <div className="flex gap-2 flex-wrap">
        {REPORT_TYPES.map(t => (
          <button key={t.key} onClick={() => { setActiveTab(t.key); setReportData(null); setSummary(null); }}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${activeTab === t.key ? 'bg-primary-600 text-white' : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-400 border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="card p-4">
        <div className="flex flex-wrap gap-4 items-end">
          <div>
            <label className="form-label text-xs">From Date</label>
            <input type="date" className="form-input text-sm" value={filters.from_date} onChange={e => setFilter('from_date', e.target.value)} />
          </div>
          <div>
            <label className="form-label text-xs">To Date</label>
            <input type="date" className="form-input text-sm" value={filters.to_date} onChange={e => setFilter('to_date', e.target.value)} />
          </div>
          <button onClick={fetchReport} disabled={loading} className="btn-primary">
            <Filter size={14} /> {loading ? 'Loading…' : 'Generate Report'}
          </button>
          {reportData && (
            <>
              <button onClick={() => downloadReport('csv')} disabled={!!downloading} className="btn-secondary text-sm">
                <Download size={14} /> {downloading === 'csv' ? 'Downloading…' : 'CSV'}
              </button>
              <button onClick={() => downloadReport('excel')} disabled={!!downloading} className="btn-secondary text-sm">
                <Download size={14} /> {downloading === 'excel' ? 'Downloading…' : 'Excel'}
              </button>
            </>
          )}
        </div>
      </div>

      {/* Summary Cards */}
      {summary && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {Object.entries(summary).map(([key, val]) => (
            <div key={key} className="card p-4 text-center">
              <div className="text-lg font-bold text-primary-600">{typeof val === 'number' && val > 1000 ? fmtCurrency(val) : val}</div>
              <div className="text-xs text-gray-500 mt-1 capitalize">{key.replace(/_/g,' ')}</div>
            </div>
          ))}
        </div>
      )}

      {/* Report Table */}
      {reportData && (
        <div className="card">
          <div className="px-4 py-3 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
            <span className="text-sm font-semibold text-gray-700 dark:text-gray-300">{REPORT_TYPES.find(t => t.key === activeTab)?.label}</span>
            <span className="text-xs text-gray-400">{reportData.length} records</span>
          </div>
          <DataTable columns={getColumns()} data={reportData} loading={loading} emptyMessage="No data for selected filters" />
        </div>
      )}

      {!reportData && !loading && (
        <div className="card p-12 text-center">
          <FileBarChart size={40} className="mx-auto text-gray-300 mb-3" />
          <p className="text-gray-500">Select filters and click Generate Report</p>
        </div>
      )}
    </div>
  );
}
