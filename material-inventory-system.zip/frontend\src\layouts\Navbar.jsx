import { useState, useEffect, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Menu, Bell, Sun, Moon, LogOut, User, ChevronDown, AlertTriangle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { alertService } from '../services/alertService';
import { timeAgo, getStatusColor } from '../utils/helpers';

export default function Navbar({ onMenuToggle }) {
  const { user, logout } = useAuth();
  const { dark, toggle } = useTheme();
  const navigate = useNavigate();
  const [alertCount, setAlertCount] = useState(0);
  const [alerts, setAlerts] = useState([]);
  const [alertOpen, setAlertOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const alertRef = useRef(null);
  const profileRef = useRef(null);

  useEffect(() => {
    fetchAlertCount();
    const interval = setInterval(fetchAlertCount, 30000);
    return () => clearInterval(interval);
  }, []);

  const fetchAlertCount = async () => {
    try {
      const { data } = await alertService.getUnreadCount();
      if (data.success) setAlertCount(data.data.count);
    } catch {}
  };

  const fetchAlerts = async () => {
    try {
      const { data } = await alertService.getAll({ limit: 8, is_read: false, is_resolved: false });
      if (data.success) setAlerts(data.data);
    } catch {}
  };

  const handleAlertOpen = () => {
    if (!alertOpen) fetchAlerts();
    setAlertOpen(o => !o);
    setProfileOpen(false);
  };

  useEffect(() => {
    const handler = e => {
      if (alertRef.current && !alertRef.current.contains(e.target)) setAlertOpen(false);
      if (profileRef.current && !profileRef.current.contains(e.target)) setProfileOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleLogout = () => { logout(); navigate('/login'); };

  const getSeverityColor = s => ({
    critical: 'text-red-500', high: 'text-orange-500', medium: 'text-yellow-500', low: 'text-blue-500'
  }[s] || 'text-gray-500');

  return (
    <header className="sticky top-0 z-10 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 h-14 flex items-center px-4 gap-3">
      <button
        onClick={onMenuToggle}
        className="lg:hidden p-2 rounded-lg text-gray-500 hover:text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 dark:text-gray-400"
      >
        <Menu size={20} />
      </button>

      {/* Breadcrumb placeholder - expandable */}
      <div className="flex-1 hidden sm:block">
        <span className="text-sm font-semibold text-gray-700 dark:text-gray-200">
          Material Inventory Management System
        </span>
      </div>

      <div className="flex items-center gap-2 ml-auto">
        {/* Dark mode */}
        <button
          onClick={toggle}
          className="p-2 rounded-lg text-gray-500 hover:text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-800"
          title="Toggle theme"
        >
          {dark ? <Sun size={18} /> : <Moon size={18} />}
        </button>

        {/* Alerts */}
        <div className="relative" ref={alertRef}>
          <button
            onClick={handleAlertOpen}
            className="relative p-2 rounded-lg text-gray-500 hover:text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-800"
          >
            <Bell size={18} />
            {alertCount > 0 && (
              <span className="absolute top-0.5 right-0.5 min-w-[18px] h-[18px] bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center px-1">
                {alertCount > 99 ? '99+' : alertCount}
              </span>
            )}
          </button>

          {alertOpen && (
            <div className="absolute right-0 mt-2 w-80 card shadow-xl py-1 z-50">
              <div className="flex items-center justify-between px-4 py-2 border-b border-gray-100 dark:border-gray-700">
                <span className="text-sm font-semibold text-gray-900 dark:text-white">Alerts</span>
                <Link to="/alerts" onClick={() => setAlertOpen(false)} className="text-xs text-primary-600 hover:underline">View all</Link>
              </div>
              <div className="max-h-72 overflow-y-auto">
                {alerts.length === 0
                  ? <div className="px-4 py-6 text-center text-sm text-gray-500">No unread alerts</div>
                  : alerts.map(a => (
                    <div key={a.id} className="px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer border-b border-gray-50 dark:border-gray-800 last:border-0">
                      <div className="flex items-start gap-2">
                        <AlertTriangle size={14} className={`mt-0.5 flex-shrink-0 ${getSeverityColor(a.severity)}`} />
                        <div className="flex-1 min-w-0">
                          <div className="text-xs font-medium text-gray-900 dark:text-white truncate">{a.title}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-400 mt-0.5 line-clamp-2">{a.message}</div>
                          <div className="text-xs text-gray-400 mt-0.5">{timeAgo(a.created_at)}</div>
                        </div>
                      </div>
                    </div>
                  ))
                }
              </div>
            </div>
          )}
        </div>

        {/* Profile */}
        <div className="relative" ref={profileRef}>
          <button
            onClick={() => { setProfileOpen(o => !o); setAlertOpen(false); }}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          >
            <div className="w-7 h-7 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center text-primary-700 dark:text-primary-300 text-xs font-bold">
              {user?.name?.charAt(0)?.toUpperCase()}
            </div>
            <span className="hidden sm:block text-sm font-medium text-gray-700 dark:text-gray-200">{user?.name?.split(' ')[0]}</span>
            <ChevronDown size={14} className="text-gray-400" />
          </button>

          {profileOpen && (
            <div className="absolute right-0 mt-2 w-48 card shadow-xl py-1 z-50">
              <div className="px-4 py-2 border-b border-gray-100 dark:border-gray-700">
                <div className="text-xs font-semibold text-gray-900 dark:text-white">{user?.name}</div>
                <div className="text-xs text-gray-500 capitalize">{user?.role?.replace(/_/g,' ')}</div>
              </div>
              <Link to="/profile" onClick={() => setProfileOpen(false)} className="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700">
                <User size={14} /> My Profile
              </Link>
              <button onClick={handleLogout} className="flex items-center gap-2 w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20">
                <LogOut size={14} /> Sign Out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
