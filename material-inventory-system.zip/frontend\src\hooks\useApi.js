import { useState, useCallback } from 'react';
import toast from 'react-hot-toast';

export function useApi(apiFn, { showSuccess = true, successMsg = 'Done' } = {}) {
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState(null);

  const execute = useCallback(async (...args) => {
    setLoading(true); setError(null);
    try {
      const res = await apiFn(...args);
      if (showSuccess) toast.success(res.data?.message || successMsg);
      return res.data;
    } catch (err) {
      const msg = err.message || 'Something went wrong';
      setError(msg);
      toast.error(msg);
      return null;
    } finally {
      setLoading(false);
    }
  }, [apiFn]);

  return { execute, loading, error };
}

export function useFetch(apiFn, immediate = true) {
  const [data,    setData]    = useState(null);
  const [loading, setLoading] = useState(immediate);
  const [error,   setError]   = useState(null);

  const fetch = useCallback(async (...args) => {
    setLoading(true); setError(null);
    try {
      const res = await apiFn(...args);
      setData(res.data?.data ?? res.data);
      return res.data?.data ?? res.data;
    } catch (err) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, [apiFn]);

  return { data, loading, error, fetch, setData };
}
