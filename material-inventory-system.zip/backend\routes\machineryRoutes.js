const express = require('express');
const router = express.Router();
const machineryController = require('../controllers/machineryController');
const { authenticate } = require('../middleware/auth');

router.use(authenticate);

router.get('/', machineryController.getAll);
router.get('/:id', machineryController.getOne);
router.post('/', machineryController.create);
router.put('/:id', machineryController.update);
router.delete('/:id', machineryController.remove);

module.exports = router;
