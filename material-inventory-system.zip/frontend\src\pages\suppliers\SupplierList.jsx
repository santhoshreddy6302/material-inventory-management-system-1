import { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, RefreshCw, Truck } from 'lucide-react';
import { supplierService } from '../../services/supplierService';
import DataTable from '../../components/common/DataTable';
import Pagination from '../../components/common/Pagination';
import SearchFilter from '../../components/common/SearchFilter';
import Modal from '../../components/common/Modal';
import { fmtCurrency } from '../../utils/helpers';
import toast from 'react-hot-toast';
import { useAuth } from '../../context/AuthContext';

export default function SupplierList() {
  const { hasRole } = useAuth();
  const canEdit = hasRole('admin','procurement_staff');
  const [data, setData]             = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading]       = useState(true);
  const [search, setSearch]         = useState('');
  const [page, setPage]             = useState(1);
  const [modal, setModal]           = useState(false);
  const [editing, setEditing]       = useState(null);
  const [saving, setSaving]         = useState(false);
  const emptyForm = { name:'', contact_person:'', email:'', phone:'', address:'', city:'', state:'', gst_number:'', payment_terms:'', credit_limit:'0', notes:'' };
  const [form, setForm]             = useState(emptyForm);

  useEffect(() => { fetchData(); }, [page, search]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: r } = await supplierService.getAll({ page, limit: 12, search });
      if (r.success) { setData(r.data); setPagination(r.pagination); }
    } catch {}
    setLoading(false);
  };

  const openAdd  = () => { setEditing(null); setForm(emptyForm); setModal(true); };
  const openEdit = item => { setEditing(item); setForm({ name:item.name, contact_person:item.contact_person||'', email:item.email||'', phone:item.phone||'', address:item.address||'', city:item.city||'', state:item.state||'', gst_number:item.gst_number||'', payment_terms:item.payment_terms||'', credit_limit:item.credit_limit||0, notes:item.notes||'' }); setModal(true); };

  const handleSave = async () => {
    if (!form.name) { toast.error('Supplier name required'); return; }
    setSaving(true);
    try {
      const { data: r } = editing ? await supplierService.update(editing.id, form) : await supplierService.create(form);
      if (r.success) { toast.success(editing ? 'Supplier updated' : 'Supplier created'); setModal(false); fetchData(); }
    } catch (e) { toast.error(e.message); }
    setSaving(false);
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Delete supplier "${name}"?`)) return;
    try {
      const { data: r } = await supplierService.remove(id);
      if (r.success) { toast.success('Deleted'); fetchData(); }
    } catch (e) { toast.error(e.message); }
  };

  const columns = [
    { header: 'Supplier', key: 'name', render: (v, row) => (<div><div className="font-semibold">{v}</div><div className="text-xs text-gray-400">{row.supplier_code}</div></div>) },
    { header: 'Contact', key: 'contact_person', render: v => v || '—' },
    { header: 'Phone', key: 'phone', render: v => v || '—' },
    { header: 'Email', key: 'email', render: v => v || '—' },
    { header: 'City / State', key: 'city', render: (v, row) => [v, row.state].filter(Boolean).join(', ') || '—' },
    { header: 'Orders', key: 'total_orders', render: v => <span className="badge-blue">{v}</span> },
    { header: 'Total Purchased', key: 'total_purchased', render: v => fmtCurrency(v) },
    { header: 'Status', key: 'is_active', render: v => v ? <span className="badge-green">Active</span> : <span className="badge-red">Inactive</span> },
    ...(canEdit ? [{ header: '', key: 'id', render: (_, row) => (
      <div className="flex gap-1">
        <button onClick={() => openEdit(row)} className="p-1.5 text-gray-400 hover:text-primary-600 rounded"><Edit2 size={14}/></button>
        <button onClick={() => handleDelete(row.id, row.name)} className="p-1.5 text-gray-400 hover:text-red-600 rounded"><Trash2 size={14}/></button>
      </div>
    )}] : [])
  ];

  return (
    <div className="space-y-4">
      <div className="page-header">
        <div><h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2"><Truck size={22}/>Suppliers</h1><p className="text-sm text-gray-500">{pagination?.total ?? 0} suppliers</p></div>
        {canEdit && <button onClick={openAdd} className="btn-primary"><Plus size={15}/> New Supplier</button>}
      </div>
      <div className="card">
        <div className="p-4 border-b border-gray-100 dark:border-gray-700 flex gap-3 items-center justify-between">
          <SearchFilter value={search} onChange={v=>{setSearch(v);setPage(1);}} placeholder="Search suppliers…" />
          <button onClick={fetchData} className="btn-secondary text-xs"><RefreshCw size={13}/></button>
        </div>
        <DataTable columns={columns} data={data} loading={loading} />
        <Pagination pagination={pagination} onPageChange={setPage} />
      </div>
      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Edit Supplier' : 'New Supplier'} size="lg"
        footer={<><button onClick={() => setModal(false)} className="btn-secondary">Cancel</button><button onClick={handleSave} disabled={saving} className="btn-primary">{saving ? 'Saving…' : editing ? 'Update' : 'Create'}</button></>}
      >
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2"><label className="form-label">Supplier Name *</label><input className="form-input" value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} /></div>
          <div><label className="form-label">Contact Person</label><input className="form-input" value={form.contact_person} onChange={e=>setForm(f=>({...f,contact_person:e.target.value}))} /></div>
          <div><label className="form-label">Phone</label><input className="form-input" value={form.phone} onChange={e=>setForm(f=>({...f,phone:e.target.value}))} /></div>
          <div><label className="form-label">Email</label><input type="email" className="form-input" value={form.email} onChange={e=>setForm(f=>({...f,email:e.target.value}))} /></div>
          <div><label className="form-label">GST Number</label><input className="form-input" value={form.gst_number} onChange={e=>setForm(f=>({...f,gst_number:e.target.value}))} /></div>
          <div><label className="form-label">City</label><input className="form-input" value={form.city} onChange={e=>setForm(f=>({...f,city:e.target.value}))} /></div>
          <div><label className="form-label">State</label><input className="form-input" value={form.state} onChange={e=>setForm(f=>({...f,state:e.target.value}))} /></div>
          <div><label className="form-label">Payment Terms</label><input className="form-input" placeholder="e.g. Net 30" value={form.payment_terms} onChange={e=>setForm(f=>({...f,payment_terms:e.target.value}))} /></div>
          <div><label className="form-label">Credit Limit (₹)</label><input type="number" className="form-input" value={form.credit_limit} onChange={e=>setForm(f=>({...f,credit_limit:e.target.value}))} /></div>
          <div className="col-span-2"><label className="form-label">Address</label><textarea className="form-input" rows={2} value={form.address} onChange={e=>setForm(f=>({...f,address:e.target.value}))} /></div>
          <div className="col-span-2"><label className="form-label">Notes</label><textarea className="form-input" rows={2} value={form.notes} onChange={e=>setForm(f=>({...f,notes:e.target.value}))} /></div>
        </div>
      </Modal>
    </div>
  );
}
