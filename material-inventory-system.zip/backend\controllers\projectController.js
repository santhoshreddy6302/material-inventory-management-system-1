const db = require('../config/database');
const { success, created, error, paginated } = require('../utils/responseHelper');
const { parseFilters, generateCode } = require('../utils/helpers');

const getAll = async (req, res) => {
  try {
    const { page, limit, offset, search } = parseFilters(req.query);
    const { status } = req.query;
    let where = 'WHERE 1=1';
    const params = [];
    if (search) { where += ' AND (p.name LIKE ? OR p.project_code LIKE ? OR p.client_name LIKE ?)'; params.push(`%${search}%`, `%${search}%`, `%${search}%`); }
    if (status) { where += ' AND p.status = ?'; params.push(status); }

    const [countResult] = await db.query(`SELECT COUNT(*) as total FROM projects p ${where}`, params);
    const [rows] = await db.query(
      `SELECT p.*, u.name as manager_name, COUNT(DISTINCT s.id) as site_count
       FROM projects p
       LEFT JOIN users u ON p.manager_id = u.id
       LEFT JOIN sites s ON p.id = s.project_id
       ${where}
       GROUP BY p.id
       ORDER BY p.created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );
    return paginated(res, rows, countResult[0].total, page, limit);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getOne = async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT p.*, u.name as manager_name FROM projects p LEFT JOIN users u ON p.manager_id = u.id WHERE p.id = ?`,
      [req.params.id]
    );
    if (!rows.length) return error(res, 'Project not found', 404);
    const [sites] = await db.query('SELECT s.*, u.name as engineer_name FROM sites s LEFT JOIN users u ON s.engineer_id = u.id WHERE s.project_id = ?', [req.params.id]);
    return success(res, { ...rows[0], sites });
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const create = async (req, res) => {
  try {
    const { name, description, location, client_name, start_date, end_date, budget, status, manager_id } = req.body;
    const code = generateCode('PRJ');
    const [result] = await db.query(
      `INSERT INTO projects (project_code, name, description, location, client_name, start_date, end_date, budget, status, manager_id, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [code, name.trim(), description || null, location || null, client_name || null, start_date || null, end_date || null, budget || 0, status || 'planning', manager_id || null, req.user.id]
    );
    const [newProject] = await db.query('SELECT p.*, u.name as manager_name FROM projects p LEFT JOIN users u ON p.manager_id = u.id WHERE p.id = ?', [result.insertId]);
    return created(res, newProject[0], 'Project created successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const update = async (req, res) => {
  try {
    const { name, description, location, client_name, start_date, end_date, budget, status, manager_id } = req.body;
    const [exists] = await db.query('SELECT id FROM projects WHERE id = ?', [req.params.id]);
    if (!exists.length) return error(res, 'Project not found', 404);
    await db.query(
      `UPDATE projects SET name=?, description=?, location=?, client_name=?, start_date=?, end_date=?, budget=?, status=?, manager_id=?, updated_at=NOW() WHERE id=?`,
      [name, description || null, location || null, client_name || null, start_date || null, end_date || null, budget || 0, status, manager_id || null, req.params.id]
    );
    const [updated] = await db.query('SELECT p.*, u.name as manager_name FROM projects p LEFT JOIN users u ON p.manager_id = u.id WHERE p.id = ?', [req.params.id]);
    return success(res, updated[0], 'Project updated successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const remove = async (req, res) => {
  try {
    const [sites] = await db.query('SELECT id FROM sites WHERE project_id = ? LIMIT 1', [req.params.id]);
    if (sites.length) return error(res, 'Cannot delete project with associated sites', 409);
    const [result] = await db.query('DELETE FROM projects WHERE id = ?', [req.params.id]);
    if (!result.affectedRows) return error(res, 'Project not found', 404);
    return success(res, null, 'Project deleted successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

module.exports = { getAll, getOne, create, update, remove };
