const db = require('../config/database');
const { success, created, error, paginated } = require('../utils/responseHelper');
const { parseFilters, generateCode } = require('../utils/helpers');

const getAll = async (req, res) => {
  try {
    const { page, limit, offset, search } = parseFilters(req.query);
    const { is_active } = req.query;
    let where = 'WHERE 1=1';
    const params = [];
    if (search) { where += ' AND (s.name LIKE ? OR s.supplier_code LIKE ? OR s.email LIKE ? OR s.phone LIKE ?)'; params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`); }
    if (is_active !== undefined) { where += ' AND s.is_active = ?'; params.push(is_active === 'true' ? 1 : 0); }

    const [countResult] = await db.query(`SELECT COUNT(*) as total FROM suppliers s ${where}`, params);
    const [rows] = await db.query(
      `SELECT s.*, COUNT(po.id) as total_orders, COALESCE(SUM(po.total_amount), 0) as total_purchased
       FROM suppliers s
       LEFT JOIN purchase_orders po ON s.id = po.supplier_id AND po.status NOT IN ('cancelled', 'draft')
       ${where}
       GROUP BY s.id
       ORDER BY s.created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );
    return paginated(res, rows, countResult[0].total, page, limit);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getAll_simple = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT id, name, supplier_code, phone, email FROM suppliers WHERE is_active = 1 ORDER BY name ASC');
    return success(res, rows);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const create = async (req, res) => {
  try {
    const { name, contact_person, email, phone, address, city, state, gst_number, payment_terms, credit_limit, notes } = req.body;
    const code = generateCode('SUP');
    const [result] = await db.query(
      'INSERT INTO suppliers (supplier_code, name, contact_person, email, phone, address, city, state, gst_number, payment_terms, credit_limit, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [code, name.trim(), contact_person || null, email || null, phone || null, address || null, city || null, state || null, gst_number || null, payment_terms || null, credit_limit || 0, notes || null]
    );
    const [newSupplier] = await db.query('SELECT * FROM suppliers WHERE id = ?', [result.insertId]);
    return created(res, newSupplier[0], 'Supplier created successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const update = async (req, res) => {
  try {
    const { name, contact_person, email, phone, address, city, state, gst_number, payment_terms, credit_limit, notes, is_active, rating } = req.body;
    await db.query(
      'UPDATE suppliers SET name=?, contact_person=?, email=?, phone=?, address=?, city=?, state=?, gst_number=?, payment_terms=?, credit_limit=?, notes=?, is_active=?, rating=?, updated_at=NOW() WHERE id=?',
      [name, contact_person || null, email || null, phone || null, address || null, city || null, state || null, gst_number || null, payment_terms || null, credit_limit || 0, notes || null, is_active !== undefined ? is_active : 1, rating || 0, req.params.id]
    );
    const [updated] = await db.query('SELECT * FROM suppliers WHERE id = ?', [req.params.id]);
    return success(res, updated[0], 'Supplier updated successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const remove = async (req, res) => {
  try {
    const [orders] = await db.query('SELECT id FROM purchase_orders WHERE supplier_id = ? LIMIT 1', [req.params.id]);
    if (orders.length) return error(res, 'Cannot delete supplier with purchase orders', 409);
    const [result] = await db.query('DELETE FROM suppliers WHERE id = ?', [req.params.id]);
    if (!result.affectedRows) return error(res, 'Supplier not found', 404);
    return success(res, null, 'Supplier deleted successfully');
  } catch (err) {
    return error(res, err.message, 500);
  }
};

module.exports = { getAll, getAll_simple, create, update, remove };
