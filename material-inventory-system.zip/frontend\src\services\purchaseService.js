import api from './api';
export const purchaseService = {
  getAll:       p => api.get('/purchase-orders', { params: p }),
  getOne:       id => api.get(`/purchase-orders/${id}`),
  create:       d => api.post('/purchase-orders', d),
  updateStatus: (id, d) => api.put(`/purchase-orders/${id}/status`, d),
  remove:       id => api.delete(`/purchase-orders/${id}`),
};
