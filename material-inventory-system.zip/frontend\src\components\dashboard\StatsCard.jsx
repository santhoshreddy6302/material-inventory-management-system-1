export default function StatsCard({ title, value, subtitle, icon: Icon, color = 'blue', trend, trendUp }) {
  const colors = {
    blue:   { bg: 'bg-blue-50 dark:bg-blue-900/20',   icon: 'text-blue-600 dark:text-blue-400',   border: 'border-l-blue-500' },
    green:  { bg: 'bg-green-50 dark:bg-green-900/20', icon: 'text-green-600 dark:text-green-400', border: 'border-l-green-500' },
    yellow: { bg: 'bg-yellow-50 dark:bg-yellow-900/20', icon: 'text-yellow-600 dark:text-yellow-400', border: 'border-l-yellow-500' },
    red:    { bg: 'bg-red-50 dark:bg-red-900/20',     icon: 'text-red-600 dark:text-red-400',     border: 'border-l-red-500' },
    purple: { bg: 'bg-purple-50 dark:bg-purple-900/20', icon: 'text-purple-600 dark:text-purple-400', border: 'border-l-purple-500' },
    orange: { bg: 'bg-orange-50 dark:bg-orange-900/20', icon: 'text-orange-600 dark:text-orange-400', border: 'border-l-orange-500' },
  };
  const c = colors[color] || colors.blue;

  return (
    <div className={`stat-card border-l-4 ${c.border}`}>
      <div>
        <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">{title}</p>
        <p className="text-2xl font-bold text-gray-900 dark:text-white">{value}</p>
        {subtitle && <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{subtitle}</p>}
        {trend && (
          <div className={`flex items-center gap-1 mt-2 text-xs font-medium ${trendUp ? 'text-green-600' : 'text-red-500'}`}>
            <span>{trendUp ? '↑' : '↓'} {trend}</span>
            <span className="text-gray-400 font-normal">vs last month</span>
          </div>
        )}
      </div>
      <div className={`p-3 rounded-xl ${c.bg}`}>
        <Icon size={22} className={c.icon} />
      </div>
    </div>
  );
}
