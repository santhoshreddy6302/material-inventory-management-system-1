import api from './api';
export const siteService = {
  getAll:      p => api.get('/sites', { params: p }),
  getAllSimple: () => api.get('/sites/all'),
  create:      d => api.post('/sites', d),
  update:      (id, d) => api.put(`/sites/${id}`, d),
  remove:      id => api.delete(`/sites/${id}`),
};
