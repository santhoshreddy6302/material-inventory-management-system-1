import api from './api';
export const expenseService = {
  getAll: p => api.get('/expenses', { params: p }),
  getOne: id => api.get(`/expenses/${id}`),
  create: d => api.post('/expenses', d),
  update: (id, d) => api.put(`/expenses/${id}`, d),
  remove: id => api.delete(`/expenses/${id}`),
};
