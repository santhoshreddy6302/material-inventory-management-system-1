const db = require('../config/database');
const { success, created, error, paginated } = require('../utils/responseHelper');
const { parseFilters, generateCode_with_timestamp } = require('../utils/helpers');
const { checkAndCreateAlerts } = require('./inventoryController');

const getAll = async (req, res) => {
  try {
    const { page, limit, offset, search } = parseFilters(req.query);
    const { site_id, material_id, from_date, to_date } = req.query;
    let where = 'WHERE 1=1';
    const params = [];
    if (site_id) { where += ' AND u.site_id = ?'; params.push(site_id); }
    if (material_id) { where += ' AND u.material_id = ?'; params.push(material_id); }
    if (from_date) { where += ' AND u.usage_date >= ?'; params.push(from_date); }
    if (to_date) { where += ' AND u.usage_date <= ?'; params.push(to_date); }
    if (search) { where += ' AND (m.name LIKE ? OR s.name LIKE ? OR u.purpose LIKE ?)'; params.push(`%${search}%`, `%${search}%`, `%${search}%`); }

    const [countResult] = await db.query(`SELECT COUNT(*) as total FROM material_usage u LEFT JOIN materials m ON u.material_id = m.id LEFT JOIN sites s ON u.site_id = s.id ${where}`, params);
    const [rows] = await db.query(
      `SELECT u.*, m.name as material_name, m.unit, m.material_code, m.cost_per_unit,
              s.name as site_name, p.name as project_name, r.name as recorded_by_name
       FROM material_usage u
       LEFT JOIN materials m ON u.material_id = m.id
       LEFT JOIN sites s ON u.site_id = s.id
       LEFT JOIN projects p ON s.project_id = p.id
       LEFT JOIN users r ON u.recorded_by = r.id
       ${where}
       ORDER BY u.usage_date DESC, u.created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );
    return paginated(res, rows, countResult[0].total, page, limit);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const create = async (req, res) => {
  try {
    const { site_id, material_id, quantity_used, usage_date, purpose, work_type, floor_level, remarks } = req.body;
    const conn = await db.getConnection();
    try {
      await conn.beginTransaction();
      // Check inventory
      const [inv] = await conn.query(
        'SELECT * FROM inventory WHERE material_id = ? AND site_id = ?',
        [material_id, site_id]
      );
      if (!inv.length || inv[0].current_stock < quantity_used) {
        throw new Error(`Insufficient stock. Available: ${inv.length ? inv[0].current_stock : 0}`);
      }
      const [material] = await conn.query('SELECT cost_per_unit FROM materials WHERE id = ?', [material_id]);
      const unit_cost = material[0]?.cost_per_unit || 0;
      const total_cost = unit_cost * quantity_used;
      const code = generateCode_with_timestamp('USE');
      const [result] = await conn.query(
        `INSERT INTO material_usage (usage_code, site_id, material_id, quantity_used, unit_cost, total_cost, usage_date, purpose, work_type, floor_level, remarks, recorded_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [code, site_id, material_id, quantity_used, unit_cost, total_cost, usage_date, purpose || null, work_type || null, floor_level || null, remarks || null, req.user.id]
      );
      const newStock = parseFloat(inv[0].current_stock) - parseFloat(quantity_used);
      await conn.query('UPDATE inventory SET current_stock = ?, last_updated = NOW() WHERE id = ?', [newStock, inv[0].id]);
      await conn.query(
        `INSERT INTO inventory_transactions (inventory_id, material_id, site_id, transaction_type, quantity, balance_after, unit_cost, total_cost, reference_id, reference_type, created_by)
         VALUES (?, ?, ?, 'usage', ?, ?, ?, ?, ?, 'material_usage', ?)`,
        [inv[0].id, material_id, site_id, -quantity_used, newStock, unit_cost, total_cost, result.insertId, req.user.id]
      );
      await checkAndCreateAlerts(conn, material_id, site_id, newStock);
      await conn.commit();
      const [newUsage] = await db.query('SELECT * FROM material_usage WHERE id = ?', [result.insertId]);
      return created(res, newUsage[0], 'Usage recorded successfully');
    } catch (e) {
      await conn.rollback();
      throw e;
    } finally {
      conn.release();
    }
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getStats = async (req, res) => {
  try {
    const { site_id, from_date, to_date } = req.query;
    let where = 'WHERE 1=1';
    const params = [];
    if (site_id) { where += ' AND u.site_id = ?'; params.push(site_id); }
    if (from_date) { where += ' AND u.usage_date >= ?'; params.push(from_date); }
    if (to_date) { where += ' AND u.usage_date <= ?'; params.push(to_date); }

    const [byMaterial] = await db.query(
      `SELECT m.name, m.unit, SUM(u.quantity_used) as total_qty, SUM(u.total_cost) as total_cost
       FROM material_usage u LEFT JOIN materials m ON u.material_id = m.id ${where}
       GROUP BY u.material_id ORDER BY total_qty DESC LIMIT 10`,
      params
    );
    const [bySite] = await db.query(
      `SELECT s.name as site_name, SUM(u.total_cost) as total_cost, COUNT(*) as records
       FROM material_usage u LEFT JOIN sites s ON u.site_id = s.id ${where}
       GROUP BY u.site_id ORDER BY total_cost DESC`,
      params
    );
    const [monthly] = await db.query(
      `SELECT DATE_FORMAT(u.usage_date, '%Y-%m') as month, SUM(u.total_cost) as total_cost, SUM(u.quantity_used) as total_qty
       FROM material_usage u ${where}
       GROUP BY month ORDER BY month DESC LIMIT 12`,
      params
    );
    return success(res, { byMaterial, bySite, monthly });
  } catch (err) {
    return error(res, err.message, 500);
  }
};

module.exports = { getAll, create, getStats };
