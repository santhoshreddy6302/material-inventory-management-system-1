import LoadingSpinner from './LoadingSpinner';

export default function DataTable({ columns, data, loading, emptyMessage = 'No records found' }) {
  if (loading) return (
    <div className="flex items-center justify-center py-16">
      <LoadingSpinner size="lg" />
    </div>
  );

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
        <thead className="bg-gray-50 dark:bg-gray-700/50">
          <tr>
            {columns.map((col, i) => (
              <th key={i} className={`table-header ${col.className || ''}`} style={col.style}>
                {col.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100 dark:divide-gray-700/50">
          {(!data || data.length === 0)
            ? <tr><td colSpan={columns.length} className="py-12 text-center text-sm text-gray-500 dark:text-gray-400">{emptyMessage}</td></tr>
            : data.map((row, ri) =>
                <tr key={ri} className="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                  {columns.map((col, ci) => (
                    <td key={ci} className={`table-cell ${col.tdClassName || ''}`} style={col.style}>
                      {col.render ? col.render(row[col.key], row) : (row[col.key] ?? '—')}
                    </td>
                  ))}
                </tr>
              )
          }
        </tbody>
      </table>
    </div>
  );
}
