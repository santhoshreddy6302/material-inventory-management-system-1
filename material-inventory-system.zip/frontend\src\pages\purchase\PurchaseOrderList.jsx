import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Plus, ShoppingCart, Eye, Trash2, RefreshCw, CheckCircle, XCircle } from 'lucide-react';
import { purchaseService } from '../../services/purchaseService';
import DataTable from '../../components/common/DataTable';
import Pagination from '../../components/common/Pagination';
import SearchFilter from '../../components/common/SearchFilter';
import Modal from '../../components/common/Modal';
import { fmtDate, fmtCurrency, getStatusColor, getStatusLabel } from '../../utils/helpers';
import toast from 'react-hot-toast';
import { useAuth } from '../../context/AuthContext';

export default function PurchaseOrderList() {
  const { hasRole } = useAuth();
  const [data, setData]             = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading]       = useState(true);
  const [search, setSearch]         = useState('');
  const [filters, setFilters]       = useState({});
  const [page, setPage]             = useState(1);
  const [viewModal, setViewModal]   = useState(false);
  const [selected, setSelected]     = useState(null);
  const [statusModal, setStatusModal] = useState(false);
  const [newStatus, setNewStatus]   = useState('');
  const [statusNotes, setStatusNotes] = useState('');
  const [saving, setSaving]         = useState(false);

  useEffect(() => { fetchData(); }, [page, search, filters]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: r } = await purchaseService.getAll({ page, limit: 12, search, ...filters });
      if (r.success) { setData(r.data); setPagination(r.pagination); }
    } catch {}
    setLoading(false);
  };

  const openView = async (id) => {
    try {
      const { data: r } = await purchaseService.getOne(id);
      if (r.success) { setSelected(r.data); setViewModal(true); }
    } catch (e) { toast.error(e.message); }
  };

  const openStatus = (po, status) => {
    setSelected(po); setNewStatus(status); setStatusNotes(''); setStatusModal(true);
  };

  const handleStatusUpdate = async () => {
    setSaving(true);
    try {
      const { data: r } = await purchaseService.updateStatus(selected.id, { status: newStatus, notes: statusNotes });
      if (r.success) { toast.success(r.message); setStatusModal(false); fetchData(); }
    } catch (e) { toast.error(e.message); }
    setSaving(false);
  };

  const handleDelete = async (id, po_number) => {
    if (!window.confirm(`Delete PO ${po_number}? This cannot be undone.`)) return;
    try {
      const { data: r } = await purchaseService.remove(id);
      if (r.success) { toast.success('Purchase order deleted'); fetchData(); }
    } catch (e) { toast.error(e.message); }
  };

  const getStatusActions = (row) => {
    const map = {
      draft:             ['pending_approval', 'cancelled'],
      pending_approval:  ['approved', 'cancelled'],
      approved:          ['ordered', 'cancelled'],
      ordered:           ['received', 'cancelled'],
      partially_received:['received'],
    };
    return map[row.status] || [];
  };

  const statusLabels = {
    pending_approval: 'Submit for Approval',
    approved: 'Approve',
    ordered: 'Mark Ordered',
    received: 'Mark Received',
    partially_received: 'Partial Receive',
    cancelled: 'Cancel',
  };

  const statusBtnClass = s => s === 'cancelled'
    ? 'text-xs px-2 py-1 rounded bg-red-50 text-red-600 hover:bg-red-100 dark:bg-red-900/20'
    : 'text-xs px-2 py-1 rounded bg-primary-50 text-primary-600 hover:bg-primary-100 dark:bg-primary-900/20';

  const columns = [
    { header: 'PO Number', key: 'po_number', render: v => (
      <span className="font-mono text-xs font-semibold text-primary-600 dark:text-primary-400">{v}</span>
    )},
    { header: 'Supplier', key: 'supplier_name', render: (v, row) => (
      <div><div className="font-medium text-sm">{v}</div><div className="text-xs text-gray-400">{row.supplier_phone}</div></div>
    )},
    { header: 'Date', key: 'order_date', render: v => fmtDate(v) },
    { header: 'Project / Site', key: 'project_name', render: (v, row) => (
      <div className="text-xs"><div>{v || '—'}</div><div className="text-gray-400">{row.site_name || ''}</div></div>
    )},
    { header: 'Items', key: 'item_count', render: v => <span className="badge-blue">{v} items</span> },
    { header: 'Amount', key: 'total_amount', render: v => <span className="font-semibold">{fmtCurrency(v)}</span> },
    { header: 'Status', key: 'status', render: v => <span className={getStatusColor(v)}>{getStatusLabel(v)}</span> },
    { header: 'Payment', key: 'payment_status', render: v => <span className={getStatusColor(v)}>{getStatusLabel(v)}</span> },
    { header: 'Actions', key: 'id', render: (id, row) => (
      <div className="flex items-center gap-1 flex-wrap">
        <button onClick={() => openView(id)} className="p-1.5 text-gray-400 hover:text-primary-600 rounded" title="View"><Eye size={14} /></button>
        {getStatusActions(row).map(s => (
          <button key={s} onClick={() => openStatus(row, s)} className={statusBtnClass(s)}>
            {statusLabels[s]}
          </button>
        ))}
        {['draft','cancelled'].includes(row.status) && hasRole('admin','procurement_staff') && (
          <button onClick={() => handleDelete(id, row.po_number)} className="p-1.5 text-gray-400 hover:text-red-600 rounded"><Trash2 size={14} /></button>
        )}
      </div>
    )}
  ];

  const filterDefs = [
    { key: 'status', label: 'Status', type: 'select', options: ['draft','pending_approval','approved','ordered','partially_received','received','cancelled'].map(s => ({ value: s, label: getStatusLabel(s) })) },
    { key: 'from_date', label: 'From Date', type: 'date' },
    { key: 'to_date', label: 'To Date', type: 'date' },
  ];

  return (
    <div className="space-y-4">
      <div className="page-header">
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2"><ShoppingCart size={22} />Purchase Orders</h1>
          <p className="text-sm text-gray-500 mt-0.5">{pagination?.total ?? 0} total orders</p>
        </div>
        {hasRole('admin','procurement_staff','project_manager') && (
          <Link to="/purchase-orders/new" className="btn-primary"><Plus size={16} /> New PO</Link>
        )}
      </div>

      <div className="card">
        <div className="p-4 border-b border-gray-100 dark:border-gray-700 flex flex-wrap gap-3 items-center justify-between">
          <SearchFilter value={search} onChange={v=>{setSearch(v);setPage(1);}} placeholder="Search PO number, supplier…"
            filters={filterDefs} filterValues={filters} onFilterChange={(k,v)=>{setFilters(f=>({...f,[k]:v}));setPage(1);}} />
          <button onClick={fetchData} className="btn-secondary text-xs"><RefreshCw size={13} /></button>
        </div>
        <DataTable columns={columns} data={data} loading={loading} emptyMessage="No purchase orders found" />
        <Pagination pagination={pagination} onPageChange={setPage} />
      </div>

      {/* View Modal */}
      <Modal open={viewModal} onClose={() => setViewModal(false)} title={`PO Details — ${selected?.po_number}`} size="xl">
        {selected && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="space-y-2">
                <div className="flex gap-2"><span className="text-gray-500 w-32">Supplier:</span><span className="font-medium">{selected.supplier_name}</span></div>
                <div className="flex gap-2"><span className="text-gray-500 w-32">Order Date:</span><span>{fmtDate(selected.order_date)}</span></div>
                <div className="flex gap-2"><span className="text-gray-500 w-32">Expected:</span><span>{fmtDate(selected.expected_delivery) || '—'}</span></div>
                <div className="flex gap-2"><span className="text-gray-500 w-32">Status:</span><span className={getStatusColor(selected.status)}>{getStatusLabel(selected.status)}</span></div>
              </div>
              <div className="space-y-2">
                <div className="flex gap-2"><span className="text-gray-500 w-32">Project:</span><span>{selected.project_name || '—'}</span></div>
                <div className="flex gap-2"><span className="text-gray-500 w-32">Site:</span><span>{selected.site_name || '—'}</span></div>
                <div className="flex gap-2"><span className="text-gray-500 w-32">Created by:</span><span>{selected.created_by_name}</span></div>
                <div className="flex gap-2"><span className="text-gray-500 w-32">Approved by:</span><span>{selected.approved_by_name || '—'}</span></div>
              </div>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">Order Items</h4>
              <table className="w-full text-sm">
                <thead><tr className="bg-gray-50 dark:bg-gray-700">{['Material','Unit','Qty','Unit Price','Total'].map(h=><th key={h} className="table-header">{h}</th>)}</tr></thead>
                <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                  {(selected.items || []).map(item => (
                    <tr key={item.id}>
                      <td className="table-cell font-medium">{item.material_name}</td>
                      <td className="table-cell">{item.unit}</td>
                      <td className="table-cell">{item.quantity}</td>
                      <td className="table-cell">{fmtCurrency(item.unit_price)}</td>
                      <td className="table-cell font-semibold">{fmtCurrency(item.total_price)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot><tr className="bg-gray-50 dark:bg-gray-700">
                  <td colSpan={4} className="table-cell font-bold text-right">Total Amount:</td>
                  <td className="table-cell font-bold text-primary-600">{fmtCurrency(selected.total_amount)}</td>
                </tr></tfoot>
              </table>
            </div>
            {selected.notes && <div className="text-sm"><span className="text-gray-500">Notes: </span>{selected.notes}</div>}
          </div>
        )}
      </Modal>

      {/* Status Modal */}
      <Modal open={statusModal} onClose={() => setStatusModal(false)} title={`Update PO Status → ${getStatusLabel(newStatus)}`} size="sm"
        footer={<>
          <button onClick={() => setStatusModal(false)} className="btn-secondary">Cancel</button>
          <button onClick={handleStatusUpdate} disabled={saving} className="btn-primary">{saving ? 'Updating…' : 'Confirm'}</button>
        </>}
      >
        <div className="space-y-3">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Update <strong>{selected?.po_number}</strong> status to <strong>{getStatusLabel(newStatus)}</strong>?
            {newStatus === 'received' && <span className="block text-green-600 mt-1">⚡ This will automatically update site inventory.</span>}
            {newStatus === 'cancelled' && <span className="block text-red-600 mt-1">⚠️ This action cannot be undone.</span>}
          </p>
          <div>
            <label className="form-label">Notes (optional)</label>
            <textarea className="form-input" rows={2} value={statusNotes} onChange={e => setStatusNotes(e.target.value)} />
          </div>
        </div>
      </Modal>
    </div>
  );
}
