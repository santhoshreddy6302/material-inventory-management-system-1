const sendNotification = async (userId, message) => {
  // Stub for sending notifications
  console.log(`Notification to user ${userId}: ${message}`);
  return true;
};

module.exports = { sendNotification };
