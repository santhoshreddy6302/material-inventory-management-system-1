import api from './api';
export const reportService = {
  getInventory: p => api.get('/reports/inventory', { params: p }),
  getPurchase:  p => api.get('/reports/purchase', { params: p }),
  getUsage:     p => api.get('/reports/usage', { params: p }),
  getWastage:   p => api.get('/reports/wastage', { params: p }),
  getLogs:      p => api.get('/reports/activity-logs', { params: p }),
  download: (type, params) => api.get(`/reports/${type}`, {
    params, responseType: 'blob'
  }),
};
