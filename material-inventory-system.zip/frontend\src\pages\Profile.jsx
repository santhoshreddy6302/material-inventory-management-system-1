import { useState } from 'react';
import { User, Lock, Save, Shield } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { userService } from '../services/userService';
import { fmtDateTime, ROLE_LABELS } from '../utils/helpers';
import toast from 'react-hot-toast';

export default function Profile() {
  const { user, fetchMe } = useAuth();
  const [tab, setTab]         = useState('profile');
  const [saving, setSaving]   = useState(false);
  const [profile, setProfile] = useState({ name: user?.name || '', phone: user?.phone || '' });
  const [passwords, setPasswords] = useState({ currentPassword:'', newPassword:'', confirm:'' });

  const handleProfileSave = async () => {
    if (!profile.name) { toast.error('Name is required'); return; }
    setSaving(true);
    try {
      const { data } = await userService.updateProfile(profile);
      if (data.success) { toast.success('Profile updated'); fetchMe(); }
    } catch (e) { toast.error(e.message); }
    setSaving(false);
  };

  const handlePasswordSave = async () => {
    const { currentPassword, newPassword, confirm } = passwords;
    if (!currentPassword || !newPassword) { toast.error('Fill all fields'); return; }
    if (newPassword.length < 6) { toast.error('New password must be at least 6 characters'); return; }
    if (newPassword !== confirm) { toast.error('Passwords do not match'); return; }
    setSaving(true);
    try {
      const { data } = await userService.changePassword({ currentPassword, newPassword });
      if (data.success) { toast.success('Password changed'); setPasswords({ currentPassword:'', newPassword:'', confirm:'' }); }
    } catch (e) { toast.error(e.message); }
    setSaving(false);
  };

  return (
    <div className="max-w-2xl space-y-5">
      <div>
        <h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2"><User size={22}/>My Profile</h1>
        <p className="text-sm text-gray-500">Manage your account settings</p>
      </div>

      {/* Avatar + Role Card */}
      <div className="card p-5 flex items-center gap-5">
        <div className="w-16 h-16 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center text-primary-700 dark:text-primary-300 text-2xl font-bold">
          {user?.name?.charAt(0)?.toUpperCase()}
        </div>
        <div>
          <div className="text-lg font-bold text-gray-900 dark:text-white">{user?.name}</div>
          <div className="text-sm text-gray-500">{user?.email}</div>
          <div className="flex items-center gap-2 mt-1">
            <span className="badge-blue flex items-center gap-1"><Shield size={11} />{ROLE_LABELS[user?.role] || user?.role}</span>
            {user?.is_active ? <span className="badge-green">Active</span> : <span className="badge-red">Inactive</span>}
          </div>
        </div>
        <div className="ml-auto text-right text-xs text-gray-400">
          <div>Last login</div>
          <div className="font-medium text-gray-600 dark:text-gray-300">{user?.last_login ? fmtDateTime(user.last_login) : 'N/A'}</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-gray-200 dark:border-gray-700">
        {[{ key:'profile', label:'Profile Info', icon: User }, { key:'password', label:'Change Password', icon: Lock }].map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors -mb-px ${tab === t.key ? 'border-primary-600 text-primary-600' : 'border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'}`}>
            <t.icon size={15}/>{t.label}
          </button>
        ))}
      </div>

      {tab === 'profile' && (
        <div className="card p-5 space-y-4">
          <h2 className="text-sm font-semibold text-gray-700 dark:text-gray-300">Personal Information</h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="form-label">Full Name</label>
              <input className="form-input" value={profile.name} onChange={e => setProfile(p => ({ ...p, name: e.target.value }))} />
            </div>
            <div>
              <label className="form-label">Email Address</label>
              <input className="form-input bg-gray-50 dark:bg-gray-700" value={user?.email} readOnly disabled />
              <p className="text-xs text-gray-400 mt-1">Email cannot be changed here. Contact admin.</p>
            </div>
            <div>
              <label className="form-label">Phone Number</label>
              <input className="form-input" value={profile.phone} onChange={e => setProfile(p => ({ ...p, phone: e.target.value }))} placeholder="+91 XXXXX XXXXX" />
            </div>
            <div>
              <label className="form-label">Role</label>
              <input className="form-input bg-gray-50 dark:bg-gray-700" value={ROLE_LABELS[user?.role] || user?.role} readOnly disabled />
            </div>
          </div>
          <div className="flex justify-end">
            <button onClick={handleProfileSave} disabled={saving} className="btn-primary">
              <Save size={15}/>{saving ? 'Saving…' : 'Save Changes'}
            </button>
          </div>
        </div>
      )}

      {tab === 'password' && (
        <div className="card p-5 space-y-4">
          <h2 className="text-sm font-semibold text-gray-700 dark:text-gray-300">Change Password</h2>
          <div>
            <label className="form-label">Current Password</label>
            <input type="password" className="form-input" value={passwords.currentPassword} onChange={e => setPasswords(p => ({ ...p, currentPassword: e.target.value }))} />
          </div>
          <div>
            <label className="form-label">New Password</label>
            <input type="password" className="form-input" value={passwords.newPassword} onChange={e => setPasswords(p => ({ ...p, newPassword: e.target.value }))} placeholder="Min 6 characters" />
          </div>
          <div>
            <label className="form-label">Confirm New Password</label>
            <input type="password" className="form-input" value={passwords.confirm} onChange={e => setPasswords(p => ({ ...p, confirm: e.target.value }))} />
            {passwords.confirm && passwords.newPassword !== passwords.confirm && (
              <p className="text-xs text-red-500 mt-1">Passwords do not match</p>
            )}
          </div>
          <div className="flex justify-end">
            <button onClick={handlePasswordSave} disabled={saving} className="btn-primary">
              <Lock size={15}/>{saving ? 'Saving…' : 'Update Password'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
