const express = require('express');
const router = express.Router();
const enquiryController = require('../controllers/enquiryController');
const { authenticate } = require('../middleware/auth');

router.use(authenticate);

router.get('/', enquiryController.getAll);
router.get('/:id', enquiryController.getOne);
router.post('/', enquiryController.create);
router.put('/:id', enquiryController.update);
router.delete('/:id', enquiryController.remove);

module.exports = router;
