const jwt = require('jsonwebtoken');
const db = require('../config/database');
const { error } = require('../utils/responseHelper');
const { JWT_SECRET } = require('../config/config');

const authenticate = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return error(res, 'Access denied. No token provided.', 401);
    }
    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, JWT_SECRET);
    const [rows] = await db.query(
      'SELECT id, name, email, role, is_active FROM users WHERE id = ?',
      [decoded.id]
    );
    if (!rows.length || !rows[0].is_active) {
      return error(res, 'User not found or account deactivated.', 401);
    }
    req.user = rows[0];
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') return error(res, 'Token expired.', 401);
    if (err.name === 'JsonWebTokenError') return error(res, 'Invalid token.', 401);
    return error(res, 'Authentication failed.', 500);
  }
};

const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user) return error(res, 'Not authenticated.', 401);
    if (!roles.includes(req.user.role)) {
      return error(res, `Access denied. Required roles: ${roles.join(', ')}`, 403);
    }
    next();
  };
};

module.exports = { authenticate, authorize };
