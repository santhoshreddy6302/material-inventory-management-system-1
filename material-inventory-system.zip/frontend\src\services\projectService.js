import api from './api';
export const projectService = {
  getAll:  p => api.get('/projects', { params: p }),
  getOne:  id => api.get(`/projects/${id}`),
  create:  d => api.post('/projects', d),
  update:  (id, d) => api.put(`/projects/${id}`, d),
  remove:  id => api.delete(`/projects/${id}`),
};
