const express = require('express');
const router = express.Router();
const labourController = require('../controllers/labourController');
const { authenticate } = require('../middleware/auth');

router.use(authenticate);

router.get('/', labourController.getAll);
router.get('/:id', labourController.getOne);
router.post('/', labourController.create);
router.put('/:id', labourController.update);
router.delete('/:id', labourController.remove);

module.exports = router;
