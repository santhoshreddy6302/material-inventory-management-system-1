import { useState, useEffect } from 'react';
import { Warehouse, Settings, RefreshCw, TrendingUp } from 'lucide-react';
import { inventoryService } from '../../services/inventoryService';
import { materialService } from '../../services/materialService';
import { siteService } from '../../services/siteService';
import DataTable from '../../components/common/DataTable';
import Pagination from '../../components/common/Pagination';
import SearchFilter from '../../components/common/SearchFilter';
import Modal from '../../components/common/Modal';
import { fmtCurrency, fmtNumber, fmtDateTime } from '../../utils/helpers';
import toast from 'react-hot-toast';
import { useAuth } from '../../context/AuthContext';

export default function InventoryList() {
  const { hasRole } = useAuth();
  const [data, setData]           = useState([]);
  const [pagination, setPagination]= useState(null);
  const [loading, setLoading]     = useState(true);
  const [search, setSearch]       = useState('');
  const [filters, setFilters]     = useState({});
  const [page, setPage]           = useState(1);
  const [adjModal, setAdjModal]   = useState(false);
  const [ledgerModal, setLedgerModal] = useState(false);
  const [selectedInv, setSelectedInv] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [txLoading, setTxLoading] = useState(false);
  const [sites, setSites]         = useState([]);
  const [materials, setMaterials] = useState([]);
  const [adjForm, setAdjForm]     = useState({ material_id:'', site_id:'', quantity:'', notes:'' });
  const [saving, setSaving]       = useState(false);

  useEffect(() => { siteService.getAllSimple().then(r => { if(r.data.success) setSites(r.data.data); }); }, []);
  useEffect(() => { fetchData(); }, [page, search, filters]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: r } = await inventoryService.getAll({ page, limit: 15, search, ...filters });
      if (r.success) { setData(r.data); setPagination(r.pagination); }
    } catch {}
    setLoading(false);
  };

  const openLedger = async (inv) => {
    setSelectedInv(inv); setLedgerModal(true); setTxLoading(true);
    try {
      const { data: r } = await inventoryService.getTransactions({ material_id: inv.material_id, site_id: inv.site_id, limit: 20 });
      if (r.success) setTransactions(r.data);
    } catch {}
    setTxLoading(false);
  };

  const handleAdjust = async () => {
    if (!adjForm.material_id || !adjForm.site_id || adjForm.quantity === '') { toast.error('Fill all required fields'); return; }
    setSaving(true);
    try {
      const { data } = await inventoryService.adjustStock({ ...adjForm, quantity: parseFloat(adjForm.quantity) });
      if (data.success) { toast.success('Stock adjusted'); setAdjModal(false); setAdjForm({ material_id:'', site_id:'', quantity:'', notes:'' }); fetchData(); }
    } catch (e) { toast.error(e.message); }
    setSaving(false);
  };

  const txColors = { purchase:'text-green-600', usage:'text-orange-600', wastage:'text-red-600', transfer_in:'text-blue-600', transfer_out:'text-purple-600', adjustment:'text-gray-600' };

  const columns = [
    { header: 'Material', key: 'material_name', render: (v, row) => (
      <div>
        <div className="font-medium text-gray-900 dark:text-white">{v}</div>
        <div className="text-xs text-gray-400">{row.material_code} · {row.category_name || '—'}</div>
      </div>
    )},
    { header: 'Site', key: 'site_name' },
    { header: 'Current Stock', key: 'current_stock', render: (v, row) => (
      <div>
        <div className={`font-semibold ${parseFloat(v) <= 0 ? 'text-red-600' : parseFloat(v) <= row.minimum_threshold ? 'text-yellow-600' : 'text-green-600'}`}>
          {fmtNumber(v)} {row.unit}
        </div>
        <div className="text-xs text-gray-400">Min: {fmtNumber(row.minimum_threshold)}</div>
      </div>
    )},
    { header: 'Stock Value', key: 'current_stock', tdClassName: '', render: (v, row) => fmtCurrency(parseFloat(v) * parseFloat(row.cost_per_unit)) },
    { header: 'Status', key: 'stock_status', render: v => ({
      in_stock:     <span className="badge-green">In Stock</span>,
      low_stock:    <span className="badge-yellow">Low Stock</span>,
      out_of_stock: <span className="badge-red">Out of Stock</span>,
    }[v] || '—') },
    { header: 'Last Updated', key: 'last_updated', render: v => <span className="text-xs text-gray-500">{fmtDateTime(v)}</span> },
    { header: '', key: 'id', render: (_, row) => (
      <button onClick={() => openLedger(row)} className="text-xs text-primary-600 hover:underline flex items-center gap-1">
        <TrendingUp size={12} /> Ledger
      </button>
    )}
  ];

  const filterDefs = [
    { key: 'site_id', label: 'Site', type: 'select', options: sites.map(s => ({ value: s.id, label: s.name })) },
    { key: 'low_stock', label: 'Show Low Stock', type: 'select', options: [{ value: 'true', label: 'Low Stock Only' }] },
  ];

  return (
    <div className="space-y-4">
      <div className="page-header">
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2"><Warehouse size={22} />Inventory</h1>
          <p className="text-sm text-gray-500 mt-0.5">{pagination?.total ?? 0} inventory entries</p>
        </div>
        {hasRole('admin','procurement_staff','site_engineer') && (
          <button onClick={() => setAdjModal(true)} className="btn-primary"><Settings size={15} /> Adjust Stock</button>
        )}
      </div>

      <div className="card">
        <div className="p-4 border-b border-gray-100 dark:border-gray-700 flex flex-wrap gap-3 items-center justify-between">
          <SearchFilter value={search} onChange={v=>{setSearch(v);setPage(1);}} placeholder="Search inventory…"
            filters={filterDefs} filterValues={filters} onFilterChange={(k,v)=>{setFilters(f=>({...f,[k]:v}));setPage(1);}} />
          <button onClick={fetchData} className="btn-secondary text-xs"><RefreshCw size={13} /></button>
        </div>
        <DataTable columns={columns} data={data} loading={loading} />
        <Pagination pagination={pagination} onPageChange={setPage} />
      </div>

      {/* Adjust Modal */}
      <Modal open={adjModal} onClose={() => setAdjModal(false)} title="Adjust Stock" size="sm"
        footer={<>
          <button onClick={() => setAdjModal(false)} className="btn-secondary">Cancel</button>
          <button onClick={handleAdjust} disabled={saving} className="btn-primary">{saving ? 'Saving…' : 'Adjust'}</button>
        </>}
      >
        <div className="space-y-3">
          <div>
            <label className="form-label">Site <span className="text-red-500">*</span></label>
            <select className="form-select" value={adjForm.site_id} onChange={e => setAdjForm(f=>({...f,site_id:e.target.value}))}>
              <option value="">Select site</option>
              {sites.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div>
            <label className="form-label">Material ID <span className="text-red-500">*</span></label>
            <input type="number" className="form-input" placeholder="Material ID" value={adjForm.material_id} onChange={e => setAdjForm(f=>({...f,material_id:e.target.value}))} />
          </div>
          <div>
            <label className="form-label">Quantity <span className="text-red-500">*</span></label>
            <input type="number" step="0.01" className="form-input" placeholder="Positive to add, negative to deduct" value={adjForm.quantity} onChange={e => setAdjForm(f=>({...f,quantity:e.target.value}))} />
          </div>
          <div>
            <label className="form-label">Notes</label>
            <textarea className="form-input" rows={2} value={adjForm.notes} onChange={e => setAdjForm(f=>({...f,notes:e.target.value}))} placeholder="Reason for adjustment..." />
          </div>
        </div>
      </Modal>

      {/* Ledger Modal */}
      <Modal open={ledgerModal} onClose={() => setLedgerModal(false)} title={`Stock Ledger — ${selectedInv?.material_name} @ ${selectedInv?.site_name}`} size="xl">
        {txLoading ? (
          <div className="flex justify-center py-8"><div className="animate-spin h-6 w-6 border-2 border-primary-600 border-t-transparent rounded-full" /></div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700 text-sm">
              <thead className="bg-gray-50 dark:bg-gray-700">
                <tr>
                  {['Date','Type','Qty','Balance','Cost','Reference','By'].map(h => <th key={h} className="table-header">{h}</th>)}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                {transactions.length === 0
                  ? <tr><td colSpan={7} className="py-8 text-center text-gray-400">No transactions found</td></tr>
                  : transactions.map(t => (
                    <tr key={t.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/30">
                      <td className="table-cell text-xs">{fmtDateTime(t.created_at)}</td>
                      <td className="table-cell"><span className={`font-medium capitalize ${txColors[t.transaction_type] || 'text-gray-600'}`}>{t.transaction_type.replace(/_/g,' ')}</span></td>
                      <td className={`table-cell font-mono font-semibold ${parseFloat(t.quantity) >= 0 ? 'text-green-600' : 'text-red-600'}`}>{parseFloat(t.quantity) >= 0 ? '+' : ''}{fmtNumber(t.quantity)}</td>
                      <td className="table-cell font-mono">{fmtNumber(t.balance_after)}</td>
                      <td className="table-cell">{t.total_cost > 0 ? fmtCurrency(t.total_cost) : '—'}</td>
                      <td className="table-cell text-xs text-gray-400">{t.reference_type || '—'} {t.reference_id ? `#${t.reference_id}` : ''}</td>
                      <td className="table-cell text-xs">{t.created_by_name || '—'}</td>
                    </tr>
                  ))
                }
              </tbody>
            </table>
          </div>
        )}
      </Modal>
    </div>
  );
}
