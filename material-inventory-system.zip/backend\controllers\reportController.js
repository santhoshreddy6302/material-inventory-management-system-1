const db = require('../config/database');
const { success, error } = require('../utils/responseHelper');
const ExcelJS = require('exceljs');
const PDFDocument = require('pdfkit');

const getInventoryReport = async (req, res) => {
  try {
    const { site_id, from_date, to_date, format } = req.query;
    let where = 'WHERE 1=1';
    const params = [];
    if (site_id) { where += ' AND i.site_id = ?'; params.push(site_id); }

    const [rows] = await db.query(
      `SELECT m.material_code, m.name as material_name, mc.name as category, m.unit,
              s.name as site_name, i.current_stock, m.minimum_threshold, m.cost_per_unit,
              (i.current_stock * m.cost_per_unit) as stock_value,
              CASE WHEN i.current_stock <= 0 THEN 'Out of Stock'
                   WHEN i.current_stock <= m.minimum_threshold THEN 'Low Stock'
                   ELSE 'In Stock' END as status
       FROM inventory i
       LEFT JOIN materials m ON i.material_id = m.id
       LEFT JOIN material_categories mc ON m.category_id = mc.id
       LEFT JOIN sites s ON i.site_id = s.id
       ${where}
       ORDER BY m.name, s.name`,
      params
    );

    if (format === 'csv') {
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=inventory_report.csv');
      const header = 'Code,Material,Category,Unit,Site,Current Stock,Min Threshold,Cost/Unit,Stock Value,Status\n';
      const csvData = rows.map(r =>
        `"${r.material_code}","${r.material_name}","${r.category || ''}","${r.unit}","${r.site_name}",${r.current_stock},${r.minimum_threshold},${r.cost_per_unit},${r.stock_value},"${r.status}"`
      ).join('\n');
      return res.send(header + csvData);
    }

    if (format === 'excel') {
      const wb = new ExcelJS.Workbook();
      const ws = wb.addWorksheet('Inventory Report');
      ws.columns = [
        { header: 'Code', key: 'material_code', width: 15 },
        { header: 'Material', key: 'material_name', width: 30 },
        { header: 'Category', key: 'category', width: 20 },
        { header: 'Unit', key: 'unit', width: 10 },
        { header: 'Site', key: 'site_name', width: 25 },
        { header: 'Current Stock', key: 'current_stock', width: 15 },
        { header: 'Min Threshold', key: 'minimum_threshold', width: 15 },
        { header: 'Cost/Unit', key: 'cost_per_unit', width: 15 },
        { header: 'Stock Value', key: 'stock_value', width: 15 },
        { header: 'Status', key: 'status', width: 15 }
      ];
      ws.getRow(1).font = { bold: true };
      ws.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E3A5F' } };
      ws.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
      rows.forEach(row => {
        const addedRow = ws.addRow(row);
        if (row.status === 'Out of Stock') addedRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEE2E2' } };
        else if (row.status === 'Low Stock') addedRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEF9C3' } };
      });
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename=inventory_report.xlsx');
      await wb.xlsx.write(res);
      return res.end();
    }

    return success(res, { rows, summary: { total: rows.length, lowStock: rows.filter(r => r.status === 'Low Stock').length, outOfStock: rows.filter(r => r.status === 'Out of Stock').length, totalValue: rows.reduce((s, r) => s + parseFloat(r.stock_value || 0), 0) } });
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getPurchaseReport = async (req, res) => {
  try {
    const { from_date, to_date, supplier_id, format } = req.query;
    let where = 'WHERE po.status NOT IN (\'draft\', \'cancelled\')';
    const params = [];
    if (from_date) { where += ' AND po.order_date >= ?'; params.push(from_date); }
    if (to_date) { where += ' AND po.order_date <= ?'; params.push(to_date); }
    if (supplier_id) { where += ' AND po.supplier_id = ?'; params.push(supplier_id); }

    const [rows] = await db.query(
      `SELECT po.po_number, po.order_date, s.name as supplier_name, po.status, po.payment_status,
              po.subtotal, po.total_amount, pr.name as project_name, si.name as site_name
       FROM purchase_orders po
       LEFT JOIN suppliers s ON po.supplier_id = s.id
       LEFT JOIN projects pr ON po.project_id = pr.id
       LEFT JOIN sites si ON po.site_id = si.id
       ${where}
       ORDER BY po.order_date DESC`,
      params
    );

    if (format === 'csv') {
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=purchase_report.csv');
      const header = 'PO Number,Date,Supplier,Status,Payment,Total,Project,Site\n';
      const csv = rows.map(r => `"${r.po_number}","${r.order_date}","${r.supplier_name}","${r.status}","${r.payment_status}",${r.total_amount},"${r.project_name || ''}","${r.site_name || ''}"`).join('\n');
      return res.send(header + csv);
    }

    if (format === 'excel') {
      const wb = new ExcelJS.Workbook();
      const ws = wb.addWorksheet('Purchase Report');
      ws.columns = [
        { header: 'PO Number', key: 'po_number', width: 20 },
        { header: 'Date', key: 'order_date', width: 15 },
        { header: 'Supplier', key: 'supplier_name', width: 25 },
        { header: 'Status', key: 'status', width: 15 },
        { header: 'Payment', key: 'payment_status', width: 15 },
        { header: 'Total Amount', key: 'total_amount', width: 15 },
        { header: 'Project', key: 'project_name', width: 25 },
        { header: 'Site', key: 'site_name', width: 20 }
      ];
      ws.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
      ws.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E3A5F' } };
      rows.forEach(r => ws.addRow(r));
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename=purchase_report.xlsx');
      await wb.xlsx.write(res);
      return res.end();
    }

    const total = rows.reduce((s, r) => s + parseFloat(r.total_amount || 0), 0);
    return success(res, { rows, summary: { total_orders: rows.length, total_amount: total } });
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getUsageReport = async (req, res) => {
  try {
    const { from_date, to_date, site_id, material_id, format } = req.query;
    let where = 'WHERE 1=1';
    const params = [];
    if (from_date) { where += ' AND u.usage_date >= ?'; params.push(from_date); }
    if (to_date) { where += ' AND u.usage_date <= ?'; params.push(to_date); }
    if (site_id) { where += ' AND u.site_id = ?'; params.push(site_id); }
    if (material_id) { where += ' AND u.material_id = ?'; params.push(material_id); }

    const [rows] = await db.query(
      `SELECT u.usage_code, u.usage_date, s.name as site_name, m.name as material_name, m.unit,
              u.quantity_used, u.total_cost, u.purpose, r.name as recorded_by
       FROM material_usage u
       LEFT JOIN sites s ON u.site_id = s.id
       LEFT JOIN materials m ON u.material_id = m.id
       LEFT JOIN users r ON u.recorded_by = r.id
       ${where}
       ORDER BY u.usage_date DESC`,
      params
    );

    if (format === 'csv') {
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=usage_report.csv');
      const header = 'Code,Date,Site,Material,Unit,Qty Used,Total Cost,Purpose,Recorded By\n';
      const csv = rows.map(r => `"${r.usage_code}","${r.usage_date}","${r.site_name}","${r.material_name}","${r.unit}",${r.quantity_used},${r.total_cost},"${r.purpose || ''}","${r.recorded_by}"`).join('\n');
      return res.send(header + csv);
    }

    if (format === 'excel') {
      const wb = new ExcelJS.Workbook();
      const ws = wb.addWorksheet('Usage Report');
      ws.columns = [
        { header: 'Code', key: 'usage_code', width: 15 },
        { header: 'Date', key: 'usage_date', width: 15 },
        { header: 'Site', key: 'site_name', width: 25 },
        { header: 'Material', key: 'material_name', width: 25 },
        { header: 'Unit', key: 'unit', width: 10 },
        { header: 'Qty Used', key: 'quantity_used', width: 12 },
        { header: 'Total Cost', key: 'total_cost', width: 12 },
        { header: 'Purpose', key: 'purpose', width: 20 },
        { header: 'Recorded By', key: 'recorded_by', width: 20 }
      ];
      ws.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
      ws.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E3A5F' } };
      rows.forEach(r => ws.addRow(r));
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename=usage_report.xlsx');
      await wb.xlsx.write(res);
      return res.end();
    }

    return success(res, { rows, summary: { total_records: rows.length, total_cost: rows.reduce((s, r) => s + parseFloat(r.total_cost || 0), 0) } });
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getWastageReport = async (req, res) => {
  try {
    const { from_date, to_date, site_id, format } = req.query;
    let where = 'WHERE 1=1';
    const params = [];
    if (from_date) { where += ' AND w.wastage_date >= ?'; params.push(from_date); }
    if (to_date) { where += ' AND w.wastage_date <= ?'; params.push(to_date); }
    if (site_id) { where += ' AND w.site_id = ?'; params.push(site_id); }

    const [rows] = await db.query(
      `SELECT w.wastage_code, w.wastage_date, s.name as site_name, m.name as material_name, m.unit,
              w.quantity_wasted, w.total_cost, w.reason, w.preventable, r.name as recorded_by
       FROM wastage_records w
       LEFT JOIN sites s ON w.site_id = s.id
       LEFT JOIN materials m ON w.material_id = m.id
       LEFT JOIN users r ON w.recorded_by = r.id
       ${where}
       ORDER BY w.wastage_date DESC`,
      params
    );

    if (format === 'csv') {
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=wastage_report.csv');
      const header = 'Code,Date,Site,Material,Unit,Qty Wasted,Total Cost,Reason,Preventable,Recorded By\n';
      const csv = rows.map(r => `"${r.wastage_code}","${r.wastage_date}","${r.site_name}","${r.material_name}","${r.unit}",${r.quantity_wasted},${r.total_cost},"${r.reason}","${r.preventable ? 'Yes' : 'No'}","${r.recorded_by}"`).join('\n');
      return res.send(header + csv);
    }

    if (format === 'excel') {
      const wb = new ExcelJS.Workbook();
      const ws = wb.addWorksheet('Wastage Report');
      ws.columns = [
        { header: 'Code', key: 'wastage_code', width: 15 },
        { header: 'Date', key: 'wastage_date', width: 15 },
        { header: 'Site', key: 'site_name', width: 25 },
        { header: 'Material', key: 'material_name', width: 25 },
        { header: 'Unit', key: 'unit', width: 10 },
        { header: 'Qty Wasted', key: 'quantity_wasted', width: 12 },
        { header: 'Total Cost', key: 'total_cost', width: 12 },
        { header: 'Reason', key: 'reason', width: 15 },
        { header: 'Preventable', key: 'preventable', width: 12 },
        { header: 'Recorded By', key: 'recorded_by', width: 20 }
      ];
      ws.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
      ws.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E3A5F' } };
      rows.forEach(r => ws.addRow({ ...r, preventable: r.preventable ? 'Yes' : 'No' }));
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename=wastage_report.xlsx');
      await wb.xlsx.write(res);
      return res.end();
    }

    return success(res, { rows, summary: { total_records: rows.length, total_cost: rows.reduce((s, r) => s + parseFloat(r.total_cost || 0), 0), preventable: rows.filter(r => r.preventable).length } });
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getActivityLogs = async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;
    const [countResult] = await db.query('SELECT COUNT(*) as total FROM activity_logs');
    const [rows] = await db.query(
      `SELECT al.*, u.name as user_name FROM activity_logs al LEFT JOIN users u ON al.user_id = u.id ORDER BY al.created_at DESC LIMIT ? OFFSET ?`,
      [parseInt(limit), offset]
    );
    return success(res, { rows, total: countResult[0].total });
  } catch (err) {
    return error(res, err.message, 500);
  }
};

module.exports = { getInventoryReport, getPurchaseReport, getUsageReport, getWastageReport, getActivityLogs };
