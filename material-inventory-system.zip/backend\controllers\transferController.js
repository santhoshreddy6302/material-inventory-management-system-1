const db = require('../config/database');
const { success, created, error, paginated } = require('../utils/responseHelper');
const { parseFilters, generateCode_with_timestamp } = require('../utils/helpers');

const getAll = async (req, res) => {
  try {
    const { page, limit, offset } = parseFilters(req.query);
    const { status, from_site_id, to_site_id } = req.query;
    let where = 'WHERE 1=1';
    const params = [];
    if (status) { where += ' AND t.status = ?'; params.push(status); }
    if (from_site_id) { where += ' AND t.from_site_id = ?'; params.push(from_site_id); }
    if (to_site_id) { where += ' AND t.to_site_id = ?'; params.push(to_site_id); }
    const [countResult] = await db.query(`SELECT COUNT(*) as total FROM stock_transfers t ${where}`, params);
    const [rows] = await db.query(
      `SELECT t.*, fs.name as from_site_name, ts.name as to_site_name,
              m.name as material_name, m.unit, m.material_code,
              r.name as requested_by_name, a.name as approved_by_name
       FROM stock_transfers t
       LEFT JOIN sites fs ON t.from_site_id = fs.id
       LEFT JOIN sites ts ON t.to_site_id = ts.id
       LEFT JOIN materials m ON t.material_id = m.id
       LEFT JOIN users r ON t.requested_by = r.id
       LEFT JOIN users a ON t.approved_by = a.id
       ${where}
       ORDER BY t.created_at DESC LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );
    return paginated(res, rows, countResult[0].total, page, limit);
  } catch (err) { return error(res, err.message, 500); }
};

const create = async (req, res) => {
  try {
    const { from_site_id, to_site_id, material_id, quantity, transfer_date, reason } = req.body;
    if (from_site_id === to_site_id) return error(res, 'Source and destination sites cannot be the same', 400);
    const [inv] = await db.query('SELECT * FROM inventory WHERE material_id = ? AND site_id = ?', [material_id, from_site_id]);
    if (!inv.length || inv[0].current_stock < quantity) {
      return error(res, `Insufficient stock. Available: ${inv.length ? inv[0].current_stock : 0}`, 400);
    }
    const code = generateCode_with_timestamp('TRF');
    const [result] = await db.query(
      `INSERT INTO stock_transfers (transfer_code, from_site_id, to_site_id, material_id, quantity, transfer_date, reason, requested_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [code, from_site_id, to_site_id, material_id, quantity, transfer_date, reason || null, req.user.id]
    );
    return created(res, { id: result.insertId, transfer_code: code }, 'Transfer request created');
  } catch (err) { return error(res, err.message, 500); }
};

const updateStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const [transfer] = await db.query('SELECT * FROM stock_transfers WHERE id = ?', [req.params.id]);
    if (!transfer.length) return error(res, 'Transfer not found', 404);
    const t = transfer[0];
    if (status === 'completed' && t.status !== 'in_transit' && t.status !== 'pending') {
      return error(res, 'Invalid status transition', 400);
    }
    const conn = await db.getConnection();
    try {
      await conn.beginTransaction();
      if (status === 'completed') {
        // Deduct from source
        const [srcInv] = await conn.query('SELECT * FROM inventory WHERE material_id = ? AND site_id = ?', [t.material_id, t.from_site_id]);
        if (!srcInv.length || srcInv[0].current_stock < t.quantity) throw new Error('Insufficient stock at source site');
        const newSrcStock = parseFloat(srcInv[0].current_stock) - parseFloat(t.quantity);
        await conn.query('UPDATE inventory SET current_stock = ?, last_updated = NOW() WHERE id = ?', [newSrcStock, srcInv[0].id]);
        await conn.query(
          `INSERT INTO inventory_transactions (inventory_id, material_id, site_id, transaction_type, quantity, balance_after, reference_id, reference_type, notes, created_by)
           VALUES (?, ?, ?, 'transfer_out', ?, ?, ?, 'stock_transfer', ?, ?)`,
          [srcInv[0].id, t.material_id, t.from_site_id, -t.quantity, newSrcStock, t.id, `Transfer to site`, req.user.id]
        );
        // Add to destination
        const [dstInv] = await conn.query('SELECT * FROM inventory WHERE material_id = ? AND site_id = ?', [t.material_id, t.to_site_id]);
        let dstInvId;
        let newDstStock;
        if (!dstInv.length) {
          const [r] = await conn.query('INSERT INTO inventory (material_id, site_id, current_stock) VALUES (?, ?, ?)', [t.material_id, t.to_site_id, t.quantity]);
          dstInvId = r.insertId; newDstStock = t.quantity;
        } else {
          newDstStock = parseFloat(dstInv[0].current_stock) + parseFloat(t.quantity);
          await conn.query('UPDATE inventory SET current_stock = ?, last_updated = NOW() WHERE id = ?', [newDstStock, dstInv[0].id]);
          dstInvId = dstInv[0].id;
        }
        await conn.query(
          `INSERT INTO inventory_transactions (inventory_id, material_id, site_id, transaction_type, quantity, balance_after, reference_id, reference_type, notes, created_by)
           VALUES (?, ?, ?, 'transfer_in', ?, ?, ?, 'stock_transfer', ?, ?)`,
          [dstInvId, t.material_id, t.to_site_id, t.quantity, newDstStock, t.id, `Transfer from site`, req.user.id]
        );
        await conn.query('UPDATE stock_transfers SET status = ?, approved_by = ?, updated_at = NOW() WHERE id = ?', [status, req.user.id, t.id]);
      } else {
        await conn.query('UPDATE stock_transfers SET status = ?, updated_at = NOW() WHERE id = ?', [status, t.id]);
      }
      await conn.commit();
      return success(res, null, 'Transfer status updated');
    } catch (e) { await conn.rollback(); throw e; } finally { conn.release(); }
  } catch (err) { return error(res, err.message, 500); }
};

module.exports = { getAll, create, updateStatus };
