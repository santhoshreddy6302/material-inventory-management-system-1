const db = require('../config/database');

const logActivity = (action, entityType) => async (req, res, next) => {
  const originalJson = res.json.bind(res);
  res.json = async (body) => {
    if (body && body.success && req.user) {
      try {
        await db.query(
          `INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, entity_name, ip_address)
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [
            req.user.id,
            req.user.name,
            action,
            entityType,
            body.data?.id || null,
            body.data?.name || body.data?.po_number || null,
            req.ip
          ]
        );
      } catch (e) { /* silent fail for logging */ }
    }
    return originalJson(body);
  };
  next();
};

module.exports = { logActivity };
