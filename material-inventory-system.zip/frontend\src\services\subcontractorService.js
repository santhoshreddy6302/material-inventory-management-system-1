import api from './api';
export const subcontractorService = {
  getAll: p => api.get('/subcontractors', { params: p }),
  getOne: id => api.get(`/subcontractors/${id}`),
  create: d => api.post('/subcontractors', d),
  update: (id, d) => api.put(`/subcontractors/${id}`, d),
  remove: id => api.delete(`/subcontractors/${id}`),
};
