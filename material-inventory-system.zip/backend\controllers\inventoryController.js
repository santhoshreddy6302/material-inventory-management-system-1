const db = require('../config/database');
const { success, created, error, paginated } = require('../utils/responseHelper');
const { parseFilters } = require('../utils/helpers');

const getAll = async (req, res) => {
  try {
    const { page, limit, offset, search } = parseFilters(req.query);
    const { site_id, material_id, low_stock } = req.query;
    let where = 'WHERE 1=1';
    const params = [];
    if (site_id) { where += ' AND i.site_id = ?'; params.push(site_id); }
    if (material_id) { where += ' AND i.material_id = ?'; params.push(material_id); }
    if (search) { where += ' AND (m.name LIKE ? OR m.material_code LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }
    if (low_stock === 'true') { where += ' AND i.current_stock <= m.minimum_threshold'; }

    const [countResult] = await db.query(`SELECT COUNT(*) as total FROM inventory i LEFT JOIN materials m ON i.material_id = m.id ${where}`, params);
    const [rows] = await db.query(
      `SELECT i.*, m.name as material_name, m.material_code, m.unit, m.minimum_threshold, m.cost_per_unit,
              mc.name as category_name, mc.color as category_color, s.name as site_name,
              CASE WHEN i.current_stock <= 0 THEN 'out_of_stock'
                   WHEN i.current_stock <= m.minimum_threshold THEN 'low_stock'
                   ELSE 'in_stock' END as stock_status
       FROM inventory i
       LEFT JOIN materials m ON i.material_id = m.id
       LEFT JOIN material_categories mc ON m.category_id = mc.id
       LEFT JOIN sites s ON i.site_id = s.id
       ${where}
       ORDER BY i.last_updated DESC
       LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );
    return paginated(res, rows, countResult[0].total, page, limit);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getSiteInventory = async (req, res) => {
  try {
    const { site_id } = req.params;
    const [rows] = await db.query(
      `SELECT i.*, m.name as material_name, m.material_code, m.unit, m.minimum_threshold, m.cost_per_unit,
              mc.name as category_name, mc.color as category_color
       FROM inventory i
       LEFT JOIN materials m ON i.material_id = m.id
       LEFT JOIN material_categories mc ON m.category_id = mc.id
       WHERE i.site_id = ?
       ORDER BY m.name ASC`,
      [site_id]
    );
    return success(res, rows);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const getTransactions = async (req, res) => {
  try {
    const { page, limit, offset } = parseFilters(req.query);
    const { site_id, material_id, transaction_type, from_date, to_date } = req.query;
    let where = 'WHERE 1=1';
    const params = [];
    if (site_id) { where += ' AND t.site_id = ?'; params.push(site_id); }
    if (material_id) { where += ' AND t.material_id = ?'; params.push(material_id); }
    if (transaction_type) { where += ' AND t.transaction_type = ?'; params.push(transaction_type); }
    if (from_date) { where += ' AND DATE(t.created_at) >= ?'; params.push(from_date); }
    if (to_date) { where += ' AND DATE(t.created_at) <= ?'; params.push(to_date); }

    const [countResult] = await db.query(`SELECT COUNT(*) as total FROM inventory_transactions t ${where}`, params);
    const [rows] = await db.query(
      `SELECT t.*, m.name as material_name, m.unit, m.material_code,
              s.name as site_name, u.name as created_by_name
       FROM inventory_transactions t
       LEFT JOIN materials m ON t.material_id = m.id
       LEFT JOIN sites s ON t.site_id = s.id
       LEFT JOIN users u ON t.created_by = u.id
       ${where}
       ORDER BY t.created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );
    return paginated(res, rows, countResult[0].total, page, limit);
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const adjustStock = async (req, res) => {
  try {
    const { material_id, site_id, quantity, notes } = req.body;
    const conn = await db.getConnection();
    try {
      await conn.beginTransaction();
      const [existing] = await conn.query(
        'SELECT * FROM inventory WHERE material_id = ? AND site_id = ?',
        [material_id, site_id]
      );
      let newStock;
      let inventoryId;
      if (!existing.length) {
        const [result] = await conn.query(
          'INSERT INTO inventory (material_id, site_id, current_stock) VALUES (?, ?, ?)',
          [material_id, site_id, Math.max(0, quantity)]
        );
        newStock = Math.max(0, quantity);
        inventoryId = result.insertId;
      } else {
        newStock = parseFloat(existing[0].current_stock) + parseFloat(quantity);
        if (newStock < 0) throw new Error('Insufficient stock for adjustment');
        await conn.query(
          'UPDATE inventory SET current_stock = ?, last_updated = NOW() WHERE id = ?',
          [newStock, existing[0].id]
        );
        inventoryId = existing[0].id;
      }
      await conn.query(
        `INSERT INTO inventory_transactions (inventory_id, material_id, site_id, transaction_type, quantity, balance_after, notes, created_by)
         VALUES (?, ?, ?, 'adjustment', ?, ?, ?, ?)`,
        [inventoryId, material_id, site_id, quantity, newStock, notes || null, req.user.id]
      );
      await checkAndCreateAlerts(conn, material_id, site_id, newStock);
      await conn.commit();
      return success(res, { material_id, site_id, new_stock: newStock }, 'Stock adjusted successfully');
    } catch (e) {
      await conn.rollback();
      throw e;
    } finally {
      conn.release();
    }
  } catch (err) {
    return error(res, err.message, 500);
  }
};

const checkAndCreateAlerts = async (conn, material_id, site_id, current_stock) => {
  const [material] = await conn.query('SELECT minimum_threshold, name FROM materials WHERE id = ?', [material_id]);
  if (!material.length) return;
  const { minimum_threshold, name } = material[0];
  if (current_stock <= 0) {
    await conn.query(
      `INSERT INTO alerts (type, title, message, material_id, site_id, severity)
       VALUES ('out_of_stock', ?, ?, ?, ?, 'critical')
       ON DUPLICATE KEY UPDATE is_read = 0, is_resolved = 0, created_at = NOW()`,
      [`Out of Stock: ${name}`, `Material "${name}" is out of stock at site`, material_id, site_id]
    );
  } else if (current_stock <= minimum_threshold) {
    await conn.query(
      `INSERT INTO alerts (type, title, message, material_id, site_id, severity)
       VALUES ('low_stock', ?, ?, ?, ?, 'high')
       ON DUPLICATE KEY UPDATE is_read = 0, is_resolved = 0, created_at = NOW()`,
      [`Low Stock: ${name}`, `Material "${name}" is below minimum threshold (${minimum_threshold})`, material_id, site_id]
    );
  }
};

module.exports = { getAll, getSiteInventory, getTransactions, adjustStock, checkAndCreateAlerts };
