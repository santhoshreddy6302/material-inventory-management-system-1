const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const { getAll, getOne, create, updateStatus, remove } = require('../controllers/purchaseController');
const { authenticate, authorize } = require('../middleware/auth');
const validate = require('../middleware/validate');

router.use(authenticate);
router.get('/', getAll);
router.get('/:id', getOne);
router.post('/', authorize('admin', 'procurement_staff', 'project_manager'), [
  body('supplier_id').isInt().withMessage('Supplier required'),
  body('order_date').isDate().withMessage('Valid date required'),
  body('items').isArray({ min: 1 }).withMessage('At least one item required')
], validate, create);
router.put('/:id/status', authorize('admin', 'procurement_staff', 'project_manager', 'accounts_staff'), updateStatus);
router.delete('/:id', authorize('admin', 'procurement_staff'), remove);

module.exports = router;
